// Service Worker for Push Notifications
self.addEventListener('push', (event) => {
  let data = { title: 'Duty Reminder', body: 'You have a duty today!' };
  
  try {
    if (event.data) {
      data = event.data.json();
    }
  } catch (e) {
    // Use defaults
  }

  const options = {
    body: data.body || 'You have a duty today!',
    icon: '/favicon.ico',
    badge: '/favicon.ico',
    tag: data.tag || 'duty-reminder',
    requireInteraction: true,
    data: { url: '/' },
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'Duty Reminder', options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }
      return clients.openWindow('/');
    })
  );
});
