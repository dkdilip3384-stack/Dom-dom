import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Validate JWT - require authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!);
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await anonClient.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    const { time } = await req.json();
    
    if (!time || !/^\d{2}:\d{2}$/.test(time)) {
      return new Response(
        JSON.stringify({ error: "Invalid time format. Use HH:MM" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate time range
    const [hours, minutes] = time.split(":").map(Number);
    if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59) {
      return new Response(
        JSON.stringify({ error: "Invalid time values" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Save notification time to app_settings
    const { error: upsertError } = await supabase
      .from("app_settings")
      .upsert({ key: "notification_time", value: time }, { onConflict: "key" });

    if (upsertError) throw upsertError;

    // Convert IST time to UTC for cron schedule
    let utcHours = hours - 5;
    let utcMinutes = minutes - 30;
    if (utcMinutes < 0) {
      utcMinutes += 60;
      utcHours -= 1;
    }
    if (utcHours < 0) utcHours += 24;

    const cronExpression = `${utcMinutes} ${utcHours} * * *`;

    // Update the cron job schedule using pg_cron via database
    const dbUrl = Deno.env.get("SUPABASE_DB_URL")!;
    
    const { Pool } = await import("https://deno.land/x/postgres@v0.19.3/mod.ts");
    const pool = new Pool(dbUrl, 1);
    const connection = await pool.connect();
    
    try {
      await connection.queryArray(`SELECT cron.unschedule('daily-duty-notifications')`).catch(() => {});
      
      const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || "";
      
      // Use parameterized approach - cron schedule and URL are validated/from env
      await connection.queryArray(`
        SELECT cron.schedule(
          'daily-duty-notifications',
          '${cronExpression}',
          $$
          SELECT net.http_post(
            url:='${supabaseUrl}/functions/v1/send-duty-notifications',
            headers:='{"Content-Type": "application/json", "Authorization": "Bearer ${anonKey}"}'::jsonb,
            body:='{"time": "scheduled"}'::jsonb
          ) as request_id;
          $$
        );
      `);
    } finally {
      connection.release();
      await pool.end();
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Notification time updated` 
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error updating schedule:", error);
    return new Response(
      JSON.stringify({ error: "Failed to update schedule" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
