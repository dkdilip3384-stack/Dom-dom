import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

interface NormalizedDeal {
  id: string;
  title: string;
  description: string;
  merchant: string;
  logo: string | null;
  image: string | null;
  discountLabel: string | null;
  offerPrice: number | null;
  originalPrice: number | null;
  url: string;
}

const CATEGORY_KEYWORDS: Record<string, string[]> = {
  all: [],
  food: ['food', 'restaurant', 'swiggy', 'zomato', 'dining', 'pizza', 'cafe', 'eat'],
  grocery: ['grocery', 'bigbasket', 'blinkit', 'zepto', 'jiomart', 'supermarket', 'fresh', 'vegetables'],
  room: ['home', 'kitchen', 'furniture', 'appliance', 'essentials', 'household', 'decor', 'ikea', 'urban ladder', 'pepperfry'],
  recharge: ['recharge', 'mobile', 'dth', 'bill', 'prepaid', 'postpaid', 'jio', 'airtel', 'vi ', 'bsnl'],
};

function matchesCategory(deal: NormalizedDeal, category: string): boolean {
  if (category === 'all' || !category) return true;
  const keywords = CATEGORY_KEYWORDS[category] || [];
  if (keywords.length === 0) return true;
  const haystack = `${deal.title} ${deal.description} ${deal.merchant}`.toLowerCase();
  return keywords.some((k) => haystack.includes(k));
}

function normalize(raw: any): NormalizedDeal | null {
  if (!raw) return null;
  const url =
    raw.click_url || raw.tracking_url || raw.deep_link || raw.url || raw.affiliate_url || raw.landing_url;
  if (!url) return null;

  const title = raw.title || raw.name || raw.offer_title || raw.description || 'Deal';
  const description = raw.description || raw.short_description || raw.offer_description || '';
  const merchant =
    raw.merchant_name || raw.campaign_name || raw.advertiser_name || raw.store || raw.brand || '';
  const logo = raw.logo || raw.merchant_logo || raw.image_url || raw.campaign_logo || null;
  const image = raw.banner || raw.image || raw.image_url || raw.thumbnail || logo;

  let discountLabel: string | null = null;
  if (raw.discount) discountLabel = String(raw.discount);
  else if (raw.discount_percentage) discountLabel = `${raw.discount_percentage}% OFF`;
  else if (raw.offer_type) discountLabel = String(raw.offer_type);

  const offerPrice = raw.offer_price ?? raw.sale_price ?? raw.price ?? null;
  const originalPrice = raw.original_price ?? raw.mrp ?? raw.list_price ?? null;

  return {
    id: String(raw.id || raw.offer_id || raw.campaign_id || raw.coupon_id || url),
    title: String(title),
    description: String(description),
    merchant: String(merchant),
    logo,
    image,
    discountLabel,
    offerPrice: offerPrice ? Number(offerPrice) : null,
    originalPrice: originalPrice ? Number(originalPrice) : null,
    url: String(url),
  };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('CUELINKS_API_KEY');
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'CUELINKS_API_KEY not configured' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let payload: any = {};
    if (req.method === 'POST') {
      payload = await req.json().catch(() => ({}));
    } else {
      const u = new URL(req.url);
      payload = Object.fromEntries(u.searchParams.entries());
    }

    const category = String(payload.category || 'all').toLowerCase();
    const page = Math.max(1, parseInt(String(payload.page || '1'), 10) || 1);
    const perPage = Math.min(50, Math.max(1, parseInt(String(payload.per_page || '20'), 10) || 20));

    // CueLinks v3 Publisher API
    const endpoint = `https://developers.cuelinks.com/pub_api/v3/campaigns?access_status=open&sort=epc_7d&order=desc&page=${page}&per_page=${perPage}`;

    const resp = await fetch(endpoint, {
      headers: {
        Authorization: `Token ${apiKey}`,
        Accept: 'application/json',
      },
    });
    const text = await resp.text();
    let lastErr: { status: number; body: string } | null = null;
    let items: any[] = [];

    if (!resp.ok) {
      lastErr = { status: resp.status, body: text.slice(0, 500) };
    } else {
      try {
        const data = JSON.parse(text);
        items = data.campaigns || data.data || (Array.isArray(data) ? data : []);
      } catch {
        lastErr = { status: 502, body: 'Invalid JSON from CueLinks' };
      }
    }

    if (lastErr && items.length === 0) {
      console.error('CueLinks error:', lastErr);
      return new Response(
        JSON.stringify({ error: 'Failed to fetch deals', status: lastErr.status, details: lastErr.body }),
        { status: lastErr.status, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
      );
    }

    const normalized = items
      .map(normalize)
      .filter((d): d is NormalizedDeal => d !== null)
      .filter((d) => matchesCategory(d, category));

    return new Response(
      JSON.stringify({
        deals: normalized,
        page,
        perPage,
        hasMore: items.length >= perPage,
        nextPage: items.length >= perPage ? page + 1 : null,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (e) {
    console.error('cuelinks-deals error', e);
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
