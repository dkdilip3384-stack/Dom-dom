import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

const decode = (s: string) =>
  s
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ');

const pickMeta = (html: string, patterns: RegExp[]): string | null => {
  for (const re of patterns) {
    const m = html.match(re);
    if (m && m[1]) return decode(m[1].trim());
  }
  return null;
};

const parsePrice = (raw: string | null): number | null => {
  if (!raw) return null;
  const cleaned = raw.replace(/[₹$,€£\s]/g, '').match(/[\d]+(\.[\d]+)?/);
  return cleaned ? Number(cleaned[0]) : null;
};

const guessStore = (url: string): string | null => {
  try {
    const host = new URL(url).hostname.replace(/^www\./, '');
    if (host.includes('amazon')) return 'Amazon';
    if (host.includes('flipkart')) return 'Flipkart';
    if (host.includes('meesho')) return 'Meesho';
    if (host.includes('myntra')) return 'Myntra';
    if (host.includes('ajio')) return 'Ajio';
    if (host.includes('nykaa')) return 'Nykaa';
    if (host.includes('bigbasket')) return 'BigBasket';
    if (host.includes('zepto')) return 'Zepto';
    if (host.includes('blinkit')) return 'Blinkit';
    if (host.includes('snapdeal')) return 'Snapdeal';
    if (host.includes('tatacliq')) return 'Tata CLiQ';
    if (host.includes('firstcry')) return 'FirstCry';
    return null;
  } catch {
    return null;
  }
};

const AFFILIATE_HOSTS = [
  'fktr.in', 'linkredirect.in', 'ekaro.in', 'earnkaro.com', 'cuelinks.com',
  'clnk.in', 'inrdeals.com', 'wishlink.com', 'bitli.in', 'amzn.to', 'amzn.in',
  'flipkart.com/dl', 'dl.flipkart.com', 'tinyurl.com', 'bit.ly', 'cutt.ly',
  'shorturl.at', 'dl.amazon', 'amazon.in/dp', 'fkrt.cc', 'fkrt.it',
];

const isAffiliate = (u: string) => {
  try {
    const host = new URL(u).hostname.replace(/^www\./, '');
    return AFFILIATE_HOSTS.some((h) => host.includes(h.split('/')[0]));
  } catch {
    return false;
  }
};

// Extract the real destination URL from an affiliate redirect landing page
const extractDestination = (html: string, currentUrl: string): string | null => {
  // 1. query param ?dl= or ?url= or ?u= or ?redirect=
  try {
    const u = new URL(currentUrl);
    for (const key of ['dl', 'url', 'u', 'redirect', 'r', 'to', 'target']) {
      const v = u.searchParams.get(key);
      if (v && /^https?:\/\//i.test(v)) return v;
    }
  } catch {}

  // 2. meta refresh
  const meta = html.match(/<meta[^>]+http-equiv=["']?refresh["']?[^>]+content=["'][^"']*url=([^"']+)["']/i);
  if (meta && meta[1]) return decode(meta[1]);

  // 3. JS window.location redirects
  const js = html.match(/(?:window\.location(?:\.href)?|location\.replace|location\.assign)\s*=?\s*\(?\s*["']([^"']+)["']/i);
  if (js && js[1] && /^https?:\/\//i.test(js[1])) return js[1];

  // 4. canonical link
  const canon = html.match(/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i);
  if (canon && canon[1] && /^https?:\/\//i.test(canon[1]) && !isAffiliate(canon[1])) return canon[1];

  return null;
};

const fetchHtml = async (url: string) => {
  const res = await fetch(url, {
    redirect: 'follow',
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
      'Cache-Control': 'no-cache',
    },
  });
  return { finalUrl: res.url || url, html: await res.text(), status: res.status };
};

const parseProduct = (html: string, finalUrl: string) => {
  const title = pickMeta(html, [
    /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+name=["']twitter:title["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+name=["']title["'][^>]+content=["']([^"']+)["']/i,
    /<title[^>]*>([^<]+)<\/title>/i,
    /<h1[^>]*>([^<]+)<\/h1>/i,
    /<span[^>]+id=["']productTitle["'][^>]*>([^<]+)<\/span>/i, // Amazon
    /<span[^>]+class=["'][^"']*VU-ZEz[^"']*["'][^>]*>([^<]+)<\/span>/i, // Flipkart
  ]);
  const description = pickMeta(html, [
    /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+name=["']twitter:description["'][^>]+content=["']([^"']+)["']/i,
  ]);
  const image = pickMeta(html, [
    /<meta[^>]+property=["']og:image:secure_url["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+name=["']twitter:image["'][^>]+content=["']([^"']+)["']/i,
    /<link[^>]+rel=["']image_src["'][^>]+href=["']([^"']+)["']/i,
    /"hiRes"\s*:\s*"([^"]+)"/i, // Amazon JSON
    /"large"\s*:\s*"([^"]+)"/i, // Amazon JSON
    /<img[^>]+id=["']landingImage["'][^>]+src=["']([^"']+)["']/i, // Amazon
  ]);
  const priceMeta = pickMeta(html, [
    /<meta[^>]+property=["']product:price:amount["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+property=["']og:price:amount["'][^>]+content=["']([^"']+)["']/i,
    /<meta[^>]+itemprop=["']price["'][^>]+content=["']([^"']+)["']/i,
    /"price"\s*:\s*"?([\d.,]+)"?/i,
    /"priceAmount"\s*:\s*"?([\d.,]+)"?/i,
    /class=["'][^"']*a-price-whole[^"']*["'][^>]*>([\d,]+)/i, // Amazon
    /class=["'][^"']*Nx9bqj[^"']*["'][^>]*>₹([\d,]+)/i, // Flipkart
    /class=["'][^"']*_30jeq3[^"']*["'][^>]*>₹([\d,]+)/i, // Flipkart legacy
  ]);
  const siteName = pickMeta(html, [
    /<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i,
  ]);

  const store = guessStore(finalUrl) || siteName;

  return {
    title,
    description,
    image_url: image,
    price: parsePrice(priceMeta),
    store_name: store,
  };
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { url } = await req.json();
    if (!url || typeof url !== 'string') {
      return new Response(JSON.stringify({ error: 'url required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let currentUrl = url;
    let hops = 0;
    let result: ReturnType<typeof parseProduct> | null = null;
    let lastFinalUrl = url;

    // Follow affiliate hops up to 4 times to reach the real product page
    while (hops < 4) {
      let fetched;
      try {
        fetched = await fetchHtml(currentUrl);
      } catch {
        break;
      }
      lastFinalUrl = fetched.finalUrl;
      const parsed = parseProduct(fetched.html, fetched.finalUrl);

      // If we landed on an affiliate/redirector page, try to extract the real product URL
      if (isAffiliate(fetched.finalUrl) || !parsed.image_url || guessStore(fetched.finalUrl) === null) {
        const next = extractDestination(fetched.html, fetched.finalUrl);
        if (next && next !== currentUrl && next !== fetched.finalUrl) {
          currentUrl = next;
          hops++;
          continue;
        }
      }

      result = parsed;
      break;
    }

    if (!result) result = { title: null, description: null, image_url: null, price: null, store_name: guessStore(lastFinalUrl) };

    // Fallback: use microlink public API if we couldn't extract essentials
    if ((!result.title || !result.image_url) && /^https?:\/\//.test(lastFinalUrl)) {
      try {
        const ml = await fetch(`https://api.microlink.io/?url=${encodeURIComponent(lastFinalUrl)}`);
        if (ml.ok) {
          const j = await ml.json();
          if (j?.status === 'success' && j.data) {
            const d = j.data;
            result.title = result.title || d.title || null;
            result.description = result.description || d.description || null;
            result.image_url = result.image_url || d.image?.url || d.logo?.url || null;
            result.store_name = result.store_name || (d.publisher ? String(d.publisher).split('.')[0].replace(/^\w/, (c: string) => c.toUpperCase()) : null);
          }
        }
      } catch {}
    }

    return new Response(
      JSON.stringify({
        ok: true,
        manual: !result.title && !result.image_url,
        finalUrl: lastFinalUrl,
        ...result,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  } catch (e) {
    return new Response(
      JSON.stringify({ ok: false, manual: true, error: (e as Error).message }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } },
    );
  }
});
