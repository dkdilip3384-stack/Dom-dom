import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Web Push payload encryption using Web Crypto API
async function encryptPayload(payload: string, p256dhBase64: string, authBase64: string) {
  const urlSafeToStandard = (s: string) => s.replace(/-/g, "+").replace(/_/g, "/");
  const base64ToBuffer = (b64: string) => {
    const padded = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    const binary = atob(urlSafeToStandard(padded));
    return new Uint8Array([...binary].map((c) => c.charCodeAt(0)));
  };

  const clientPublicKeyBytes = base64ToBuffer(p256dhBase64);
  const authSecret = base64ToBuffer(authBase64);

  const clientPublicKey = await crypto.subtle.importKey(
    "raw", clientPublicKeyBytes, { name: "ECDH", namedCurve: "P-256" }, false, []
  );

  const serverKeys = await crypto.subtle.generateKey(
    { name: "ECDH", namedCurve: "P-256" }, true, ["deriveBits"]
  );

  const serverPublicKeyRaw = new Uint8Array(
    await crypto.subtle.exportKey("raw", serverKeys.publicKey)
  );

  const sharedSecret = new Uint8Array(
    await crypto.subtle.deriveBits(
      { name: "ECDH", public: clientPublicKey }, serverKeys.privateKey, 256
    )
  );

  const encoder = new TextEncoder();

  const prkKey = await crypto.subtle.importKey(
    "raw", authSecret, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const prk = new Uint8Array(await crypto.subtle.sign("HMAC", prkKey, sharedSecret));

  const keyInfoBuf = new Uint8Array([...encoder.encode("Content-Encoding: aes128gcm\0"), 0x01]);
  const keyHmacKey = await crypto.subtle.importKey(
    "raw", prk, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const keyMaterial = new Uint8Array(await crypto.subtle.sign("HMAC", keyHmacKey, keyInfoBuf));
  const contentEncryptionKey = keyMaterial.slice(0, 16);

  const nonceInfoBuf = new Uint8Array([...encoder.encode("Content-Encoding: nonce\0"), 0x01]);
  const nonceHmacKey = await crypto.subtle.importKey(
    "raw", prk, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
  );
  const nonceMaterial = new Uint8Array(await crypto.subtle.sign("HMAC", nonceHmacKey, nonceInfoBuf));
  const nonce = nonceMaterial.slice(0, 12);

  const payloadBytes = encoder.encode(payload);
  const paddedPayload = new Uint8Array([...payloadBytes, 2]);

  const aesKey = await crypto.subtle.importKey(
    "raw", contentEncryptionKey, { name: "AES-GCM" }, false, ["encrypt"]
  );

  const encrypted = new Uint8Array(
    await crypto.subtle.encrypt({ name: "AES-GCM", iv: nonce }, aesKey, paddedPayload)
  );

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const rs = new Uint8Array(4);
  new DataView(rs.buffer).setUint32(0, 4096, false);

  const header = new Uint8Array([...salt, ...rs, serverPublicKeyRaw.length, ...serverPublicKeyRaw]);
  const body = new Uint8Array([...header, ...encrypted]);

  return { body, serverPublicKeyRaw };
}

function derToRaw(der: Uint8Array): Uint8Array {
  if (der.length === 64) return der;
  const raw = new Uint8Array(64);
  if (der[0] === 0x30) {
    let offset = 2;
    const rLen = der[offset + 1];
    const rStart = offset + 2 + (rLen > 32 ? 1 : 0);
    const rBytes = Math.min(rLen, 32);
    raw.set(der.slice(rStart, rStart + rBytes), 32 - rBytes);
    offset = offset + 2 + rLen;
    const sLen = der[offset + 1];
    const sStart = offset + 2 + (sLen > 32 ? 1 : 0);
    const sBytes = Math.min(sLen, 32);
    raw.set(der.slice(sStart, sStart + sBytes), 64 - sBytes);
  } else {
    return der.slice(0, 64);
  }
  return raw;
}

async function createVapidAuth(endpoint: string, publicKeyBase64: string, privateKeyBase64: string) {
  const urlSafeToStandard = (s: string) => s.replace(/-/g, "+").replace(/_/g, "/");
  const base64ToBuffer = (b64: string) => {
    const padded = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
    const binary = atob(urlSafeToStandard(padded));
    return new Uint8Array([...binary].map((c) => c.charCodeAt(0)));
  };

  const endpointUrl = new URL(endpoint);
  const audience = `${endpointUrl.protocol}//${endpointUrl.host}`;

  const header = { typ: "JWT", alg: "ES256" };
  const payload = {
    aud: audience,
    exp: Math.floor(Date.now() / 1000) + 12 * 60 * 60,
    sub: "mailto:admin@z-kanakku.app",
  };

  const encoder = new TextEncoder();
  const toBase64Url = (data: Uint8Array) =>
    btoa(String.fromCharCode(...data)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");

  const headerB64 = toBase64Url(encoder.encode(JSON.stringify(header)));
  const payloadB64 = toBase64Url(encoder.encode(JSON.stringify(payload)));
  const unsignedToken = `${headerB64}.${payloadB64}`;

  const privateKeyBytes = base64ToBuffer(privateKeyBase64);
  const publicKeyBytes = base64ToBuffer(publicKeyBase64);

  const jwk = {
    kty: "EC",
    crv: "P-256",
    x: toBase64Url(publicKeyBytes.slice(1, 33)),
    y: toBase64Url(publicKeyBytes.slice(33, 65)),
    d: privateKeyBase64,
  };

  const key = await crypto.subtle.importKey(
    "jwk", jwk, { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]
  );

  const signature = new Uint8Array(
    await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, encoder.encode(unsignedToken))
  );

  const rawSignature = derToRaw(signature);
  const signatureB64 = toBase64Url(rawSignature);
  const jwt = `${unsignedToken}.${signatureB64}`;
  const publicKeyUrlSafe = toBase64Url(publicKeyBytes);

  return { authorization: `vapid t=${jwt}, k=${publicKeyUrlSafe}` };
}

async function sendPushNotification(
  subscription: { endpoint: string; p256dh: string; auth_key: string },
  payload: object,
  vapidPublicKey: string,
  vapidPrivateKey: string
) {
  const payloadStr = JSON.stringify(payload);
  try {
    const { body } = await encryptPayload(payloadStr, subscription.p256dh, subscription.auth_key);
    const { authorization } = await createVapidAuth(subscription.endpoint, vapidPublicKey, vapidPrivateKey);

    const response = await fetch(subscription.endpoint, {
      method: "POST",
      headers: {
        Authorization: authorization,
        "Content-Encoding": "aes128gcm",
        "Content-Type": "application/octet-stream",
        TTL: "86400",
        Urgency: "normal",
      },
      body,
    });

    if (!response.ok) {
      throw new Error(`Push failed [${response.status}]`);
    }
    return { success: true };
  } catch (error) {
    console.error("Push send error:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown" };
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Validate JWT - require authenticated user (or cron caller with anon key)
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!);
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await anonClient.auth.getUser(token);
    
    // Allow if authenticated user OR if token matches anon key (cron job)
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") || "";
    const isCronCall = token === anonKey;
    
    if (!isCronCall && (authError || !user)) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Read VAPID keys from app_settings
    const { data: vapidPubSetting } = await supabase
      .from("app_settings").select("value").eq("key", "vapid_public_key").is("room_id", null).single();
    const { data: vapidPrivSetting } = await supabase
      .from("app_settings").select("value").eq("key", "vapid_private_key").is("room_id", null).single();

    if (!vapidPubSetting?.value || !vapidPrivSetting?.value) {
      return new Response(
        JSON.stringify({ error: "VAPID keys not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const vapidPublicKey = vapidPubSetting.value;
    const vapidPrivateKey = vapidPrivSetting.value;

    // Check if it's the right time
    const { data: timeSetting } = await supabase
      .from("app_settings").select("value").eq("key", "notification_time").is("room_id", null).single();
    
    const configuredTime = timeSetting?.value || "08:00";
    const now = new Date();
    const istOffset = 5.5 * 60 * 60 * 1000;
    const istNow = new Date(now.getTime() + istOffset);
    const currentHour = istNow.getUTCHours();
    const currentMinute = istNow.getUTCMinutes();
    const [targetHour, targetMinute] = configuredTime.split(":").map(Number);

    const currentTotalMin = currentHour * 60 + currentMinute;
    const targetTotalMin = targetHour * 60 + targetMinute;
    const diff = Math.abs(currentTotalMin - targetTotalMin);

    let forceRun = false;
    try {
      const body = await req.json();
      forceRun = body?.force === true;
    } catch { /* no body */ }

    if (!forceRun && !isCronCall && diff > 30) {
      return new Response(
        JSON.stringify({ message: "Not time yet" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Get all duty assignments
    const { data: assignments, error: assignError } = await supabase
      .from("duty_assignments").select("*").order("duty_order", { ascending: true });

    if (assignError) throw assignError;
    if (!assignments?.length) {
      return new Response(
        JSON.stringify({ message: "No duty assignments found" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const dutyTypes = ["Cooking", "Trash", "Water"];
    const results: Array<{ dutyType: string; friendName: string; pushSent: boolean }> = [];

    for (const dutyType of dutyTypes) {
      const dutyAssignments = assignments
        .filter((a: any) => a.duty_type === dutyType)
        .sort((a: any, b: any) => a.duty_order - b.duty_order);

      if (dutyAssignments.length === 0) continue;

      const currentIndex = dutyAssignments[0]?.current_index || 0;
      const normalizedIndex = currentIndex % dutyAssignments.length;
      const assignedFriendId = dutyAssignments[normalizedIndex]?.friend_id;
      if (!assignedFriendId) continue;

      const { data: friend } = await supabase
        .from("friends").select("name, user_id, room_id").eq("id", assignedFriendId).single();
      if (!friend) continue;

      const message = `Hi ${friend.name}, Today is your ${dutyType} duty!`;

      const targetUserId = friend.user_id;

      await supabase.from("notifications").insert({
        user_id: targetUserId,
        room_id: friend.room_id,
        type: "duty_reminder",
        message,
        expense_description: dutyType,
      });

      let pushSent = false;
      if (targetUserId) {
        const { data: subscriptions } = await supabase
          .from("push_subscriptions").select("*").eq("user_id", targetUserId);

        for (const sub of subscriptions || []) {
          const result = await sendPushNotification(
            sub,
            {
              title: `${dutyType} Duty Reminder`,
              body: message,
              tag: `duty-${dutyType}-${new Date().toISOString().split("T")[0]}`,
            },
            vapidPublicKey,
            vapidPrivateKey
          );

          if (result.success) {
            pushSent = true;
          } else if (result.error?.includes("404") || result.error?.includes("410")) {
            await supabase.from("push_subscriptions").delete().eq("id", sub.id);
          }
        }
      }

      results.push({ dutyType, friendName: friend.name, pushSent });
    }

    return new Response(JSON.stringify({ sent: results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error sending duty notifications:", error);
    return new Response(
      JSON.stringify({ error: "Failed to send notifications" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
