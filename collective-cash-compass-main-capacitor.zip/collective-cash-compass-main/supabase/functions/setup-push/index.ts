import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Validate JWT - require authenticated user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Missing authorization" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const anonClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!);
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await anonClient.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseKey);

    // Check if VAPID keys already exist
    const { data: existing } = await supabase
      .from("app_settings")
      .select("value")
      .eq("key", "vapid_public_key")
      .is("room_id", null)
      .single();

    if (existing?.value) {
      return new Response(
        JSON.stringify({
          message: "VAPID keys already configured",
          publicKey: existing.value,
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Generate VAPID key pair using Web Crypto API (ECDSA P-256)
    const keyPair = await crypto.subtle.generateKey(
      { name: "ECDSA", namedCurve: "P-256" },
      true,
      ["sign"]
    );

    const publicKeyBuffer = await crypto.subtle.exportKey("raw", keyPair.publicKey);
    const publicKeyBase64 = btoa(String.fromCharCode(...new Uint8Array(publicKeyBuffer)))
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");

    const privateKeyJwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);
    const privateKeyBase64 = privateKeyJwk.d!;

    // Store both keys in app_settings (no manual secret needed)
    await supabase.from("app_settings").upsert(
      { key: "vapid_public_key", value: publicKeyBase64 },
      { onConflict: "key" }
    );

    await supabase.from("app_settings").upsert(
      { key: "vapid_private_key", value: privateKeyBase64 },
      { onConflict: "key" }
    );

    await supabase.from("app_settings").upsert(
      { key: "notification_time", value: "08:00" },
      { onConflict: "key" }
    );

    return new Response(
      JSON.stringify({
        message: "VAPID keys generated and stored automatically!",
        publicKey: publicKeyBase64,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error generating VAPID keys:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
