-- Add a column to track when each duty was last completed
-- This allows independent rotation per duty type
ALTER TABLE public.duty_assignments 
ADD COLUMN last_completed_at timestamp with time zone DEFAULT NULL;

-- Add current_index to track the current position in the rotation
-- This allows completion-based rotation instead of date-based
ALTER TABLE public.duty_assignments 
ADD COLUMN current_index integer DEFAULT 0;