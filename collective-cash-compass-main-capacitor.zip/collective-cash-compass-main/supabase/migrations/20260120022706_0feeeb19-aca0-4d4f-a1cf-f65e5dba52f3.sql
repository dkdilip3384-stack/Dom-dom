-- =====================================================
-- SECURITY FIX: Address all 3 error-level security issues
-- 1. PUBLIC_DATA_EXPOSURE - Restrict destructive operations to admins
-- 2. CLIENT_SIDE_AUTH - Enforce admin roles at RLS level using has_role()
-- 3. STORAGE_EXPOSURE - Make receipts bucket private
-- =====================================================

-- =====================================================
-- FIX 1 & 2: Update RLS policies to enforce admin-only modifications
-- Keep SELECT policies permissive for all authenticated users
-- Restrict INSERT to authenticated users
-- Restrict UPDATE/DELETE to admins only
-- =====================================================

-- EXPENSES TABLE
DROP POLICY IF EXISTS "Anyone can update expenses" ON public.expenses;
DROP POLICY IF EXISTS "Anyone can delete expenses" ON public.expenses;
DROP POLICY IF EXISTS "Anyone can insert expenses" ON public.expenses;
DROP POLICY IF EXISTS "Anyone can view expenses" ON public.expenses;

-- Authenticated users can view all expenses (shared tracker)
CREATE POLICY "Authenticated users can view expenses"
ON public.expenses FOR SELECT
TO authenticated
USING (true);

-- Authenticated users can insert expenses
CREATE POLICY "Authenticated users can insert expenses"
ON public.expenses FOR INSERT
TO authenticated
WITH CHECK (true);

-- Only admins can update expenses
CREATE POLICY "Admins can update expenses"
ON public.expenses FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete expenses
CREATE POLICY "Admins can delete expenses"
ON public.expenses FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- EXPENSE_SPLITS TABLE
DROP POLICY IF EXISTS "Anyone can delete expense splits" ON public.expense_splits;
DROP POLICY IF EXISTS "Anyone can insert expense splits" ON public.expense_splits;
DROP POLICY IF EXISTS "Anyone can view expense splits" ON public.expense_splits;

-- Authenticated users can view all expense splits
CREATE POLICY "Authenticated users can view expense splits"
ON public.expense_splits FOR SELECT
TO authenticated
USING (true);

-- Authenticated users can insert expense splits
CREATE POLICY "Authenticated users can insert expense splits"
ON public.expense_splits FOR INSERT
TO authenticated
WITH CHECK (true);

-- Only admins can delete expense splits
CREATE POLICY "Admins can delete expense splits"
ON public.expense_splits FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Add UPDATE policy for expense splits (was missing)
CREATE POLICY "Admins can update expense splits"
ON public.expense_splits FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- FRIENDS TABLE
DROP POLICY IF EXISTS "Anyone can update friends" ON public.friends;
DROP POLICY IF EXISTS "Anyone can view friends" ON public.friends;

-- Authenticated users can view all friends
CREATE POLICY "Authenticated users can view friends"
ON public.friends FOR SELECT
TO authenticated
USING (true);

-- Only admins can insert friends
CREATE POLICY "Admins can insert friends"
ON public.friends FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can update friends
CREATE POLICY "Admins can update friends"
ON public.friends FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete friends
CREATE POLICY "Admins can delete friends"
ON public.friends FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- NOTIFICATIONS TABLE - Make user-specific
DROP POLICY IF EXISTS "Anyone can delete notifications" ON public.notifications;
DROP POLICY IF EXISTS "Anyone can insert notifications" ON public.notifications;
DROP POLICY IF EXISTS "Anyone can update notifications" ON public.notifications;
DROP POLICY IF EXISTS "Anyone can view notifications" ON public.notifications;

-- Users can only view their own notifications
CREATE POLICY "Users can view their own notifications"
ON public.notifications FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Authenticated users can insert notifications (for any user - needed for admin notifications)
CREATE POLICY "Authenticated users can insert notifications"
ON public.notifications FOR INSERT
TO authenticated
WITH CHECK (true);

-- Users can only update their own notifications (mark as read)
CREATE POLICY "Users can update their own notifications"
ON public.notifications FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Users can only delete their own notifications
CREATE POLICY "Users can delete their own notifications"
ON public.notifications FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- =====================================================
-- FIX 3: Make receipts storage bucket private
-- =====================================================

-- Update bucket to private
UPDATE storage.buckets 
SET public = false 
WHERE id = 'receipts';

-- Drop existing permissive policies
DROP POLICY IF EXISTS "Anyone can view receipts" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can upload receipts" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can update receipts" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can delete receipts" ON storage.objects;

-- Create authenticated-only policies
CREATE POLICY "Authenticated users can view receipts" 
ON storage.objects FOR SELECT 
TO authenticated
USING (bucket_id = 'receipts');

CREATE POLICY "Authenticated users can upload receipts" 
ON storage.objects FOR INSERT 
TO authenticated
WITH CHECK (bucket_id = 'receipts');

-- Only admins can delete receipts (to prevent tampering)
CREATE POLICY "Admins can delete receipts" 
ON storage.objects FOR DELETE 
TO authenticated
USING (
  bucket_id = 'receipts' 
  AND public.has_role(auth.uid(), 'admin')
);