
-- Create rooms table first
CREATE TABLE public.rooms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;

-- Create room_members table
CREATE TABLE public.room_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  room_id uuid NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  display_name text NOT NULL,
  is_admin boolean NOT NULL DEFAULT false,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(room_id, user_id)
);

ALTER TABLE public.room_members ENABLE ROW LEVEL SECURITY;

-- Now create functions that reference the tables
CREATE OR REPLACE FUNCTION public.is_room_member(_user_id uuid, _room_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.room_members
    WHERE user_id = _user_id AND room_id = _room_id
  )
$$;

CREATE OR REPLACE FUNCTION public.is_room_admin(_user_id uuid, _room_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.room_members
    WHERE user_id = _user_id AND room_id = _room_id AND is_admin = true
  )
$$;

-- Generate unique 6-char alphanumeric room code
CREATE OR REPLACE FUNCTION public.generate_room_code()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  result text := '';
  i integer;
BEGIN
  LOOP
    result := '';
    FOR i IN 1..6 LOOP
      result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
    END LOOP;
    IF NOT EXISTS (SELECT 1 FROM public.rooms WHERE code = result) THEN
      RETURN result;
    END IF;
  END LOOP;
END;
$$;

-- Add code column to rooms
ALTER TABLE public.rooms ADD COLUMN code text NOT NULL UNIQUE DEFAULT public.generate_room_code();

-- RLS for rooms
CREATE POLICY "Users can view rooms they belong to"
ON public.rooms FOR SELECT TO authenticated
USING (public.is_room_member(auth.uid(), id));

CREATE POLICY "Authenticated users can create rooms"
ON public.rooms FOR INSERT TO authenticated
WITH CHECK (auth.uid() = created_by);

-- RLS for room_members
CREATE POLICY "Members can view room members"
ON public.room_members FOR SELECT TO authenticated
USING (public.is_room_member(auth.uid(), room_id));

CREATE POLICY "Users can join rooms (insert themselves)"
ON public.room_members FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Room admins can delete members"
ON public.room_members FOR DELETE TO authenticated
USING (public.is_room_admin(auth.uid(), room_id));

CREATE POLICY "Members can update own display name"
ON public.room_members FOR UPDATE TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Add room_id to existing tables
ALTER TABLE public.friends ADD COLUMN room_id uuid REFERENCES public.rooms(id) ON DELETE CASCADE;
ALTER TABLE public.friends ADD COLUMN user_id uuid;
ALTER TABLE public.expenses ADD COLUMN room_id uuid REFERENCES public.rooms(id) ON DELETE CASCADE;
ALTER TABLE public.expense_splits ADD COLUMN room_id uuid REFERENCES public.rooms(id) ON DELETE CASCADE;
ALTER TABLE public.duty_assignments ADD COLUMN room_id uuid REFERENCES public.rooms(id) ON DELETE CASCADE;
ALTER TABLE public.notifications ADD COLUMN room_id uuid REFERENCES public.rooms(id) ON DELETE CASCADE;
ALTER TABLE public.app_settings ADD COLUMN room_id uuid REFERENCES public.rooms(id) ON DELETE CASCADE;

-- Drop old RLS policies on friends
DROP POLICY IF EXISTS "Authenticated users can view friends" ON public.friends;
DROP POLICY IF EXISTS "Admins can insert friends" ON public.friends;
DROP POLICY IF EXISTS "Admins can update friends" ON public.friends;
DROP POLICY IF EXISTS "Admins can delete friends" ON public.friends;

CREATE POLICY "Room members can view friends" ON public.friends FOR SELECT TO authenticated USING (public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room admins can insert friends" ON public.friends FOR INSERT TO authenticated WITH CHECK (public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can update friends" ON public.friends FOR UPDATE TO authenticated USING (public.is_room_admin(auth.uid(), room_id)) WITH CHECK (public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can delete friends" ON public.friends FOR DELETE TO authenticated USING (public.is_room_admin(auth.uid(), room_id));

-- Drop old RLS policies on expenses
DROP POLICY IF EXISTS "Authenticated users can view expenses" ON public.expenses;
DROP POLICY IF EXISTS "Authenticated users can insert expenses" ON public.expenses;
DROP POLICY IF EXISTS "Admins can update expenses" ON public.expenses;
DROP POLICY IF EXISTS "Admins can delete expenses" ON public.expenses;

CREATE POLICY "Room members can view expenses" ON public.expenses FOR SELECT TO authenticated USING (public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room members can insert expenses" ON public.expenses FOR INSERT TO authenticated WITH CHECK (public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room admins can update expenses" ON public.expenses FOR UPDATE TO authenticated USING (public.is_room_admin(auth.uid(), room_id)) WITH CHECK (public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can delete expenses" ON public.expenses FOR DELETE TO authenticated USING (public.is_room_admin(auth.uid(), room_id));

-- Drop old RLS policies on expense_splits
DROP POLICY IF EXISTS "Authenticated users can view expense splits" ON public.expense_splits;
DROP POLICY IF EXISTS "Authenticated users can insert expense splits" ON public.expense_splits;
DROP POLICY IF EXISTS "Admins can update expense splits" ON public.expense_splits;
DROP POLICY IF EXISTS "Admins can delete expense splits" ON public.expense_splits;

CREATE POLICY "Room members can view expense splits" ON public.expense_splits FOR SELECT TO authenticated USING (public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room members can insert expense splits" ON public.expense_splits FOR INSERT TO authenticated WITH CHECK (public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room admins can update expense splits" ON public.expense_splits FOR UPDATE TO authenticated USING (public.is_room_admin(auth.uid(), room_id)) WITH CHECK (public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can delete expense splits" ON public.expense_splits FOR DELETE TO authenticated USING (public.is_room_admin(auth.uid(), room_id));

-- Drop old RLS policies on duty_assignments
DROP POLICY IF EXISTS "All authenticated users can view duty assignments" ON public.duty_assignments;
DROP POLICY IF EXISTS "Admins can insert duty assignments" ON public.duty_assignments;
DROP POLICY IF EXISTS "Admins can update duty assignments" ON public.duty_assignments;
DROP POLICY IF EXISTS "Admins can delete duty assignments" ON public.duty_assignments;

CREATE POLICY "Room members can view duty assignments" ON public.duty_assignments FOR SELECT TO authenticated USING (public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room admins can insert duty assignments" ON public.duty_assignments FOR INSERT TO authenticated WITH CHECK (public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can update duty assignments" ON public.duty_assignments FOR UPDATE TO authenticated USING (public.is_room_admin(auth.uid(), room_id)) WITH CHECK (public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can delete duty assignments" ON public.duty_assignments FOR DELETE TO authenticated USING (public.is_room_admin(auth.uid(), room_id));

-- Drop old RLS policies on notifications
DROP POLICY IF EXISTS "Users can view own or global notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can insert own or admin can insert any notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update own or global notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can delete own or global notifications" ON public.notifications;

CREATE POLICY "Room members can view notifications" ON public.notifications FOR SELECT TO authenticated USING (room_id IS NULL OR public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room members can insert notifications" ON public.notifications FOR INSERT TO authenticated WITH CHECK (room_id IS NULL OR public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Users can update own notifications" ON public.notifications FOR UPDATE TO authenticated USING (user_id IS NULL OR user_id = auth.uid()) WITH CHECK (user_id IS NULL OR user_id = auth.uid());
CREATE POLICY "Users can delete own notifications" ON public.notifications FOR DELETE TO authenticated USING (user_id IS NULL OR user_id = auth.uid());

-- Drop old RLS policies on app_settings
DROP POLICY IF EXISTS "Authenticated users can read app settings" ON public.app_settings;
DROP POLICY IF EXISTS "Admins can insert app settings" ON public.app_settings;
DROP POLICY IF EXISTS "Admins can update app settings" ON public.app_settings;
DROP POLICY IF EXISTS "Admins can delete app settings" ON public.app_settings;

CREATE POLICY "Room members can read app settings" ON public.app_settings FOR SELECT TO authenticated USING (room_id IS NULL OR public.is_room_member(auth.uid(), room_id));
CREATE POLICY "Room admins can insert app settings" ON public.app_settings FOR INSERT TO authenticated WITH CHECK (room_id IS NULL OR public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can update app settings" ON public.app_settings FOR UPDATE TO authenticated USING (room_id IS NULL OR public.is_room_admin(auth.uid(), room_id));
CREATE POLICY "Room admins can delete app settings" ON public.app_settings FOR DELETE TO authenticated USING (room_id IS NULL OR public.is_room_admin(auth.uid(), room_id));
