-- Add CHECK constraints for input validation on expenses
ALTER TABLE public.expenses
  ADD CONSTRAINT expenses_amount_positive CHECK (amount > 0),
  ADD CONSTRAINT expenses_description_length CHECK (char_length(description) BETWEEN 1 AND 500);

-- Add CHECK constraint on expense_splits
ALTER TABLE public.expense_splits
  ADD CONSTRAINT splits_amount_positive CHECK (share_amount > 0);

-- Fix notification INSERT policy to restrict to own user or admins
DROP POLICY IF EXISTS "All authenticated users can insert notifications" ON public.notifications;
CREATE POLICY "Users can insert own or admin can insert any notifications"
ON public.notifications FOR INSERT
TO authenticated
WITH CHECK (
  user_id IS NULL OR user_id = auth.uid() OR public.has_role(auth.uid(), 'admin')
);