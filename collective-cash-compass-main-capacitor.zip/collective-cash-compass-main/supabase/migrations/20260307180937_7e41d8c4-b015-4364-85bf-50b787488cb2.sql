
-- Tighten expenses INSERT: require authenticated user (explicit check replaces bare true)
DROP POLICY IF EXISTS "Authenticated users can insert expenses" ON public.expenses;
CREATE POLICY "Authenticated users can insert expenses"
ON public.expenses FOR INSERT
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL);

-- Tighten expense_splits INSERT: same approach
DROP POLICY IF EXISTS "Authenticated users can insert expense splits" ON public.expense_splits;
CREATE POLICY "Authenticated users can insert expense splits"
ON public.expense_splits FOR INSERT
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL);
