-- Add columns for split payment tracking
ALTER TABLE public.expenses 
ADD COLUMN online_amount numeric DEFAULT NULL,
ADD COLUMN cash_amount numeric DEFAULT NULL,
ADD COLUMN payment_mode text DEFAULT 'single' CHECK (payment_mode IN ('single', 'split'));