
CREATE TABLE public.custom_deals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category TEXT NOT NULL DEFAULT 'all',
  title TEXT NOT NULL,
  description TEXT,
  merchant TEXT,
  image_url TEXT,
  discount_label TEXT,
  offer_price NUMERIC(10,2),
  original_price NUMERIC(10,2),
  url TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.custom_deals TO authenticated;
GRANT ALL ON public.custom_deals TO service_role;

ALTER TABLE public.custom_deals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Room members can view custom deals"
  ON public.custom_deals FOR SELECT TO authenticated
  USING (public.is_room_member(auth.uid(), room_id));

CREATE POLICY "Room admins can insert custom deals"
  ON public.custom_deals FOR INSERT TO authenticated
  WITH CHECK (public.is_room_admin(auth.uid(), room_id) AND created_by = auth.uid());

CREATE POLICY "Room admins can update custom deals"
  ON public.custom_deals FOR UPDATE TO authenticated
  USING (public.is_room_admin(auth.uid(), room_id))
  WITH CHECK (public.is_room_admin(auth.uid(), room_id));

CREATE POLICY "Room admins can delete custom deals"
  ON public.custom_deals FOR DELETE TO authenticated
  USING (public.is_room_admin(auth.uid(), room_id));

CREATE TRIGGER update_custom_deals_updated_at
  BEFORE UPDATE ON public.custom_deals
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE INDEX idx_custom_deals_room_category ON public.custom_deals(room_id, category, created_at DESC);
