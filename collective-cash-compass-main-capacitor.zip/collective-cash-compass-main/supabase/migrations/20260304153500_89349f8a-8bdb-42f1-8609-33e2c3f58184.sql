-- Make audio bucket private
UPDATE storage.buckets SET public = false WHERE id = 'audio';

-- Add storage policy for authenticated users to read audio files (if not exists)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE policyname = 'Authenticated users can read audio files' AND tablename = 'objects'
  ) THEN
    CREATE POLICY "Authenticated users can read audio files"
    ON storage.objects FOR SELECT
    TO authenticated
    USING (bucket_id = 'audio');
  END IF;
END $$;