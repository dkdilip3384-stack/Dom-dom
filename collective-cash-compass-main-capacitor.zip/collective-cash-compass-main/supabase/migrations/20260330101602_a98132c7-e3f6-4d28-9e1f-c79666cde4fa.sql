
-- Create a secure function to delete a room and all associated data
-- Only the room creator (admin) can delete the room
CREATE OR REPLACE FUNCTION public.delete_room(_room_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid := auth.uid();
BEGIN
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Verify the user is the room creator
  IF NOT EXISTS (SELECT 1 FROM public.rooms WHERE id = _room_id AND created_by = _user_id) THEN
    RAISE EXCEPTION 'Only the room creator can delete the room';
  END IF;

  -- Delete all associated data in correct order
  DELETE FROM public.expense_splits WHERE room_id = _room_id;
  DELETE FROM public.expenses WHERE room_id = _room_id;
  DELETE FROM public.duty_assignments WHERE room_id = _room_id;
  DELETE FROM public.notifications WHERE room_id = _room_id;
  DELETE FROM public.app_settings WHERE room_id = _room_id;
  DELETE FROM public.friends WHERE room_id = _room_id;
  DELETE FROM public.room_members WHERE room_id = _room_id;
  DELETE FROM public.rooms WHERE id = _room_id AND created_by = _user_id;

  RETURN true;
END;
$$;
