-- Make user_id nullable for global notifications
ALTER TABLE public.notifications ALTER COLUMN user_id DROP NOT NULL;

-- Drop existing RLS policies
DROP POLICY IF EXISTS "Users can view their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Authenticated users can insert notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update their own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can delete their own notifications" ON public.notifications;

-- Create new policies for global notification visibility
CREATE POLICY "All authenticated users can view all notifications"
ON public.notifications
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "All authenticated users can insert notifications"
ON public.notifications
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "All authenticated users can update notifications"
ON public.notifications
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "All authenticated users can delete notifications"
ON public.notifications
FOR DELETE
TO authenticated
USING (true);