
-- Seed owner as super_admin (look up by email once, then use user_id forever)
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'super_admin'::public.app_role
FROM auth.users
WHERE lower(email) = 'dkdilip3384@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

-- Rewrite is_super_admin to use role table
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'super_admin'::public.app_role)
$$;

-- Protect super_admin role from being granted/removed by non-super-admins
CREATE OR REPLACE FUNCTION public.protect_super_admin_role()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (TG_OP = 'INSERT' AND NEW.role = 'super_admin'::public.app_role)
     OR (TG_OP = 'DELETE' AND OLD.role = 'super_admin'::public.app_role)
     OR (TG_OP = 'UPDATE' AND (OLD.role = 'super_admin'::public.app_role OR NEW.role = 'super_admin'::public.app_role)) THEN
    IF NOT public.has_role(auth.uid(), 'super_admin'::public.app_role) THEN
      RAISE EXCEPTION 'Only a super admin can modify super_admin role assignments';
    END IF;
  END IF;
  RETURN COALESCE(NEW, OLD);
END;
$$;

DROP TRIGGER IF EXISTS protect_super_admin_role_trg ON public.user_roles;
CREATE TRIGGER protect_super_admin_role_trg
BEFORE INSERT OR UPDATE OR DELETE ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.protect_super_admin_role();

-- =================== Audit log (create first so triggers can write to it) ===================
CREATE TABLE public.admin_audit_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  actor_id UUID,
  actor_email TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  before JSONB,
  after JSONB,
  status TEXT NOT NULL DEFAULT 'success',
  ip TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.admin_audit_log TO authenticated;
GRANT ALL ON public.admin_audit_log TO service_role;
ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "super admin can read audit log"
  ON public.admin_audit_log FOR SELECT TO authenticated
  USING (public.is_super_admin());
-- No INSERT/UPDATE/DELETE policies for clients; triggers (SECURITY DEFINER) and service_role write.

-- Shared audit-writer trigger function
CREATE OR REPLACE FUNCTION public.log_admin_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _email TEXT := lower(coalesce((auth.jwt() ->> 'email'), ''));
BEGIN
  INSERT INTO public.admin_audit_log (actor_id, actor_email, action, entity, entity_id, before, after)
  VALUES (
    auth.uid(),
    NULLIF(_email, ''),
    TG_OP,
    TG_TABLE_NAME,
    COALESCE(NEW.id::text, OLD.id::text),
    CASE WHEN TG_OP IN ('UPDATE','DELETE') THEN to_jsonb(OLD) END,
    CASE WHEN TG_OP IN ('UPDATE','INSERT') THEN to_jsonb(NEW) END
  );
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- =================== FAQs ===================
CREATE TABLE public.faqs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  lang TEXT NOT NULL DEFAULT 'en',
  display_order INT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','hidden')),
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.faqs TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.faqs TO authenticated;
GRANT ALL ON public.faqs TO service_role;
ALTER TABLE public.faqs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public reads published faqs" ON public.faqs FOR SELECT USING (status = 'published' OR public.is_super_admin());
CREATE POLICY "super admin manages faqs" ON public.faqs FOR ALL TO authenticated
  USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());
CREATE TRIGGER update_faqs_updated_at BEFORE UPDATE ON public.faqs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER audit_faqs AFTER INSERT OR UPDATE OR DELETE ON public.faqs
  FOR EACH ROW EXECUTE FUNCTION public.log_admin_change();

-- =================== Contact methods ===================
CREATE TABLE public.contact_methods (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('email','phone','whatsapp','hours','other')),
  label TEXT NOT NULL,
  value TEXT NOT NULL,
  display_order INT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','hidden')),
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.contact_methods TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.contact_methods TO authenticated;
GRANT ALL ON public.contact_methods TO service_role;
ALTER TABLE public.contact_methods ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public reads published contacts" ON public.contact_methods FOR SELECT USING (status = 'published' OR public.is_super_admin());
CREATE POLICY "super admin manages contacts" ON public.contact_methods FOR ALL TO authenticated
  USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());
CREATE TRIGGER update_contact_methods_updated_at BEFORE UPDATE ON public.contact_methods
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER audit_contact_methods AFTER INSERT OR UPDATE OR DELETE ON public.contact_methods
  FOR EACH ROW EXECUTE FUNCTION public.log_admin_change();

-- =================== About sections ===================
CREATE TABLE public.about_sections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  lang TEXT NOT NULL DEFAULT 'en',
  display_order INT NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','hidden')),
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.about_sections TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.about_sections TO authenticated;
GRANT ALL ON public.about_sections TO service_role;
ALTER TABLE public.about_sections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public reads published about" ON public.about_sections FOR SELECT USING (status = 'published' OR public.is_super_admin());
CREATE POLICY "super admin manages about" ON public.about_sections FOR ALL TO authenticated
  USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());
CREATE TRIGGER update_about_sections_updated_at BEFORE UPDATE ON public.about_sections
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER audit_about_sections AFTER INSERT OR UPDATE OR DELETE ON public.about_sections
  FOR EACH ROW EXECUTE FUNCTION public.log_admin_change();

-- =================== Legal documents ===================
CREATE TABLE public.legal_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('privacy','terms')),
  version TEXT NOT NULL,
  title TEXT,
  summary TEXT,
  content TEXT NOT NULL,
  lang TEXT NOT NULL DEFAULT 'en',
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','archived','unpublished')),
  effective_date DATE,
  published_at TIMESTAMPTZ,
  previous_version_id UUID REFERENCES public.legal_documents(id),
  created_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.legal_documents TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.legal_documents TO authenticated;
GRANT ALL ON public.legal_documents TO service_role;
ALTER TABLE public.legal_documents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public reads published legal" ON public.legal_documents FOR SELECT USING (status = 'published' OR public.is_super_admin());
CREATE POLICY "super admin manages legal" ON public.legal_documents FOR ALL TO authenticated
  USING (public.is_super_admin()) WITH CHECK (public.is_super_admin());
CREATE TRIGGER update_legal_documents_updated_at BEFORE UPDATE ON public.legal_documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER audit_legal_documents AFTER INSERT OR UPDATE OR DELETE ON public.legal_documents
  FOR EACH ROW EXECUTE FUNCTION public.log_admin_change();

-- =================== Legal acceptances ===================
CREATE TABLE public.legal_acceptances (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  document_id UUID NOT NULL REFERENCES public.legal_documents(id) ON DELETE CASCADE,
  accepted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, document_id)
);
GRANT SELECT, INSERT ON public.legal_acceptances TO authenticated;
GRANT ALL ON public.legal_acceptances TO service_role;
ALTER TABLE public.legal_acceptances ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user sees own acceptances" ON public.legal_acceptances FOR SELECT TO authenticated
  USING (auth.uid() = user_id OR public.is_super_admin());
CREATE POLICY "user records own acceptance" ON public.legal_acceptances FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Client RPC to record failed access / login events into audit log
CREATE OR REPLACE FUNCTION public.log_admin_event(_action TEXT, _entity TEXT, _status TEXT DEFAULT 'success', _detail JSONB DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.admin_audit_log (actor_id, actor_email, action, entity, status, after)
  VALUES (auth.uid(), lower(coalesce((auth.jwt() ->> 'email'), '')), _action, _entity, _status, _detail);
END;
$$;
REVOKE ALL ON FUNCTION public.log_admin_event(TEXT, TEXT, TEXT, JSONB) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.log_admin_event(TEXT, TEXT, TEXT, JSONB) TO authenticated;
