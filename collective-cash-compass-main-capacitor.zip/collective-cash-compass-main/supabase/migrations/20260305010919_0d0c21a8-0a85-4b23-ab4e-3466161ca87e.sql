-- Fix notifications: restrict SELECT to own notifications or global (user_id IS NULL)
DROP POLICY IF EXISTS "All authenticated users can view all notifications" ON public.notifications;
CREATE POLICY "Users can view own or global notifications"
ON public.notifications FOR SELECT
TO authenticated
USING (user_id IS NULL OR user_id = auth.uid());

-- Fix notifications: restrict UPDATE to own notifications or global
DROP POLICY IF EXISTS "All authenticated users can update notifications" ON public.notifications;
CREATE POLICY "Users can update own or global notifications"
ON public.notifications FOR UPDATE
TO authenticated
USING (user_id IS NULL OR user_id = auth.uid())
WITH CHECK (user_id IS NULL OR user_id = auth.uid());

-- Fix notifications: restrict DELETE to own notifications or global
DROP POLICY IF EXISTS "All authenticated users can delete notifications" ON public.notifications;
CREATE POLICY "Users can delete own or global notifications"
ON public.notifications FOR DELETE
TO authenticated
USING (user_id IS NULL OR user_id = auth.uid());

-- Fix app_settings: restrict SELECT to authenticated users only
DROP POLICY IF EXISTS "Anyone can read app settings" ON public.app_settings;
CREATE POLICY "Authenticated users can read app settings"
ON public.app_settings FOR SELECT
TO authenticated
USING (true);