
-- Function to look up room ID by code (accessible without being a member)
CREATE OR REPLACE FUNCTION public.get_room_id_by_code(_code text)
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.rooms WHERE code = _code LIMIT 1
$$;
