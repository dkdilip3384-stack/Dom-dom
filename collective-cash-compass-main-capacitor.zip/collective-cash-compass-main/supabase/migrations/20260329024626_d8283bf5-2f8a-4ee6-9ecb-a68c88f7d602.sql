
-- 1. Create a secure join_room_by_code function that validates room code before inserting member
CREATE OR REPLACE FUNCTION public.join_room_by_code(_code text, _display_name text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _room_id uuid;
  _user_id uuid := auth.uid();
BEGIN
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Validate inputs
  IF _code IS NULL OR length(trim(_code)) = 0 THEN
    RAISE EXCEPTION 'Room code is required';
  END IF;
  IF _display_name IS NULL OR length(trim(_display_name)) = 0 THEN
    RAISE EXCEPTION 'Display name is required';
  END IF;
  IF length(_display_name) > 100 THEN
    RAISE EXCEPTION 'Display name too long';
  END IF;

  -- Find the room by code
  SELECT id INTO _room_id FROM public.rooms WHERE code = upper(trim(_code));
  IF _room_id IS NULL THEN
    RAISE EXCEPTION 'Room not found';
  END IF;

  -- Check if already a member
  IF EXISTS (SELECT 1 FROM public.room_members WHERE room_id = _room_id AND user_id = _user_id) THEN
    RAISE EXCEPTION 'Already a member of this room';
  END IF;

  -- Insert member
  INSERT INTO public.room_members (room_id, user_id, display_name, is_admin)
  VALUES (_room_id, _user_id, trim(_display_name), false);

  RETURN _room_id;
END;
$$;

-- 2. Drop the overly permissive INSERT policy on room_members
DROP POLICY IF EXISTS "Users can join rooms (insert themselves)" ON public.room_members;

-- 3. Create a restrictive INSERT policy - only allow inserts where user is the room creator (for room creation flow)
CREATE POLICY "Room creators can add first member" ON public.room_members
FOR INSERT TO authenticated
WITH CHECK (
  auth.uid() = user_id
  AND EXISTS (SELECT 1 FROM public.rooms WHERE id = room_id AND created_by = auth.uid())
);

-- 4. Fix app_settings: remove NULL room_id bypass for client-side access
DROP POLICY IF EXISTS "Room members can read app settings" ON public.app_settings;
DROP POLICY IF EXISTS "Room admins can insert app settings" ON public.app_settings;
DROP POLICY IF EXISTS "Room admins can update app settings" ON public.app_settings;
DROP POLICY IF EXISTS "Room admins can delete app settings" ON public.app_settings;

CREATE POLICY "Room members can read room app settings" ON public.app_settings
FOR SELECT TO authenticated
USING (room_id IS NOT NULL AND is_room_member(auth.uid(), room_id));

CREATE POLICY "Room admins can insert room app settings" ON public.app_settings
FOR INSERT TO authenticated
WITH CHECK (room_id IS NOT NULL AND is_room_admin(auth.uid(), room_id));

CREATE POLICY "Room admins can update room app settings" ON public.app_settings
FOR UPDATE TO authenticated
USING (room_id IS NOT NULL AND is_room_admin(auth.uid(), room_id));

CREATE POLICY "Room admins can delete room app settings" ON public.app_settings
FOR DELETE TO authenticated
USING (room_id IS NOT NULL AND is_room_admin(auth.uid(), room_id));

-- 5. Fix notifications: remove NULL room_id/user_id bypass
DROP POLICY IF EXISTS "Room members can view notifications" ON public.notifications;
DROP POLICY IF EXISTS "Room members can insert notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can delete own notifications" ON public.notifications;

CREATE POLICY "Users can view own room notifications" ON public.notifications
FOR SELECT TO authenticated
USING (
  (user_id = auth.uid())
  OR (room_id IS NOT NULL AND is_room_member(auth.uid(), room_id))
);

CREATE POLICY "Room members can insert room notifications" ON public.notifications
FOR INSERT TO authenticated
WITH CHECK (room_id IS NOT NULL AND is_room_member(auth.uid(), room_id));

CREATE POLICY "Users can update own notifications" ON public.notifications
FOR UPDATE TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own notifications" ON public.notifications
FOR DELETE TO authenticated
USING (user_id = auth.uid());
