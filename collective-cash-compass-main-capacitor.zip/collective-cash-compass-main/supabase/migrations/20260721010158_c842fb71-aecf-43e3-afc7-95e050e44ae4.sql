
-- Deals module (global catalog, single super-admin write access)
CREATE TABLE public.deals (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC(12,2),
  image_url TEXT,
  affiliate_url TEXT NOT NULL,
  store_name TEXT,
  category TEXT NOT NULL DEFAULT 'Others',
  badge TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX deals_category_active_idx ON public.deals (is_active, category, created_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.deals TO authenticated;
GRANT ALL ON public.deals TO service_role;

ALTER TABLE public.deals ENABLE ROW LEVEL SECURITY;

-- Helper: is the current session the super admin?
CREATE OR REPLACE FUNCTION public.is_super_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT lower(coalesce((auth.jwt() ->> 'email'), '')) = 'dkdilip3384@gmail.com'
$$;

-- Read: any authenticated user sees active deals; super admin sees all
CREATE POLICY "Deals readable by authenticated"
ON public.deals FOR SELECT TO authenticated
USING (is_active = true OR public.is_super_admin());

-- Write: super admin only
CREATE POLICY "Super admin can insert deals"
ON public.deals FOR INSERT TO authenticated
WITH CHECK (public.is_super_admin());

CREATE POLICY "Super admin can update deals"
ON public.deals FOR UPDATE TO authenticated
USING (public.is_super_admin())
WITH CHECK (public.is_super_admin());

CREATE POLICY "Super admin can delete deals"
ON public.deals FOR DELETE TO authenticated
USING (public.is_super_admin());

CREATE TRIGGER update_deals_updated_at
BEFORE UPDATE ON public.deals
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
