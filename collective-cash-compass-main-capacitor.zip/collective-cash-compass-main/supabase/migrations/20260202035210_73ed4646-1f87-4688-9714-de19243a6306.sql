-- Create storage bucket for audio files (admin uploads only)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('audio', 'audio', true)
ON CONFLICT (id) DO NOTHING;

-- Create RLS policies for audio bucket
CREATE POLICY "Anyone can view audio files" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'audio');

CREATE POLICY "Admins can upload audio files" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'audio' AND public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update audio files" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'audio' AND public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete audio files" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'audio' AND public.has_role(auth.uid(), 'admin'::public.app_role));

-- Create table to store current background audio URL
CREATE TABLE IF NOT EXISTS public.app_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text UNIQUE NOT NULL,
  value text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

-- Everyone can read app settings
CREATE POLICY "Anyone can read app settings"
ON public.app_settings FOR SELECT
USING (true);

-- Only admins can modify app settings
CREATE POLICY "Admins can insert app settings"
ON public.app_settings FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can update app settings"
ON public.app_settings FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "Admins can delete app settings"
ON public.app_settings FOR DELETE
USING (public.has_role(auth.uid(), 'admin'::public.app_role));