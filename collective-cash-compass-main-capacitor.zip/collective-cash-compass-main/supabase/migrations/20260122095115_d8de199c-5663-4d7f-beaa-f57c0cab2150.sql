-- Create duty_assignments table for daily duty roster
CREATE TABLE public.duty_assignments (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    duty_type TEXT NOT NULL CHECK (duty_type IN ('Cooking', 'Trash', 'Water')),
    friend_id UUID REFERENCES public.friends(id) ON DELETE CASCADE NOT NULL,
    duty_order INTEGER NOT NULL DEFAULT 0,
    start_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(duty_type, friend_id)
);

-- Enable RLS
ALTER TABLE public.duty_assignments ENABLE ROW LEVEL SECURITY;

-- RLS policies - all authenticated users can view
CREATE POLICY "All authenticated users can view duty assignments"
ON public.duty_assignments
FOR SELECT
TO authenticated
USING (true);

-- Only admins can insert duty assignments
CREATE POLICY "Admins can insert duty assignments"
ON public.duty_assignments
FOR INSERT
TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- Only admins can update duty assignments
CREATE POLICY "Admins can update duty assignments"
ON public.duty_assignments
FOR UPDATE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Only admins can delete duty assignments
CREATE POLICY "Admins can delete duty assignments"
ON public.duty_assignments
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_duty_assignments_updated_at
BEFORE UPDATE ON public.duty_assignments
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();