DROP POLICY IF EXISTS "Users can view rooms they belong to" ON public.rooms;
CREATE POLICY "Users can view rooms they belong to"
ON public.rooms FOR SELECT
TO authenticated
USING (created_by = auth.uid() OR is_room_member(auth.uid(), id));

DROP POLICY IF EXISTS "Room admins can insert friends" ON public.friends;
CREATE POLICY "Room members can insert friends"
ON public.friends FOR INSERT
TO authenticated
WITH CHECK (is_room_member(auth.uid(), room_id));