-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'user');

-- Create friends table to store friend information
CREATE TABLE public.friends (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    initial_balance DECIMAL(12, 2) NOT NULL DEFAULT 0,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create expense categories enum
CREATE TYPE public.expense_category AS ENUM ('Food', 'Rent', 'Bills', 'Others');

-- Create expenses table
CREATE TABLE public.expenses (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    description TEXT NOT NULL,
    amount DECIMAL(12, 2) NOT NULL,
    paid_by UUID NOT NULL REFERENCES public.friends(id) ON DELETE CASCADE,
    category expense_category NOT NULL DEFAULT 'Others',
    expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create expense splits table (who shares the expense)
CREATE TABLE public.expense_splits (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    expense_id UUID NOT NULL REFERENCES public.expenses(id) ON DELETE CASCADE,
    friend_id UUID NOT NULL REFERENCES public.friends(id) ON DELETE CASCADE,
    share_amount DECIMAL(12, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(expense_id, friend_id)
);

-- Enable RLS on all tables (but allow public access since this is a shared expense tracker)
ALTER TABLE public.friends ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expense_splits ENABLE ROW LEVEL SECURITY;

-- Create policies for public read access (anyone can view)
CREATE POLICY "Anyone can view friends" ON public.friends FOR SELECT USING (true);
CREATE POLICY "Anyone can view expenses" ON public.expenses FOR SELECT USING (true);
CREATE POLICY "Anyone can view expense splits" ON public.expense_splits FOR SELECT USING (true);

-- Create policies for public insert access (anyone can add expenses)
CREATE POLICY "Anyone can insert expenses" ON public.expenses FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can insert expense splits" ON public.expense_splits FOR INSERT WITH CHECK (true);

-- Create policies for updates (anyone can update - admin check done in app)
CREATE POLICY "Anyone can update friends" ON public.friends FOR UPDATE USING (true);
CREATE POLICY "Anyone can update expenses" ON public.expenses FOR UPDATE USING (true);

-- Create policies for deletes (anyone can delete - admin check done in app)
CREATE POLICY "Anyone can delete expenses" ON public.expenses FOR DELETE USING (true);
CREATE POLICY "Anyone can delete expense splits" ON public.expense_splits FOR DELETE USING (true);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create triggers for updated_at
CREATE TRIGGER update_friends_updated_at
    BEFORE UPDATE ON public.friends
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_expenses_updated_at
    BEFORE UPDATE ON public.expenses
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default friends with initial balances
INSERT INTO public.friends (name, initial_balance, display_order) VALUES
    ('Dilip Kumar', 3312.00, 1),
    ('Boomi', 6066.00, 2),
    ('Ajith', -3868.00, 3),
    ('Hari', -4882.00, 4);

-- Enable realtime for all tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.friends;
ALTER PUBLICATION supabase_realtime ADD TABLE public.expenses;
ALTER PUBLICATION supabase_realtime ADD TABLE public.expense_splits;