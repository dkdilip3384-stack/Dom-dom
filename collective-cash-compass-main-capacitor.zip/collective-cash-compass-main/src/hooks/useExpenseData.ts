import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Friend, Expense, ExpenseSplit, FriendBalance, Settlement } from '@/lib/types';
import { useRoom } from '@/contexts/RoomContext';
import { toast } from 'sonner';

export const useExpenseData = () => {
  const { currentRoom } = useRoom();
  const [friends, setFriends] = useState<Friend[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [expenseSplits, setExpenseSplits] = useState<ExpenseSplit[]>([]);
  const [loading, setLoading] = useState(false);

  const roomId = currentRoom?.id;

  const fetchData = useCallback(async (showLoading = false) => {
    if (!roomId) {
      setFriends([]);
      setExpenses([]);
      setExpenseSplits([]);
      return;
    }

    try {
      if (showLoading) setLoading(true);

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setFriends([]);
        setExpenses([]);
        setExpenseSplits([]);
        return;
      }

      const [friendsRes, expensesRes, splitsRes] = await Promise.all([
        supabase.from('friends').select('*').eq('room_id', roomId).order('display_order'),
        supabase.from('expenses').select('*').eq('room_id', roomId).order('created_at', { ascending: false }),
        supabase.from('expense_splits').select('*').eq('room_id', roomId).order('created_at', { ascending: false }),
      ]);

      if (friendsRes.error) throw friendsRes.error;
      if (expensesRes.error) throw expensesRes.error;
      if (splitsRes.error) throw splitsRes.error;

      setFriends((friendsRes.data ?? []) as Friend[]);
      setExpenses((expensesRes.data ?? []) as Expense[]);
      setExpenseSplits((splitsRes.data ?? []) as ExpenseSplit[]);
    } catch (error: any) {
      if (import.meta.env.DEV) console.error('Error fetching data:', error);
      const errorMessage = typeof error?.message === 'string' ? error.message : '';
      if (errorMessage.toLowerCase().includes('row-level security') || errorMessage.toLowerCase().includes('permission')) {
        toast.error('Data access blocked by backend policy. Please sign in again.');
      } else {
        toast.error('Failed to load data. Please retry.');
      }
    } finally {
      if (showLoading) setLoading(false);
    }
  }, [roomId]);

  useEffect(() => {
    void fetchData(false);

    const friendsChannel = supabase
      .channel('friends-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'friends' }, () => {
        void fetchData(false);
      })
      .subscribe();

    const expensesChannel = supabase
      .channel('expenses-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expenses' }, () => {
        void fetchData(false);
      })
      .subscribe();

    const splitsChannel = supabase
      .channel('splits-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'expense_splits' }, () => {
        void fetchData(false);
      })
      .subscribe();

    return () => {
      supabase.removeChannel(friendsChannel);
      supabase.removeChannel(expensesChannel);
      supabase.removeChannel(splitsChannel);
    };
  }, [fetchData]);

  const calculateBalances = useCallback((): FriendBalance[] => {
    return friends.map(friend => {
      const totalPaid = expenses
        .filter(e => e.paid_by === friend.id)
        .reduce((sum, e) => sum + Number(e.amount), 0);

      const totalShare = expenseSplits
        .filter(s => s.friend_id === friend.id)
        .reduce((sum, s) => sum + Number(s.share_amount), 0);

      const finalBalance = Number(friend.initial_balance) + totalPaid - totalShare;

      return { friend, totalPaid, totalShare, finalBalance };
    });
  }, [friends, expenses, expenseSplits]);

  const calculateSettlements = useCallback((): Settlement[] => {
    const balances = calculateBalances();
    const settlements: Settlement[] = [];

    const debtors = balances
      .filter(b => b.finalBalance < 0)
      .map(b => ({ friend: b.friend, amount: Math.abs(b.finalBalance) }))
      .sort((a, b) => b.amount - a.amount);

    const creditors = balances
      .filter(b => b.finalBalance > 0)
      .map(b => ({ friend: b.friend, amount: b.finalBalance }))
      .sort((a, b) => b.amount - a.amount);

    let i = 0, j = 0;
    while (i < debtors.length && j < creditors.length) {
      const debtor = debtors[i];
      const creditor = creditors[j];
      const amount = Math.min(debtor.amount, creditor.amount);

      if (amount > 0.01) {
        settlements.push({
          from: debtor.friend,
          to: creditor.friend,
          amount: Math.round(amount * 100) / 100,
        });
      }

      debtor.amount -= amount;
      creditor.amount -= amount;

      if (debtor.amount < 0.01) i++;
      if (creditor.amount < 0.01) j++;
    }

    return settlements;
  }, [calculateBalances]);

  const getTotalExpense = useCallback((): number => {
    return expenses.reduce((sum, e) => sum + Number(e.amount), 0);
  }, [expenses]);

  const createGlobalNotification = async (type: string, message: string, expenseDescription?: string) => {
    if (!roomId) return;
    try {
      const { error } = await supabase.from('notifications').insert({
        type,
        message,
        expense_description: expenseDescription,
        user_id: null,
        room_id: roomId,
      });
      if (error && import.meta.env.DEV) console.error('Error creating notification:', error);
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error creating notification:', error);
    }
  };

  const addExpense = async (
    description: string,
    amount: number,
    paidBy: string,
    expenseDate: Date,
    splitAmong: string[],
    receiptUrl: string | null = null,
    paymentMode: 'single' | 'split' = 'single',
    onlineAmount: number | null = null,
    cashAmount: number | null = null
  ) => {
    if (!roomId) return false;
    try {
      const { data: expenseData, error: expenseError } = await supabase
        .from('expenses')
        .insert({
          description,
          amount,
          paid_by: paidBy,
          category: 'Others',
          expense_date: expenseDate.toISOString().split('T')[0],
          receipt_url: receiptUrl,
          payment_mode: paymentMode,
          online_amount: paymentMode === 'split' ? onlineAmount : null,
          cash_amount: paymentMode === 'split' ? cashAmount : null,
          room_id: roomId,
        })
        .select()
        .single();

      if (expenseError) throw expenseError;

      const splitAmount = amount / splitAmong.length;
      const splits = splitAmong.map(friendId => ({
        expense_id: expenseData.id,
        friend_id: friendId,
        share_amount: splitAmount,
        room_id: roomId,
      }));

      const { error: splitsError } = await supabase
        .from('expense_splits')
        .insert(splits);

      if (splitsError) throw splitsError;

      await createGlobalNotification('add', `New expense added: "${description}" - ₹${amount.toLocaleString('en-IN')}`, description);
      toast.success('Expense added successfully');
      return true;
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error adding expense:', error);
      toast.error('Failed to add expense');
      return false;
    }
  };

  const updateExpense = async (
    id: string,
    description: string,
    amount: number,
    paidBy: string,
    expenseDate: Date,
    splitAmong: string[],
    receiptUrl?: string | null
  ) => {
    if (!roomId) return false;
    try {
      const oldExpense = expenses.find(e => e.id === id);
      const oldAmount = oldExpense ? Number(oldExpense.amount) : 0;
      const oldDescription = oldExpense?.description || description;

      const updateData: any = {
        description,
        amount,
        paid_by: paidBy,
        category: 'Others',
        expense_date: expenseDate.toISOString().split('T')[0],
      };

      if (receiptUrl !== undefined) {
        updateData.receipt_url = receiptUrl;
      }

      const { error: expenseError } = await supabase
        .from('expenses')
        .update(updateData)
        .eq('id', id);

      if (expenseError) throw expenseError;

      const { error: deleteError } = await supabase
        .from('expense_splits')
        .delete()
        .eq('expense_id', id);

      if (deleteError) throw deleteError;

      const splitAmount = amount / splitAmong.length;
      const splits = splitAmong.map(friendId => ({
        expense_id: id,
        friend_id: friendId,
        share_amount: splitAmount,
        room_id: roomId,
      }));

      const { error: splitsError } = await supabase
        .from('expense_splits')
        .insert(splits);

      if (splitsError) throw splitsError;

      const notificationMessage = oldAmount !== amount
        ? `Admin updated "${oldDescription}": Amount changed from ₹${oldAmount.toLocaleString('en-IN')} to ₹${amount.toLocaleString('en-IN')}.`
        : `Admin updated expense: "${description}" - ₹${amount.toLocaleString('en-IN')}`;

      await createGlobalNotification('edit', notificationMessage, description);
      toast.success('Expense updated successfully');
      return true;
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error updating expense:', error);
      toast.error('Failed to update expense');
      return false;
    }
  };

  const deleteExpense = async (id: string) => {
    try {
      const expense = expenses.find(e => e.id === id);
      const expenseDescription = expense?.description || 'Unknown';
      const expenseAmount = expense ? Number(expense.amount) : 0;

      const { error } = await supabase
        .from('expenses')
        .delete()
        .eq('id', id);

      if (error) throw error;

      const notificationMessage = `Admin deleted expense: "${expenseDescription}" - ₹${expenseAmount.toLocaleString('en-IN')}.`;
      await createGlobalNotification('delete', notificationMessage, expenseDescription);
      toast.success('Expense deleted successfully');
      return true;
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error deleting expense:', error);
      toast.error('Failed to delete expense');
      return false;
    }
  };

  const updateFriend = async (id: string, name: string, initialBalance: number) => {
    try {
      const { error } = await supabase
        .from('friends')
        .update({ name, initial_balance: initialBalance })
        .eq('id', id);

      if (error) throw error;
      toast.success('Friend updated successfully');
      return true;
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error updating friend:', error);
      toast.error('Failed to update friend');
      return false;
    }
  };

  const addFriend = async (name: string, initialBalance: number = 0) => {
    if (!roomId) return false;
    try {
      const maxOrder = friends.length > 0
        ? Math.max(...friends.map(f => f.display_order)) + 1
        : 0;

      const { error } = await supabase
        .from('friends')
        .insert({
          name,
          initial_balance: initialBalance,
          display_order: maxOrder,
          room_id: roomId,
        });

      if (error) throw error;
      toast.success('Friend added successfully');
      return true;
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error adding friend:', error);
      toast.error('Failed to add friend');
      return false;
    }
  };

  const deleteFriend = async (id: string) => {
    try {
      const { error: splitsError } = await supabase
        .from('expense_splits')
        .delete()
        .eq('friend_id', id);

      if (splitsError) throw splitsError;

      const { error: expensesError } = await supabase
        .from('expenses')
        .delete()
        .eq('paid_by', id);

      if (expensesError) throw expensesError;

      const { error } = await supabase
        .from('friends')
        .delete()
        .eq('id', id);

      if (error) throw error;
      toast.success('Friend removed successfully');
      return true;
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error deleting friend:', error);
      toast.error('Failed to remove friend');
      return false;
    }
  };

  return {
    friends,
    expenses,
    expenseSplits,
    loading,
    calculateBalances,
    calculateSettlements,
    getTotalExpense,
    addExpense,
    updateExpense,
    deleteExpense,
    updateFriend,
    addFriend,
    deleteFriend,
    refetch: fetchData,
  };
};
