import { useState, useEffect } from 'react';
import { getLanguage, setLanguage, onLanguageChange, Language, t, TranslationKey } from '@/lib/i18n';

export function useLanguage() {
  const [lang, setLang] = useState<Language>(getLanguage());

  useEffect(() => {
    return onLanguageChange(() => setLang(getLanguage()));
  }, []);

  return {
    lang,
    setLang: setLanguage,
    t: (key: TranslationKey) => t(key),
  };
}
