import { useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Friend } from '@/lib/types';

interface ExpensePayload {
  id: string;
  description: string;
  amount: number;
  paid_by: string;
  created_at: string;
}

export const useSystemNotifications = (friends: Friend[]) => {
  const { user } = useAuth();
  const permissionGranted = useRef(false);

  // Request notification permission on mount
  useEffect(() => {
    const requestPermission = async () => {
      if ('Notification' in window) {
        const permission = await Notification.requestPermission();
        permissionGranted.current = permission === 'granted';
        if (import.meta.env.DEV) console.log('Notification permission:', permission);
      }
    };

    requestPermission();
  }, []);

  // Helper to show system notification
  const showNotification = (title: string, body: string, tag: string) => {
    if (permissionGranted.current && 'Notification' in window) {
      const notification = new Notification(title, {
        body,
        icon: '/favicon.ico',
        tag, // Prevents duplicate notifications
        requireInteraction: false,
      });

      // Close notification after 5 seconds
      setTimeout(() => {
        notification.close();
      }, 5000);

      // Handle click on notification
      notification.onclick = () => {
        window.focus();
        notification.close();
      };
    }
  };

  // Get payer name from friends list
  const getPayerName = (paidById: string): string => {
    const payer = friends.find(f => f.id === paidById);
    return payer?.name || 'Someone';
  };

  // Listen for expense changes via Supabase Realtime
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel('expense-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'expenses',
        },
        (payload) => {
          
          const newExpense = payload.new as ExpensePayload;
          const payerName = getPayerName(newExpense.paid_by);

          showNotification(
            'New Expense Added',
            `${payerName} added ₹${Number(newExpense.amount).toLocaleString('en-IN')} for ${newExpense.description}.`,
            `expense-add-${newExpense.id}`
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'expenses',
        },
        (payload) => {
          
          const updatedExpense = payload.new as ExpensePayload;
          const payerName = getPayerName(updatedExpense.paid_by);

          showNotification(
            'Expense Edited',
            `${payerName} updated "${updatedExpense.description}". Check the new amount.`,
            `expense-edit-${updatedExpense.id}`
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'expenses',
        },
        (payload) => {
          
          const deletedExpense = payload.old as ExpensePayload;
          const payerName = getPayerName(deletedExpense.paid_by);

          showNotification(
            'Expense Deleted',
            `${payerName} deleted the expense: "${deletedExpense.description}".`,
            `expense-delete-${deletedExpense.id}`
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user, friends]);
};
