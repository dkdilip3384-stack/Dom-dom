import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export const usePushNotifications = () => {
  const { user } = useAuth();
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    setIsSupported('serviceWorker' in navigator && 'PushManager' in window);
  }, []);

  useEffect(() => {
    if (!user || !isSupported) return;
    registerAndSubscribe();
  }, [user, isSupported]);

  const registerAndSubscribe = async () => {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      await navigator.serviceWorker.ready;

      // Check existing subscription
      const existingSub = await registration.pushManager.getSubscription();
      if (existingSub) {
        setIsSubscribed(true);
        // Ensure it's saved in DB
        await saveSubscription(existingSub);
        return;
      }

      // Get VAPID public key from app_settings
      let { data: setting } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'vapid_public_key')
        .single();

      if (!setting?.value) {
        // Auto-generate VAPID keys by calling setup-push
        try {
          await supabase.functions.invoke('setup-push');
          const { data: retrySetting } = await supabase
            .from('app_settings')
            .select('value')
            .eq('key', 'vapid_public_key')
            .single();
          setting = retrySetting;
        } catch {
          if (import.meta.env.DEV) console.log('Could not auto-generate VAPID keys');
        }
      }

      if (!setting?.value) {
        if (import.meta.env.DEV) console.log('VAPID public key not configured yet');
        return;
      }

      // Request notification permission
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        if (import.meta.env.DEV) console.log('Notification permission denied');
        return;
      }

      // Subscribe to push
      const applicationServerKey = urlBase64ToUint8Array(setting.value);
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey.buffer as ArrayBuffer,
      });

      await saveSubscription(subscription);
      setIsSubscribed(true);
    } catch (error) {
      if (import.meta.env.DEV) console.error('Push subscription error:', error);
    }
  };

  const saveSubscription = async (subscription: PushSubscription) => {
    if (!user) return;

    const subJson = subscription.toJSON();
    if (!subJson.endpoint || !subJson.keys?.p256dh || !subJson.keys?.auth) return;

    try {
      // Check if already saved
      const { data: existing } = await supabase
        .from('push_subscriptions')
        .select('id')
        .eq('user_id', user.id)
        .eq('endpoint', subJson.endpoint)
        .maybeSingle();

      if (existing) return;

      await supabase.from('push_subscriptions').insert({
        user_id: user.id,
        endpoint: subJson.endpoint,
        p256dh: subJson.keys.p256dh,
        auth_key: subJson.keys.auth,
      });
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error saving push subscription:', error);
    }
  };

  return { isSubscribed, isSupported };
};
