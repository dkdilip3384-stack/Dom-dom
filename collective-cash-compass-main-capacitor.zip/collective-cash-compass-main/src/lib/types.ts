export interface Friend {
  id: string;
  name: string;
  initial_balance: number;
  display_order: number;
  avatar_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  paid_by: string;
  category: 'Food' | 'Rent' | 'Bills' | 'Others';
  expense_date: string;
  receipt_url: string | null;
  online_amount: number | null;
  cash_amount: number | null;
  payment_mode: 'single' | 'split';
  created_at: string;
  updated_at: string;
}

export interface ExpenseSplit {
  id: string;
  expense_id: string;
  friend_id: string;
  share_amount: number;
  created_at: string;
}

export interface ExpenseWithDetails extends Expense {
  payer?: Friend;
  splits?: ExpenseSplit[];
}

export interface FriendBalance {
  friend: Friend;
  totalPaid: number;
  totalShare: number;
  finalBalance: number;
}

export interface Settlement {
  from: Friend;
  to: Friend;
  amount: number;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'edit' | 'delete' | 'add';
  message: string;
  expense_description: string | null;
  is_read: boolean;
  created_at: string;
}

export type TabType = 'home' | 'history' | 'settlement' | 'duty' | 'deals';
