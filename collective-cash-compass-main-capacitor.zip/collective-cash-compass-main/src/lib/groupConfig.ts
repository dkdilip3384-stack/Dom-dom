export type GroupType =
  | 'roommates'
  | 'family'
  | 'friends'
  | 'office'
  | 'trip'
  | 'event'
  | 'couple'
  | 'business'
  | 'custom';

export interface GroupPreset {
  key: GroupType;
  label: string;
  emoji: string;
  expenseExamples: string[];
  duties: string[];
  categories: string[];
  roomNamePlaceholder: string;
}

export const GROUP_PRESETS: Record<GroupType, GroupPreset> = {
  roommates: {
    key: 'roommates',
    label: 'Roommates',
    emoji: '🏠',
    expenseExamples: ['Rent', 'Current Bill', 'Gas', 'Milk', 'Groceries'],
    duties: ['Cooking', 'Cleaning', 'Trash', 'Water'],
    categories: ['Food', 'Rent', 'Bills', 'Others'],
    roomNamePlaceholder: 'e.g., Apartment 4B',
  },
  family: {
    key: 'family',
    label: 'Family',
    emoji: '👨‍👩‍👧',
    expenseExamples: ['Groceries', 'School Fees', 'Electricity', 'Medical', 'Gas Cylinder'],
    duties: ['Kitchen', 'Shopping', 'Cleaning', 'Bills'],
    categories: ['Food', 'Bills', 'Medical', 'Others'],
    roomNamePlaceholder: 'e.g., Home',
  },
  friends: {
    key: 'friends',
    label: 'Friends',
    emoji: '🧑‍🤝‍🧑',
    expenseExamples: ['Dinner', 'Fuel', 'Movie', 'Birthday', 'Shopping'],
    duties: ['Snacks', 'Drinks', 'Planning'],
    categories: ['Food', 'Fun', 'Bills', 'Others'],
    roomNamePlaceholder: 'e.g., Weekend Gang',
  },
  office: {
    key: 'office',
    label: 'Office Team',
    emoji: '💼',
    expenseExamples: ['Tea', 'Printer', 'Stationery', 'Internet', 'Snacks'],
    duties: ['Tea', 'Meeting', 'Cleaning', 'Office Supplies'],
    categories: ['Food', 'Supplies', 'Bills', 'Others'],
    roomNamePlaceholder: 'e.g., Team Alpha',
  },
  trip: {
    key: 'trip',
    label: 'Trip',
    emoji: '✈️',
    expenseExamples: ['Hotel', 'Petrol', 'Food', 'Tickets', 'Toll'],
    duties: ['Driving', 'Booking', 'Navigation', 'Photography'],
    categories: ['Food', 'Travel', 'Stay', 'Others'],
    roomNamePlaceholder: 'e.g., Ooty Trip',
  },
  event: {
    key: 'event',
    label: 'Event',
    emoji: '🎉',
    expenseExamples: ['Stage', 'Decoration', 'Food', 'Sound', 'Transport'],
    duties: ['Decoration', 'Food', 'Photography', 'Management'],
    categories: ['Food', 'Decor', 'Logistics', 'Others'],
    roomNamePlaceholder: 'e.g., Cousin Wedding',
  },
  couple: {
    key: 'couple',
    label: 'Couple',
    emoji: '💑',
    expenseExamples: ['Dinner', 'Groceries', 'Rent', 'Date Night', 'Bills'],
    duties: ['Cooking', 'Shopping', 'Bills'],
    categories: ['Food', 'Bills', 'Fun', 'Others'],
    roomNamePlaceholder: 'e.g., Us',
  },
  business: {
    key: 'business',
    label: 'Small Business',
    emoji: '🏪',
    expenseExamples: ['Stock', 'Transport', 'Packing', 'Salary', 'Office Rent'],
    duties: ['Inventory', 'Packing', 'Delivery', 'Support'],
    categories: ['Stock', 'Salary', 'Bills', 'Others'],
    roomNamePlaceholder: 'e.g., Shop',
  },
  custom: {
    key: 'custom',
    label: 'Custom',
    emoji: '⚙️',
    expenseExamples: ['Expense 1', 'Expense 2', 'Expense 3'],
    duties: ['Task 1', 'Task 2', 'Task 3'],
    categories: ['Food', 'Bills', 'Others'],
    roomNamePlaceholder: 'e.g., My Group',
  },
};

export const GROUP_TYPE_LIST: GroupType[] = [
  'roommates', 'family', 'friends', 'office', 'trip', 'event', 'couple', 'business', 'custom',
];

export const getGroupPreset = (type?: string | null): GroupPreset =>
  GROUP_PRESETS[(type as GroupType) ?? 'roommates'] ?? GROUP_PRESETS.roommates;
