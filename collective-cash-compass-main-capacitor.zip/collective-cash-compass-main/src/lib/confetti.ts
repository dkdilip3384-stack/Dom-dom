import rupeeNote from '@/assets/rupee-note.png';
import goldCoin from '@/assets/gold-coin.png';

// Mobile-compatible speech synthesis
const speakAnnouncement = (message: string) => {
  try {
    if (!('speechSynthesis' in window)) return;
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.rate = 0.9;
    utterance.pitch = 1.1;
    utterance.volume = 1.0;
    
    // Function to speak with voice selection
    const speakWithVoice = () => {
      const voices = window.speechSynthesis.getVoices();
      
      // Find best available voice for mobile compatibility
      const preferredVoice = 
        voices.find(v => v.lang.startsWith('en') && v.name.includes('Female')) ||
        voices.find(v => v.lang.startsWith('en') && v.name.includes('Google')) ||
        voices.find(v => v.lang.startsWith('en') && v.name.includes('Samantha')) ||
        voices.find(v => v.lang === 'en-US') ||
        voices.find(v => v.lang.startsWith('en')) ||
        voices[0];
      
      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }
      
      // Mobile fix: some browsers need a small delay
      setTimeout(() => {
        window.speechSynthesis.speak(utterance);
      }, 100);
    };
    
    // Voices may not be loaded yet on mobile
    if (window.speechSynthesis.getVoices().length === 0) {
      window.speechSynthesis.onvoiceschanged = speakWithVoice;
      // Fallback timeout for mobile
      setTimeout(speakWithVoice, 500);
    } else {
      speakWithVoice();
    }
  } catch (e) {
    console.log('Speech synthesis not available');
  }
};

// Synthesize a cha-ching coin sound using Web Audio API
const playChaChing = () => {
  try {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    
    // Resume audio context for mobile
    if (audioContext.state === 'suspended') {
      audioContext.resume();
    }
    
    const playTone = (startTime: number, frequency: number, duration: number) => {
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(frequency, startTime);
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.3, startTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, startTime + duration);
      
      oscillator.start(startTime);
      oscillator.stop(startTime + duration);
    };
    
    const now = audioContext.currentTime;
    
    // Cha-ching sound sequence
    playTone(now, 1200, 0.1);
    playTone(now + 0.08, 1600, 0.1);
    playTone(now + 0.18, 2400, 0.15);
    playTone(now + 0.2, 3200, 0.2);
    
    // Metallic shimmer
    const noise = audioContext.createOscillator();
    const noiseGain = audioContext.createGain();
    noise.connect(noiseGain);
    noiseGain.connect(audioContext.destination);
    noise.frequency.setValueAtTime(4000, now + 0.15);
    noise.type = 'triangle';
    noiseGain.gain.setValueAtTime(0.1, now + 0.15);
    noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
    noise.start(now + 0.15);
    noise.stop(now + 0.5);
    
  } catch (e) {
    console.log('Audio not available');
  }
};

// Create a single falling money element
const createMoneyElement = (isNote: boolean, delay: number) => {
  const element = document.createElement('img');
  element.src = isNote ? rupeeNote : goldCoin;
  element.alt = isNote ? 'Rupee Note' : 'Gold Coin';
  
  // Random starting position
  const startX = Math.random() * 100;
  const size = isNote ? 80 + Math.random() * 40 : 60 + Math.random() * 30;
  const duration = 4 + Math.random() * 2; // 4-6 seconds fall time
  const rotationSpeed = 360 + Math.random() * 720;
  const swayAmount = 100 + Math.random() * 150;
  
  element.style.cssText = `
    position: fixed;
    top: -120px;
    left: ${startX}%;
    width: ${size}px;
    height: auto;
    z-index: 99999;
    pointer-events: none;
    animation: moneyFall ${duration}s ease-in forwards;
    animation-delay: ${delay}s;
    --sway: ${swayAmount}px;
    --rotation: ${rotationSpeed}deg;
    filter: drop-shadow(2px 4px 6px rgba(0,0,0,0.3));
  `;
  
  return element;
};

// Inject CSS animation if not already present
const injectAnimationCSS = () => {
  if (document.getElementById('money-rain-styles')) return;
  
  const style = document.createElement('style');
  style.id = 'money-rain-styles';
  style.textContent = `
    @keyframes moneyFall {
      0% {
        transform: translateY(0) translateX(0) rotate(0deg) scale(1);
        opacity: 1;
      }
      25% {
        transform: translateY(25vh) translateX(calc(var(--sway) * 0.5)) rotate(calc(var(--rotation) * 0.25)) scale(1.1);
        opacity: 1;
      }
      50% {
        transform: translateY(50vh) translateX(calc(var(--sway) * -0.3)) rotate(calc(var(--rotation) * 0.5)) scale(1);
        opacity: 0.9;
      }
      75% {
        transform: translateY(75vh) translateX(calc(var(--sway) * 0.4)) rotate(calc(var(--rotation) * 0.75)) scale(0.95);
        opacity: 0.7;
      }
      100% {
        transform: translateY(110vh) translateX(calc(var(--sway) * -0.2)) rotate(var(--rotation)) scale(0.9);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
};

// Export speech function for early mobile trigger
export const speakSuccess = () => {
  speakAnnouncement('Great! Amount Added Successfully!');
};

export const triggerMoneyRain = () => {
  // Inject CSS
  injectAnimationCSS();
  
  // Play sound first
  playChaChing();
  
  // Create container for money elements
  const container = document.createElement('div');
  container.id = 'money-rain-container';
  container.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    pointer-events: none;
    z-index: 99999;
    overflow: hidden;
  `;
  document.body.appendChild(container);
  
  // Create falling money elements with staggered delays over 3 seconds
  const totalElements = 35;
  
  for (let i = 0; i < totalElements; i++) {
    const isNote = Math.random() > 0.4; // 60% notes, 40% coins
    const delay = Math.random() * 3; // Stagger over 3 seconds
    const element = createMoneyElement(isNote, delay);
    container.appendChild(element);
  }
  
  // Clean up after 8 seconds (3s stagger + 5s animation)
  setTimeout(() => {
    container.remove();
  }, 8000);
};
