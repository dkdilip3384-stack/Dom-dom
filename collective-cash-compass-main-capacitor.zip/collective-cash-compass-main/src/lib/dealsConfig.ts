export const SUPER_ADMIN_EMAIL = 'dkdilip3384@gmail.com';

export const DEAL_CATEGORIES = [
  { key: 'All', emoji: '🛍️' },
  { key: 'Electronics', emoji: '📱' },
  { key: 'Gadgets', emoji: '🎧' },
  { key: 'Fashion', emoji: '👕' },
  { key: 'Footwear', emoji: '👟' },
  { key: 'Grocery', emoji: '🛒' },
  { key: 'Kitchen', emoji: '🍳' },
  { key: 'Home Essentials', emoji: '🏠' },
  { key: 'Student Essentials', emoji: '📚' },
  { key: 'Beauty', emoji: '💄' },
  { key: 'Others', emoji: '✨' },
] as const;

export const DEAL_BADGES = [
  '🔥 Limited Deal',
  '⚡ Best Offer',
  '💥 Hot Deal',
  "🎯 Today's Pick",
];

export type DealCategory = (typeof DEAL_CATEGORIES)[number]['key'];

export interface DealRow {
  id: string;
  title: string;
  description: string | null;
  price: number | null;
  image_url: string | null;
  affiliate_url: string;
  store_name: string | null;
  category: string;
  badge: string | null;
  is_active: boolean;
  created_at: string;
  created_by: string | null;
}
