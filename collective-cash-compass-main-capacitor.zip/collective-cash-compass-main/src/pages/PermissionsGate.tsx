import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Bell, Camera, CheckCircle2, Shield } from 'lucide-react';

interface PermissionsGateProps {
  onComplete: () => void;
}

const PermissionsGate: React.FC<PermissionsGateProps> = ({ onComplete }) => {
  const [notifGranted, setNotifGranted] = useState<boolean | null>(null);
  const [cameraGranted, setCameraGranted] = useState<boolean | null>(null);
  const [requesting, setRequesting] = useState(false);

  useEffect(() => {
    // Check if already completed
    const done = localStorage.getItem('z-kanakku-permissions-done');
    if (done === 'true') {
      onComplete();
      return;
    }

    // Check current status
    if ('Notification' in window) {
      setNotifGranted(Notification.permission === 'granted');
    } else {
      setNotifGranted(false);
    }

    if (navigator.mediaDevices) {
      navigator.mediaDevices.enumerateDevices().then(devices => {
        const hasCamera = devices.some(d => d.kind === 'videoinput');
        if (!hasCamera) setCameraGranted(true); // No camera = skip
      });
    }
  }, [onComplete]);

  const requestPermissions = async () => {
    setRequesting(true);

    // Request notification permission
    if ('Notification' in window && Notification.permission !== 'granted') {
      try {
        const result = await Notification.requestPermission();
        setNotifGranted(result === 'granted');
      } catch {
        setNotifGranted(false);
      }
    } else {
      setNotifGranted(true);
    }

    // Request camera permission
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach(t => t.stop());
      setCameraGranted(true);
    } catch {
      setCameraGranted(false);
    }

    setRequesting(false);
  };

  const handleContinue = () => {
    localStorage.setItem('z-kanakku-permissions-done', 'true');
    onComplete();
  };

  const bothHandled = notifGranted !== null && cameraGranted !== null;

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Shield className="w-12 h-12 mx-auto text-primary mb-2" />
          <CardTitle className="text-xl">App Permissions</CardTitle>
          <CardDescription>
            We need these permissions to send you reminders and capture photos.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 rounded-lg border border-border">
              <Bell className="w-5 h-5 text-primary shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium">Push Notifications</p>
                <p className="text-xs text-muted-foreground">Receive duty alerts & expense updates</p>
              </div>
              {notifGranted === true && <CheckCircle2 className="w-5 h-5 text-primary" />}
              {notifGranted === false && <span className="text-xs text-muted-foreground">Denied</span>}
            </div>

            <div className="flex items-center gap-3 p-3 rounded-lg border border-border">
              <Camera className="w-5 h-5 text-primary shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-medium">Camera Access</p>
                <p className="text-xs text-muted-foreground">Capture receipt & jewel photos</p>
              </div>
              {cameraGranted === true && <CheckCircle2 className="w-5 h-5 text-primary" />}
              {cameraGranted === false && <span className="text-xs text-muted-foreground">Denied</span>}
            </div>
          </div>

          {!bothHandled ? (
            <Button className="w-full" onClick={requestPermissions} disabled={requesting}>
              {requesting ? 'Requesting...' : 'Grant Permissions'}
            </Button>
          ) : (
            <Button className="w-full" onClick={handleContinue}>
              Continue to App
            </Button>
          )}

          {bothHandled && (notifGranted === false || cameraGranted === false) && (
            <p className="text-xs text-muted-foreground text-center">
              Some permissions were denied. You can enable them later in your browser settings.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PermissionsGate;
