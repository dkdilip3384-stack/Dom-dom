import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/hooks/useLanguage';
import { useRoom } from '@/contexts/RoomContext';
import { useAuth } from '@/contexts/AuthContext';
import { useExpenseData } from '@/hooks/useExpenseData';
import { supabase } from '@/integrations/supabase/client';
import { AdminPanel } from '@/components/expense-tracker/AdminPanel';
import { DutySetupPanel } from '@/components/expense-tracker/DutySetupPanel';
import { NotificationSettings } from '@/components/expense-tracker/NotificationSettings';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger,
} from '@/components/ui/sheet';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  ArrowLeft, Globe, Info, FileText, Shield, Star, Mail, HelpCircle,
  Users, ListChecks, Bell, User as UserIcon, Share2, ShieldCheck, LogOut, Trash2, ChevronRight,
} from 'lucide-react';
import { Language } from '@/lib/i18n';

const APP_VERSION = '1.0.0';
const APP_URL = 'https://play.google.com/store/apps/details?id=app.lovable.zkanakku';

type Faq = { id: string; question: string; answer: string; display_order: number };
type Contact = { id: string; type: string; label: string; value: string };
type About = { id: string; title: string; body: string };
type Legal = { id: string; kind: string; version: string; title: string | null; content: string; effective_date: string | null; published_at: string | null };

const Settings: React.FC = () => {
  const navigate = useNavigate();
  const { t, lang, setLang } = useLanguage();
  const { isRoomAdmin } = useRoom();
  const { user, isSuperAdmin, signOut } = useAuth();
  const { friends, updateFriend, addFriend, deleteFriend } = useExpenseData();

  const [adminOpen, setAdminOpen] = useState(false);
  const [dutyOpen, setDutyOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);

  const [faqs, setFaqs] = useState<Faq[]>([]);
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [about, setAbout] = useState<About[]>([]);
  const [privacy, setPrivacy] = useState<Legal | null>(null);
  const [terms, setTerms] = useState<Legal | null>(null);

  useEffect(() => {
    (async () => {
      const [f, c, a, p, tm] = await Promise.all([
        supabase.from('faqs').select('id,question,answer,display_order').eq('status', 'published').eq('lang', lang).order('display_order'),
        supabase.from('contact_methods').select('id,type,label,value').eq('status', 'published').order('display_order'),
        supabase.from('about_sections').select('id,title,body').eq('status', 'published').eq('lang', lang).order('display_order'),
        supabase.from('legal_documents').select('id,kind,version,title,content,effective_date,published_at').eq('status', 'published').eq('kind', 'privacy').order('published_at', { ascending: false }).limit(1).maybeSingle(),
        supabase.from('legal_documents').select('id,kind,version,title,content,effective_date,published_at').eq('status', 'published').eq('kind', 'terms').order('published_at', { ascending: false }).limit(1).maybeSingle(),
      ]);
      setFaqs((f.data as Faq[]) || []);
      setContacts((c.data as Contact[]) || []);
      setAbout((a.data as About[]) || []);
      setPrivacy(p.data as Legal | null);
      setTerms(tm.data as Legal | null);
    })();
  }, [lang]);

  const languages: { code: Language; label: string; native: string }[] = [
    { code: 'en', label: 'English', native: 'English' },
    { code: 'ta', label: 'Tamil', native: 'தமிழ்' },
    { code: 'hi', label: 'Hindi', native: 'हिन्दी' },
  ];

  const shareApp = async () => {
    const shareData = { title: 'Z-KANAKKU', text: 'Track shared expenses with Z-KANAKKU', url: APP_URL };
    try {
      if (navigator.share) await navigator.share(shareData);
      else { await navigator.clipboard.writeText(APP_URL); toast.success('App link copied'); }
    } catch { /* user cancelled */ }
  };

  const deleteAccount = async () => {
    if (!user) return;
    try {
      await supabase.rpc('log_admin_event', {
        _action: 'account_delete_request', _entity: 'auth.users', _status: 'requested',
        _detail: { user_id: user.id, email: user.email } as any,
      });
    } catch { /* ignore */ }
    toast.success('Deletion request recorded. Signing you out.');
    await signOut();
    navigate('/auth');
  };

  const Row: React.FC<{ icon: React.ReactNode; label: string; onClick?: () => void; danger?: boolean; trailing?: React.ReactNode }> =
    ({ icon, label, onClick, danger, trailing }) => (
      <button
        onClick={onClick}
        className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50 transition-colors ${danger ? 'text-destructive' : ''}`}
      >
        <span className={danger ? 'text-destructive' : 'text-primary'}>{icon}</span>
        <span className="flex-1 text-sm font-medium">{label}</span>
        {trailing ?? <ChevronRight className="w-4 h-4 text-muted-foreground" />}
      </button>
    );

  return (
    <div className="min-h-screen bg-background pb-24">
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} aria-label={t('back')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="font-display font-bold text-xl">Settings</h1>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 pt-20 space-y-6">
        {/* ACCOUNT */}
        <section className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">Account</div>
          <Card className="divide-y divide-border overflow-hidden">
            <Sheet>
              <SheetTrigger asChild>
                <button className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50">
                  <UserIcon className="w-5 h-5 text-primary" />
                  <span className="flex-1 text-sm font-medium">My Profile</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[70vh]">
                <SheetHeader><SheetTitle>My Profile</SheetTitle></SheetHeader>
                <div className="mt-4 space-y-2 text-sm">
                  <p><span className="text-muted-foreground">Name:</span> {user?.user_metadata?.full_name || '—'}</p>
                  <p><span className="text-muted-foreground">Email:</span> {user?.email}</p>
                </div>
              </SheetContent>
            </Sheet>

            {isRoomAdmin ? (
              <Row icon={<Users className="w-5 h-5" />} label="Group Settings" onClick={() => setAdminOpen(true)} />
            ) : (
              <div className="flex items-center gap-3 px-4 py-3 text-muted-foreground text-sm">
                <Users className="w-5 h-5" />
                <span className="flex-1">Group Settings</span>
                <span className="text-xs">Room admin only</span>
              </div>
            )}

            {isRoomAdmin && (
              <Row icon={<ListChecks className="w-5 h-5" />} label="Duty Setup" onClick={() => setDutyOpen(true)} />
            )}

            <Row icon={<Bell className="w-5 h-5" />} label="Notification Settings" onClick={() => setNotifOpen(true)} />

            <div className="px-4 py-3">
              <div className="flex items-center gap-3 mb-2">
                <Globe className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Language</span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {languages.map(l => (
                  <button
                    key={l.code}
                    onClick={() => setLang(l.code)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      lang === l.code ? 'bg-primary text-primary-foreground' : 'bg-muted hover:bg-muted/80 text-foreground'
                    }`}
                  >
                    {l.native}
                  </button>
                ))}
              </div>
            </div>
          </Card>
        </section>

        {/* SUPER ADMIN entry — only visible to super admin */}
        {isSuperAdmin && (
          <section className="space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">App Administration</div>
            <Card className="overflow-hidden">
              <Row icon={<ShieldCheck className="w-5 h-5" />} label="Super Admin Console" onClick={() => navigate('/super-admin')} />
            </Card>
          </section>
        )}

        {/* SUPPORT */}
        <section className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">Support</div>
          <Card className="divide-y divide-border overflow-hidden">
            <Sheet>
              <SheetTrigger asChild>
                <button className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50">
                  <HelpCircle className="w-5 h-5 text-primary" />
                  <span className="flex-1 text-sm font-medium">Help &amp; FAQ</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto">
                <SheetHeader><SheetTitle>Help &amp; FAQ</SheetTitle></SheetHeader>
                <div className="mt-4 space-y-4">
                  {faqs.length === 0 && <p className="text-sm text-muted-foreground">No FAQs published yet.</p>}
                  {faqs.map(f => (
                    <div key={f.id}>
                      <p className="font-medium text-sm">{f.question}</p>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap mt-1">{f.answer}</p>
                    </div>
                  ))}
                </div>
              </SheetContent>
            </Sheet>

            <Sheet>
              <SheetTrigger asChild>
                <button className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50">
                  <Mail className="w-5 h-5 text-primary" />
                  <span className="flex-1 text-sm font-medium">Contact Us</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[70vh] overflow-y-auto">
                <SheetHeader><SheetTitle>Contact Us</SheetTitle></SheetHeader>
                <div className="mt-4 space-y-3">
                  {contacts.length === 0 && (
                    <a href="mailto:dkworks.digital@gmail.com" className="block text-sm underline">dkworks.digital@gmail.com</a>
                  )}
                  {contacts.map(c => (
                    <div key={c.id} className="text-sm">
                      <p className="text-xs uppercase text-muted-foreground">{c.type} — {c.label}</p>
                      <p className="font-mono break-all">{c.value}</p>
                    </div>
                  ))}
                </div>
              </SheetContent>
            </Sheet>

            <Row icon={<Star className="w-5 h-5" />} label="Rate App" onClick={() => window.open(APP_URL, '_blank', 'noopener,noreferrer')} />
            <Row icon={<Share2 className="w-5 h-5" />} label="Share App" onClick={shareApp} />
          </Card>
        </section>

        {/* LEGAL & INFO */}
        <section className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">Legal &amp; Information</div>
          <Card className="divide-y divide-border overflow-hidden">
            <LegalSheet title="Privacy Policy" icon={<Shield className="w-5 h-5" />} doc={privacy} />
            <LegalSheet title="Terms & Conditions" icon={<FileText className="w-5 h-5" />} doc={terms} />
            <Sheet>
              <SheetTrigger asChild>
                <button className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50">
                  <Info className="w-5 h-5 text-primary" />
                  <span className="flex-1 text-sm font-medium">About Z-KANAKKU</span>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </button>
              </SheetTrigger>
              <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto">
                <SheetHeader><SheetTitle>About Z-KANAKKU</SheetTitle></SheetHeader>
                <div className="mt-4 space-y-4">
                  {about.length === 0 && (
                    <p className="text-sm text-muted-foreground">Z-KANAKKU helps groups track and settle shared expenses effortlessly.</p>
                  )}
                  {about.map(s => (
                    <div key={s.id}>
                      <p className="font-medium">{s.title}</p>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap mt-1">{s.body}</p>
                    </div>
                  ))}
                  <p className="text-xs text-muted-foreground pt-2">Version {APP_VERSION}</p>
                </div>
              </SheetContent>
            </Sheet>
          </Card>
        </section>

        {/* ACCOUNT ACTIONS */}
        <section className="space-y-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground px-1">Account Actions</div>
          <Card className="overflow-hidden">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <button className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-destructive/10 text-destructive">
                  <Trash2 className="w-5 h-5" />
                  <span className="flex-1 text-sm font-medium">Delete Account</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete your account?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will submit a permanent deletion request for your account and sign you out.
                    You will lose access to all your groups and history. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={deleteAccount} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </Card>

          <Card className="overflow-hidden mt-4">
            <button
              onClick={async () => { await signOut(); navigate('/auth'); }}
              className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50"
            >
              <LogOut className="w-5 h-5 text-primary" />
              <span className="flex-1 text-sm font-medium">Sign Out</span>
            </button>
          </Card>
        </section>
      </main>

      {isRoomAdmin && (
        <>
          <AdminPanel
            open={adminOpen}
            onOpenChange={setAdminOpen}
            friends={friends}
            onUpdateFriend={updateFriend}
            onAddFriend={addFriend}
            onDeleteFriend={deleteFriend}
          />
          <DutySetupPanel open={dutyOpen} onOpenChange={setDutyOpen} friends={friends} />
        </>
      )}
      <NotificationSettings open={notifOpen} onOpenChange={setNotifOpen} />
    </div>
  );
};

const LegalSheet: React.FC<{ title: string; icon: React.ReactNode; doc: Legal | null }> = ({ title, icon, doc }) => (
  <Sheet>
    <SheetTrigger asChild>
      <button className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-muted/50">
        <span className="text-primary">{icon}</span>
        <span className="flex-1 text-sm font-medium">{title}</span>
        <ChevronRight className="w-4 h-4 text-muted-foreground" />
      </button>
    </SheetTrigger>
    <SheetContent side="bottom" className="max-h-[85vh] overflow-y-auto">
      <SheetHeader>
        <SheetTitle>{title}</SheetTitle>
        {doc?.effective_date && <p className="text-xs text-muted-foreground">Effective {doc.effective_date} · v{doc.version}</p>}
      </SheetHeader>
      <div className="mt-4 text-sm whitespace-pre-wrap">
        {doc?.content || `${title} has not been published yet. Please check back soon.`}
      </div>
    </SheetContent>
  </Sheet>
);

export default Settings;
