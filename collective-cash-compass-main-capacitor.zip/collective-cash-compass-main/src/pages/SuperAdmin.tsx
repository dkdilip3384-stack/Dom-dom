import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { RequireSuperAdmin } from '@/components/RequireSuperAdmin';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { ArrowLeft, Plus, Trash2, Eye, EyeOff, Archive, Send, RotateCcw, Pencil } from 'lucide-react';

type Faq = { id: string; question: string; answer: string; display_order: number; status: string; lang: string };
type Contact = { id: string; type: string; label: string; value: string; display_order: number; status: string };
type About = { id: string; title: string; body: string; display_order: number; status: string; lang: string };
type Legal = {
  id: string; kind: string; version: string; title: string | null; summary: string | null;
  content: string; status: string; effective_date: string | null; published_at: string | null;
  previous_version_id: string | null; created_at: string;
};
type Audit = {
  id: string; actor_email: string | null; action: string; entity: string;
  entity_id: string | null; created_at: string; status: string;
};

const STATUSES = ['draft', 'published', 'hidden'] as const;

const SuperAdminInner: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background pb-16">
      <header className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/settings')}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-display font-bold text-xl">Super Admin</h1>
            <p className="text-xs text-muted-foreground">App-wide content management</p>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 pt-4">
        <Tabs defaultValue="faqs" className="w-full">
          <TabsList className="grid grid-cols-5 w-full">
            <TabsTrigger value="faqs">FAQ</TabsTrigger>
            <TabsTrigger value="contacts">Contact</TabsTrigger>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="legal">Legal</TabsTrigger>
            <TabsTrigger value="audit">Audit</TabsTrigger>
          </TabsList>
          <TabsContent value="faqs"><FaqManager /></TabsContent>
          <TabsContent value="contacts"><ContactManager /></TabsContent>
          <TabsContent value="about"><AboutManager /></TabsContent>
          <TabsContent value="legal"><LegalManager /></TabsContent>
          <TabsContent value="audit"><AuditViewer /></TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

const SuperAdmin: React.FC = () => (
  <RequireSuperAdmin><SuperAdminInner /></RequireSuperAdmin>
);
export default SuperAdmin;

// ---------- FAQ ----------
const FaqManager: React.FC = () => {
  const [items, setItems] = useState<Faq[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<Faq>>({ question: '', answer: '', lang: 'en', display_order: 0, status: 'draft' });
  const [editingId, setEditingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('faqs').select('*').order('display_order');
    if (error) toast.error(error.message); else setItems(data as Faq[]);
    setLoading(false);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.question || !form.answer) return toast.error('Question and answer are required');
    if (editingId) {
      const { error } = await supabase.from('faqs').update(form).eq('id', editingId);
      if (error) return toast.error(error.message);
      toast.success('Updated');
    } else {
      const { error } = await supabase.from('faqs').insert(form as any);
      if (error) return toast.error(error.message);
      toast.success('Added');
    }
    setForm({ question: '', answer: '', lang: 'en', display_order: 0, status: 'draft' });
    setEditingId(null);
    load();
  };

  const remove = async (id: string) => {
    const { error } = await supabase.from('faqs').delete().eq('id', id);
    if (error) return toast.error(error.message);
    toast.success('Deleted'); load();
  };
  const setStatus = async (id: string, status: string) => {
    const { error } = await supabase.from('faqs').update({ status }).eq('id', id);
    if (error) return toast.error(error.message);
    load();
  };

  return (
    <div className="space-y-4 py-4">
      <Card className="p-4 space-y-3">
        <h2 className="font-semibold">{editingId ? 'Edit FAQ' : 'Add FAQ'}</h2>
        <Input placeholder="Question" value={form.question || ''} onChange={e => setForm({ ...form, question: e.target.value })} />
        <Textarea placeholder="Answer" value={form.answer || ''} onChange={e => setForm({ ...form, answer: e.target.value })} />
        <div className="grid grid-cols-3 gap-2">
          <Select value={form.lang || 'en'} onValueChange={v => setForm({ ...form, lang: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="en">English</SelectItem><SelectItem value="ta">தமிழ்</SelectItem><SelectItem value="hi">हिन्दी</SelectItem></SelectContent>
          </Select>
          <Input type="number" placeholder="Order" value={form.display_order ?? 0} onChange={e => setForm({ ...form, display_order: Number(e.target.value) })} />
          <Select value={form.status || 'draft'} onValueChange={v => setForm({ ...form, status: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Button onClick={save}>{editingId ? 'Save' : <><Plus className="w-4 h-4 mr-1" />Add</>}</Button>
          {editingId && <Button variant="outline" onClick={() => { setEditingId(null); setForm({ question: '', answer: '', lang: 'en', display_order: 0, status: 'draft' }); }}>Cancel</Button>}
        </div>
      </Card>

      {loading ? <p className="text-muted-foreground text-sm">Loading…</p> : items.map(it => (
        <Card key={it.id} className="p-4 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <p className="font-medium">{it.question}</p>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{it.answer}</p>
              <p className="text-xs mt-1">
                <span className="uppercase font-mono">{it.status}</span> · {it.lang} · order {it.display_order}
              </p>
            </div>
            <div className="flex flex-col gap-1">
              <Button size="icon" variant="ghost" onClick={() => { setEditingId(it.id); setForm(it); }}><Pencil className="w-4 h-4" /></Button>
              {it.status === 'published'
                ? <Button size="icon" variant="ghost" onClick={() => setStatus(it.id, 'hidden')}><EyeOff className="w-4 h-4" /></Button>
                : <Button size="icon" variant="ghost" onClick={() => setStatus(it.id, 'published')}><Eye className="w-4 h-4" /></Button>}
              <ConfirmButton onConfirm={() => remove(it.id)} title="Delete FAQ?" description="This will permanently delete this FAQ." />
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
};

// ---------- Contact ----------
const ContactManager: React.FC = () => {
  const [items, setItems] = useState<Contact[]>([]);
  const [form, setForm] = useState<Partial<Contact>>({ type: 'email', label: '', value: '', display_order: 0, status: 'draft' });
  const [editingId, setEditingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('contact_methods').select('*').order('display_order');
    if (error) toast.error(error.message); else setItems(data as Contact[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.label || !form.value) return toast.error('Label and value are required');
    if (editingId) {
      const { error } = await supabase.from('contact_methods').update(form).eq('id', editingId);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from('contact_methods').insert(form as any);
      if (error) return toast.error(error.message);
    }
    setForm({ type: 'email', label: '', value: '', display_order: 0, status: 'draft' });
    setEditingId(null); load();
  };
  const remove = async (id: string) => {
    const { error } = await supabase.from('contact_methods').delete().eq('id', id);
    if (error) return toast.error(error.message); load();
  };
  const setStatus = async (id: string, status: string) => {
    await supabase.from('contact_methods').update({ status }).eq('id', id); load();
  };

  return (
    <div className="space-y-4 py-4">
      <Card className="p-4 space-y-3">
        <h2 className="font-semibold">{editingId ? 'Edit Contact' : 'Add Contact'}</h2>
        <Select value={form.type || 'email'} onValueChange={v => setForm({ ...form, type: v })}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="email">Email</SelectItem>
            <SelectItem value="phone">Phone</SelectItem>
            <SelectItem value="whatsapp">WhatsApp</SelectItem>
            <SelectItem value="hours">Support Hours</SelectItem>
            <SelectItem value="other">Other</SelectItem>
          </SelectContent>
        </Select>
        <Input placeholder="Label (e.g. Support)" value={form.label || ''} onChange={e => setForm({ ...form, label: e.target.value })} />
        <Input placeholder="Value (email / number / text)" value={form.value || ''} onChange={e => setForm({ ...form, value: e.target.value })} />
        <div className="grid grid-cols-2 gap-2">
          <Input type="number" placeholder="Order" value={form.display_order ?? 0} onChange={e => setForm({ ...form, display_order: Number(e.target.value) })} />
          <Select value={form.status || 'draft'} onValueChange={v => setForm({ ...form, status: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Button onClick={save}>{editingId ? 'Save' : 'Add'}</Button>
          {editingId && <Button variant="outline" onClick={() => { setEditingId(null); setForm({ type: 'email', label: '', value: '', display_order: 0, status: 'draft' }); }}>Cancel</Button>}
        </div>
      </Card>

      {items.map(it => (
        <Card key={it.id} className="p-4 flex items-start justify-between gap-2">
          <div className="flex-1">
            <p className="font-medium">{it.label} <span className="text-xs text-muted-foreground">({it.type})</span></p>
            <p className="text-sm break-all">{it.value}</p>
            <p className="text-xs mt-1 uppercase font-mono">{it.status} · order {it.display_order}</p>
          </div>
          <div className="flex flex-col gap-1">
            <Button size="icon" variant="ghost" onClick={() => { setEditingId(it.id); setForm(it); }}><Pencil className="w-4 h-4" /></Button>
            {it.status === 'published'
              ? <Button size="icon" variant="ghost" onClick={() => setStatus(it.id, 'hidden')}><EyeOff className="w-4 h-4" /></Button>
              : <Button size="icon" variant="ghost" onClick={() => setStatus(it.id, 'published')}><Eye className="w-4 h-4" /></Button>}
            <ConfirmButton onConfirm={() => remove(it.id)} title="Delete contact?" description="This will permanently delete this contact method." />
          </div>
        </Card>
      ))}
    </div>
  );
};

// ---------- About ----------
const AboutManager: React.FC = () => {
  const [items, setItems] = useState<About[]>([]);
  const [form, setForm] = useState<Partial<About>>({ title: '', body: '', lang: 'en', display_order: 0, status: 'draft' });
  const [editingId, setEditingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('about_sections').select('*').order('display_order');
    if (error) toast.error(error.message); else setItems(data as About[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.title || !form.body) return toast.error('Title and body are required');
    if (editingId) {
      const { error } = await supabase.from('about_sections').update(form).eq('id', editingId);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from('about_sections').insert(form as any);
      if (error) return toast.error(error.message);
    }
    setForm({ title: '', body: '', lang: 'en', display_order: 0, status: 'draft' });
    setEditingId(null); load();
  };
  const remove = async (id: string) => {
    const { error } = await supabase.from('about_sections').delete().eq('id', id);
    if (error) return toast.error(error.message); load();
  };
  const setStatus = async (id: string, status: string) => {
    await supabase.from('about_sections').update({ status }).eq('id', id); load();
  };

  return (
    <div className="space-y-4 py-4">
      <Card className="p-4 space-y-3">
        <h2 className="font-semibold">{editingId ? 'Edit Section' : 'Add About Section'}</h2>
        <Input placeholder="Title" value={form.title || ''} onChange={e => setForm({ ...form, title: e.target.value })} />
        <Textarea rows={5} placeholder="Body" value={form.body || ''} onChange={e => setForm({ ...form, body: e.target.value })} />
        <div className="grid grid-cols-3 gap-2">
          <Select value={form.lang || 'en'} onValueChange={v => setForm({ ...form, lang: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="en">English</SelectItem><SelectItem value="ta">தமிழ்</SelectItem><SelectItem value="hi">हिन्दी</SelectItem></SelectContent>
          </Select>
          <Input type="number" placeholder="Order" value={form.display_order ?? 0} onChange={e => setForm({ ...form, display_order: Number(e.target.value) })} />
          <Select value={form.status || 'draft'} onValueChange={v => setForm({ ...form, status: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Button onClick={save}>{editingId ? 'Save' : 'Add'}</Button>
          {editingId && <Button variant="outline" onClick={() => { setEditingId(null); setForm({ title: '', body: '', lang: 'en', display_order: 0, status: 'draft' }); }}>Cancel</Button>}
        </div>
      </Card>

      {items.map(it => (
        <Card key={it.id} className="p-4 flex items-start justify-between gap-2">
          <div className="flex-1">
            <p className="font-medium">{it.title}</p>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{it.body}</p>
            <p className="text-xs mt-1 uppercase font-mono">{it.status} · {it.lang} · order {it.display_order}</p>
          </div>
          <div className="flex flex-col gap-1">
            <Button size="icon" variant="ghost" onClick={() => { setEditingId(it.id); setForm(it); }}><Pencil className="w-4 h-4" /></Button>
            {it.status === 'published'
              ? <Button size="icon" variant="ghost" onClick={() => setStatus(it.id, 'hidden')}><EyeOff className="w-4 h-4" /></Button>
              : <Button size="icon" variant="ghost" onClick={() => setStatus(it.id, 'published')}><Eye className="w-4 h-4" /></Button>}
            <ConfirmButton onConfirm={() => remove(it.id)} title="Delete section?" description="This will permanently delete this About section." />
          </div>
        </Card>
      ))}
    </div>
  );
};

// ---------- Legal ----------
const LegalManager: React.FC = () => {
  const [items, setItems] = useState<Legal[]>([]);
  const [form, setForm] = useState<Partial<Legal>>({ kind: 'privacy', version: '1.0', title: '', summary: '', content: '', status: 'draft' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [preview, setPreview] = useState<Legal | null>(null);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('legal_documents').select('*').order('created_at', { ascending: false });
    if (error) toast.error(error.message); else setItems(data as Legal[]);
  }, []);
  useEffect(() => { load(); }, [load]);

  const save = async () => {
    if (!form.content || !form.version) return toast.error('Version and content are required');
    if (editingId) {
      const { error } = await supabase.from('legal_documents').update(form).eq('id', editingId);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await supabase.from('legal_documents').insert(form as any);
      if (error) return toast.error(error.message);
    }
    setForm({ kind: 'privacy', version: '1.0', title: '', summary: '', content: '', status: 'draft' });
    setEditingId(null); load();
  };

  const publish = async (it: Legal) => {
    // Unpublish previous published of same kind
    await supabase.from('legal_documents').update({ status: 'unpublished' })
      .eq('kind', it.kind).eq('status', 'published').neq('id', it.id);
    const { error } = await supabase.from('legal_documents').update({
      status: 'published',
      published_at: new Date().toISOString(),
      effective_date: it.effective_date || new Date().toISOString().slice(0, 10),
    }).eq('id', it.id);
    if (error) return toast.error(error.message);
    toast.success('Published'); load();
  };
  const unpublish = async (id: string) => { await supabase.from('legal_documents').update({ status: 'unpublished' }).eq('id', id); load(); };
  const archive = async (id: string) => { await supabase.from('legal_documents').update({ status: 'archived' }).eq('id', id); toast.success('Archived (not deleted)'); load(); };
  const restore = async (it: Legal) => {
    // Create a new draft from the archived content
    const { error } = await supabase.from('legal_documents').insert({
      kind: it.kind, version: `${it.version}-restored`, title: it.title, summary: it.summary,
      content: it.content, status: 'draft', previous_version_id: it.id,
    } as any);
    if (error) return toast.error(error.message);
    toast.success('Restored as new draft'); load();
  };

  return (
    <div className="space-y-4 py-4">
      <Card className="p-4 space-y-3">
        <h2 className="font-semibold">{editingId ? 'Edit Document' : 'New Legal Document'}</h2>
        <div className="grid grid-cols-2 gap-2">
          <Select value={form.kind || 'privacy'} onValueChange={v => setForm({ ...form, kind: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="privacy">Privacy Policy</SelectItem>
              <SelectItem value="terms">Terms &amp; Conditions</SelectItem>
            </SelectContent>
          </Select>
          <Input placeholder="Version (e.g. 1.2)" value={form.version || ''} onChange={e => setForm({ ...form, version: e.target.value })} />
        </div>
        <Input placeholder="Title (optional)" value={form.title || ''} onChange={e => setForm({ ...form, title: e.target.value })} />
        <Textarea placeholder="Summary of changes" value={form.summary || ''} onChange={e => setForm({ ...form, summary: e.target.value })} />
        <Textarea rows={10} placeholder="Full content (Markdown or plain text)" value={form.content || ''} onChange={e => setForm({ ...form, content: e.target.value })} />
        <Input type="date" placeholder="Effective date" value={form.effective_date || ''} onChange={e => setForm({ ...form, effective_date: e.target.value })} />
        <div className="flex gap-2">
          <Button onClick={save}>{editingId ? 'Save Draft' : 'Save Draft'}</Button>
          {editingId && <Button variant="outline" onClick={() => { setEditingId(null); setForm({ kind: 'privacy', version: '1.0', title: '', summary: '', content: '', status: 'draft' }); }}>Cancel</Button>}
        </div>
      </Card>

      {items.map(it => (
        <Card key={it.id} className="p-4 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <p className="font-medium">{it.kind === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions'} — v{it.version}</p>
              {it.title && <p className="text-sm">{it.title}</p>}
              <p className="text-xs uppercase font-mono mt-1">{it.status}{it.effective_date ? ` · eff ${it.effective_date}` : ''}</p>
              {it.summary && <p className="text-sm text-muted-foreground mt-1">{it.summary}</p>}
            </div>
            <div className="flex flex-col gap-1">
              <Button size="icon" variant="ghost" onClick={() => setPreview(it)}><Eye className="w-4 h-4" /></Button>
              <Button size="icon" variant="ghost" onClick={() => { setEditingId(it.id); setForm(it); }}><Pencil className="w-4 h-4" /></Button>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 pt-2">
            {it.status !== 'published' && it.status !== 'archived' && (
              <ConfirmButton
                label={<><Send className="w-3 h-3 mr-1" />Publish</>}
                variant="default"
                onConfirm={() => publish(it)}
                title="Publish this document?"
                description="This will replace the current published version and mark it as the active policy for all users."
              />
            )}
            {it.status === 'published' && (
              <Button size="sm" variant="outline" onClick={() => unpublish(it.id)}>Unpublish</Button>
            )}
            {it.status !== 'archived' && (
              <ConfirmButton
                label={<><Archive className="w-3 h-3 mr-1" />Archive</>}
                variant="destructive"
                onConfirm={() => archive(it.id)}
                title="Archive this document?"
                description="Legal content is never deleted. Archiving hides it from users but preserves the full version history."
              />
            )}
            {it.status === 'archived' && (
              <Button size="sm" variant="outline" onClick={() => restore(it)}><RotateCcw className="w-3 h-3 mr-1" />Restore as draft</Button>
            )}
          </div>
        </Card>
      ))}

      {preview && (
        <AlertDialog open onOpenChange={() => setPreview(null)}>
          <AlertDialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <AlertDialogHeader>
              <AlertDialogTitle>{preview.kind === 'privacy' ? 'Privacy Policy' : 'Terms & Conditions'} — v{preview.version}</AlertDialogTitle>
              <AlertDialogDescription>Preview (as users will see it)</AlertDialogDescription>
            </AlertDialogHeader>
            <div className="whitespace-pre-wrap text-sm">{preview.content}</div>
            <AlertDialogFooter><AlertDialogCancel>Close</AlertDialogCancel></AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
};

// ---------- Audit log ----------
const AuditViewer: React.FC = () => {
  const [items, setItems] = useState<Audit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.from('admin_audit_log')
        .select('id, actor_email, action, entity, entity_id, created_at, status')
        .order('created_at', { ascending: false }).limit(200);
      if (error) toast.error(error.message); else setItems(data as Audit[]);
      setLoading(false);
    })();
  }, []);

  if (loading) return <p className="text-muted-foreground text-sm py-4">Loading…</p>;
  if (!items.length) return <p className="text-muted-foreground text-sm py-4">No audit entries yet.</p>;

  return (
    <div className="space-y-2 py-4">
      {items.map(a => (
        <Card key={a.id} className="p-3 text-sm">
          <div className="flex justify-between gap-2">
            <div>
              <span className="font-mono text-xs uppercase mr-2">{a.action}</span>
              <span>{a.entity}</span>
              {a.entity_id && <span className="text-muted-foreground text-xs ml-2 break-all">{a.entity_id.slice(0, 8)}</span>}
            </div>
            <span className={`text-xs font-mono ${a.status === 'denied' ? 'text-destructive' : 'text-muted-foreground'}`}>{a.status}</span>
          </div>
          <div className="text-xs text-muted-foreground mt-1 flex justify-between">
            <span>{a.actor_email || '—'}</span>
            <span>{new Date(a.created_at).toLocaleString()}</span>
          </div>
        </Card>
      ))}
    </div>
  );
};

// ---------- Confirm dialog helper ----------
const ConfirmButton: React.FC<{
  onConfirm: () => void; title: string; description: string;
  label?: React.ReactNode; variant?: 'default' | 'destructive' | 'outline';
}> = ({ onConfirm, title, description, label, variant = 'destructive' }) => (
  <AlertDialog>
    <AlertDialogTrigger asChild>
      {label
        ? <Button size="sm" variant={variant}>{label}</Button>
        : <Button size="icon" variant="ghost"><Trash2 className="w-4 h-4 text-destructive" /></Button>}
    </AlertDialogTrigger>
    <AlertDialogContent>
      <AlertDialogHeader>
        <AlertDialogTitle>{title}</AlertDialogTitle>
        <AlertDialogDescription>{description}</AlertDialogDescription>
      </AlertDialogHeader>
      <AlertDialogFooter>
        <AlertDialogCancel>Cancel</AlertDialogCancel>
        <AlertDialogAction onClick={onConfirm}>Confirm</AlertDialogAction>
      </AlertDialogFooter>
    </AlertDialogContent>
  </AlertDialog>
);
