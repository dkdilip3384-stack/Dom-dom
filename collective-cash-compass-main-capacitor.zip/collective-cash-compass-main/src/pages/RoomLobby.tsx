import React, { useState } from 'react';
import { useRoom } from '@/contexts/RoomContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';
import { Plus, LogIn, Copy, ArrowLeft, LogOut, DoorOpen, Users } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';
import { GROUP_PRESETS, GROUP_TYPE_LIST, GroupType, getGroupPreset } from '@/lib/groupConfig';

const RoomLobby: React.FC = () => {
  const { rooms, createRoom, joinRoom, setCurrentRoom } = useRoom();
  const { user, signOut } = useAuth();
  const { t } = useLanguage();
  const [mode, setMode] = useState<'select' | 'create' | 'join'>('select');
  const [roomName, setRoomName] = useState('');
  const googleName = user?.user_metadata?.full_name || user?.user_metadata?.name || '';
  const avatarUrl = user?.user_metadata?.avatar_url || user?.user_metadata?.picture || '';
  const [displayName, setDisplayName] = useState(googleName);
  const [roomCode, setRoomCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [createdCode, setCreatedCode] = useState('');
  const [groupType, setGroupType] = useState<GroupType | null>(null);

  const handleCreate = async () => {
    if (!roomName.trim() || !displayName.trim() || !groupType) {
      toast.error(t('fillAllFields'));
      return;
    }
    setLoading(true);
    const room = await createRoom(roomName.trim(), displayName.trim(), groupType);
    setLoading(false);
    if (room) {
      setCreatedCode(room.code);
      toast.success(t('roomCreated'));
    } else {
      toast.error(t('roomCreateFailed'));
    }
  };

  const handleJoin = async () => {
    if (!roomCode.trim() || !displayName.trim()) {
      toast.error(t('fillAllFields'));
      return;
    }
    setLoading(true);
    const success = await joinRoom(roomCode.trim(), displayName.trim());
    setLoading(false);
    if (success) {
      toast.success(t('roomJoined'));
    } else {
      toast.error(t('roomJoinFailed'));
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast.success(t('copyCode'));
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        <div className="text-center">
          <h1 className="font-display font-bold text-3xl text-foreground mb-1">Z-Kanakku</h1>
          <p className="text-muted-foreground text-sm">{t('sharedExpenseTracker')}</p>
        </div>

        {createdCode && (
          <Card className="border-primary/30 bg-primary/5">
            <CardContent className="pt-6 text-center space-y-3">
              <p className="text-sm text-muted-foreground">{t('yourRoomCode')}</p>
              <div className="flex items-center justify-center gap-2">
                <span className="font-mono text-3xl font-bold tracking-[0.3em] text-primary">{createdCode}</span>
                <Button variant="ghost" size="icon" onClick={() => copyCode(createdCode)}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">{t('shareCodeDesc')}</p>
            </CardContent>
          </Card>
        )}

        {rooms.length > 0 && mode === 'select' && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="w-5 h-5" />
                {t('yourRooms')}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {rooms.map(room => (
                <button
                  key={room.id}
                  onClick={() => setCurrentRoom(room)}
                  className="w-full flex items-center justify-between p-3 rounded-lg border border-border hover:bg-accent/50 transition-colors text-left"
                >
                  <div>
                    <p className="font-medium text-foreground">{room.name}</p>
                    <p className="text-xs text-muted-foreground font-mono">{room.code}</p>
                  </div>
                  <DoorOpen className="w-5 h-5 text-muted-foreground" />
                </button>
              ))}
            </CardContent>
          </Card>
        )}

        {mode === 'select' && (
          <div className="grid grid-cols-2 gap-3">
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setMode('create')}
            >
              <CardContent className="pt-6 text-center space-y-2">
                <Plus className="w-8 h-8 mx-auto text-primary" />
                <p className="font-medium text-sm">{t('createNewRoom')}</p>
              </CardContent>
            </Card>
            <Card
              className="cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => setMode('join')}
            >
              <CardContent className="pt-6 text-center space-y-2">
                <LogIn className="w-8 h-8 mx-auto text-primary" />
                <p className="font-medium text-sm">{t('joinWithCode')}</p>
              </CardContent>
            </Card>
          </div>
        )}

        {mode === 'create' && (
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" onClick={() => { setMode('select'); setCreatedCode(''); setGroupType(null); }}>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
                <div>
                  <CardTitle>{t('createNewRoom')}</CardTitle>
                  <CardDescription>{groupType ? t('setupSharedExpense') : 'What type of group do you want to manage?'}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {!groupType ? (
                <div className="grid grid-cols-2 gap-2">
                  {GROUP_TYPE_LIST.map(g => (
                    <button
                      key={g}
                      onClick={() => {
                        setGroupType(g);
                        if (!roomName) setRoomName('');
                      }}
                      className="flex flex-col items-center gap-1 rounded-lg border border-border hover:border-primary/50 hover:bg-accent/50 transition-colors p-3 text-center"
                    >
                      <span className="text-2xl">{GROUP_PRESETS[g].emoji}</span>
                      <span className="text-xs font-medium">{GROUP_PRESETS[g].label}</span>
                    </button>
                  ))}
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">
                      {GROUP_PRESETS[groupType].emoji} {GROUP_PRESETS[groupType].label}
                    </span>
                    <button className="text-primary hover:underline" onClick={() => setGroupType(null)}>
                      Change
                    </button>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">{t('roomName')}</label>
                    <Input
                      placeholder={GROUP_PRESETS[groupType].roomNamePlaceholder}
                      value={roomName}
                      onChange={e => setRoomName(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">{t('yourDisplayName')}</label>
                    <Input
                      placeholder="e.g., Dilip Kumar"
                      value={displayName}
                      onChange={e => setDisplayName(e.target.value)}
                    />
                  </div>
                  <Button className="w-full" onClick={handleCreate} disabled={loading}>
                    {loading ? t('creating') : t('createRoom')}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        )}

        {mode === 'join' && (
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" onClick={() => setMode('select')}>
                  <ArrowLeft className="w-4 h-4" />
                </Button>
                <div>
                  <CardTitle>{t('joinRoom')}</CardTitle>
                  <CardDescription>{t('enterRoomCode')}</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-1 block">{t('roomCode')}</label>
                <Input
                  placeholder="e.g., A3X7K9"
                  value={roomCode}
                  onChange={e => setRoomCode(e.target.value.toUpperCase())}
                  maxLength={6}
                  className="font-mono text-lg tracking-widest text-center"
                />
              </div>
              <div>
                <label className="text-sm font-medium mb-1 block">{t('yourDisplayName')}</label>
                <Input
                  placeholder="e.g., Hari"
                  value={displayName}
                  onChange={e => setDisplayName(e.target.value)}
                />
              </div>
              <Button className="w-full" onClick={handleJoin} disabled={loading}>
                {loading ? t('joining') : t('joinRoom')}
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="flex items-center justify-center gap-3">
          {avatarUrl && (
            <Avatar className="w-8 h-8">
              <AvatarImage src={avatarUrl} alt={googleName} />
              <AvatarFallback>{googleName?.charAt(0)?.toUpperCase()}</AvatarFallback>
            </Avatar>
          )}
          <span className="text-sm text-muted-foreground">{user?.email}</span>
          <Button variant="ghost" size="sm" onClick={signOut} className="text-muted-foreground">
            <LogOut className="w-4 h-4 mr-1" />
            {t('signOut')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default RoomLobby;
