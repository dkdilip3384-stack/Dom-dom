import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useRoom } from '@/contexts/RoomContext';
import { ExpenseTracker } from '@/components/expense-tracker/ExpenseTracker';
import RoomLobby from './RoomLobby';
import PermissionsGate from './PermissionsGate';

const Index = () => {
  const { user, session, loading: authLoading } = useAuth();
  const { currentRoom, loading: roomLoading } = useRoom();
  const navigate = useNavigate();
  const [permissionsDone, setPermissionsDone] = useState(
    () => localStorage.getItem('z-kanakku-permissions-done') === 'true'
  );

  useEffect(() => {
    if (!authLoading && !user && !session?.user) {
      navigate('/auth');
    }
  }, [user, session, authLoading, navigate]);

  if (authLoading || roomLoading) return null;
  if (!user && !session?.user) return null;

  // Step 1: Permissions gate
  if (!permissionsDone) {
    return <PermissionsGate onComplete={() => setPermissionsDone(true)} />;
  }

  // Step 2: Room selection
  if (!currentRoom) {
    return <RoomLobby />;
  }

  // Step 3: Dashboard
  return <ExpenseTracker />;
};

export default Index;
