import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

export const RequireSuperAdmin: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading, isSuperAdmin } = useAuth();

  useEffect(() => {
    if (!loading && user && !isSuperAdmin) {
      toast.error('Access Denied — Super Admin only');
      // best-effort audit; ignore errors
      supabase.rpc('log_admin_event', {
        _action: 'unauthorized_access',
        _entity: 'super_admin_route',
        _status: 'denied',
        _detail: { path: window.location.pathname } as any,
      }).then(() => {}, () => {});
    }
  }, [loading, user, isSuperAdmin]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">Loading…</div>;
  }
  if (!user) return <Navigate to="/auth" replace />;
  if (!isSuperAdmin) return <Navigate to="/" replace />;
  return <>{children}</>;
};
