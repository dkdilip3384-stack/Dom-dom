import React, { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLanguage } from '@/hooks/useLanguage';

interface Notification {
  id: string;
  type: string;
  message: string;
  expense_description: string | null;
  is_read: boolean;
  created_at: string;
}

export const NotificationBell: React.FC = () => {
  const { t } = useLanguage();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [hasUnread, setHasUnread] = useState(false);

  useEffect(() => {
    fetchNotifications();

    const channel = supabase
      .channel('notifications-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, () => {
        fetchNotifications();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchNotifications = async () => {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (!error && data) {
      setNotifications(data);
      setHasUnread(data.some(n => !n.is_read));
    }
  };

  const markAllAsRead = async () => {
    const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id);
    if (unreadIds.length > 0) {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .in('id', unreadIds);
      
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      setHasUnread(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'edit': return '✏️';
      case 'delete': return '🗑️';
      case 'add': return '➕';
      default: return '📝';
    }
  };

  const getTypeBadgeClass = (type: string) => {
    switch (type) {
      case 'edit': return 'bg-yellow-100 text-yellow-800';
      case 'delete': return 'bg-red-100 text-red-800';
      case 'add': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" onClick={markAllAsRead}>
          <Bell className="w-5 h-5" />
          {hasUnread && (
            <span className="absolute top-1 right-1 w-2.5 h-2.5 rounded-full bg-destructive animate-pulse" />
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" className="w-80">
        <div className="px-3 py-2 border-b border-border">
          <h3 className="font-semibold text-sm">{t('notifications')}</h3>
        </div>
        <ScrollArea className="h-[300px]">
          {notifications.length === 0 ? (
            <div className="p-4 text-center text-muted-foreground text-sm">
              {t('noNotificationsYet')}
            </div>
          ) : (
            notifications.map(notification => (
              <DropdownMenuItem
                key={notification.id}
                className={`flex flex-col items-start gap-1 p-3 cursor-default ${
                  notification.is_read ? 'opacity-60' : ''
                }`}
              >
                <div className="flex items-center gap-2 w-full">
                  <span>{getTypeIcon(notification.type)}</span>
                  <span className={`text-xs px-1.5 py-0.5 rounded ${getTypeBadgeClass(notification.type)}`}>
                    {notification.type.toUpperCase()}
                  </span>
                  <span className="text-xs text-muted-foreground ml-auto">
                    {format(new Date(notification.created_at), 'dd MMM, HH:mm')}
                  </span>
                </div>
                <p className="text-sm">{notification.message}</p>
                {notification.expense_description && (
                  <p className="text-xs text-muted-foreground">
                    "{notification.expense_description}"
                  </p>
                )}
              </DropdownMenuItem>
            ))
          )}
        </ScrollArea>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
