import React, { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { RefreshCw, ShoppingBag, Settings2 } from 'lucide-react';
import { DEAL_CATEGORIES, DealRow, SUPER_ADMIN_EMAIL } from '@/lib/dealsConfig';
import { DealsAdminPanel } from './DealsAdminPanel';

const PAGE_SIZE = 20;

const SkeletonCard = () => (
  <div className="bg-card border border-border rounded-2xl overflow-hidden">
    <Skeleton className="aspect-square w-full" />
    <div className="p-3 space-y-2">
      <Skeleton className="h-3 w-1/3" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-2/3" />
      <Skeleton className="h-8 w-full mt-2" />
    </div>
  </div>
);

const DealCard: React.FC<{ deal: DealRow }> = ({ deal }) => (
  <div className="bg-card border border-border rounded-2xl overflow-hidden flex flex-col shadow-sm hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
    <div className="relative aspect-square bg-muted overflow-hidden">
      {deal.image_url ? (
        <img
          src={deal.image_url}
          alt={deal.title}
          loading="lazy"
          className="w-full h-full object-cover"
          onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = 'none')}
        />
      ) : (
        <div className="w-full h-full flex items-center justify-center">
          <ShoppingBag className="w-10 h-10 text-muted-foreground" />
        </div>
      )}
      {deal.badge && (
        <span className="absolute top-2 left-2 bg-primary text-primary-foreground text-[10px] font-bold px-2.5 py-1 rounded-full shadow-md backdrop-blur">
          {deal.badge}
        </span>
      )}
    </div>
    <div className="p-3 flex flex-col gap-1.5 flex-1">
      {deal.store_name && (
        <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold truncate">
          {deal.store_name}
        </p>
      )}
      <h3 className="text-sm font-semibold text-foreground line-clamp-2 leading-snug min-h-[2.5rem]">
        {deal.title}
      </h3>
      {deal.price != null && (
        <p className="text-base font-bold text-foreground">₹{deal.price.toLocaleString('en-IN')}</p>
      )}
      <Button
        size="sm"
        className="mt-auto w-full rounded-xl font-semibold"
        onClick={() => window.open(deal.affiliate_url, '_blank', 'noopener,noreferrer')}
      >
        Buy Now
      </Button>
    </div>
  </div>
);

export const DealsTab: React.FC = () => {
  const { user } = useAuth();
  const isSuperAdmin = user?.email?.toLowerCase() === SUPER_ADMIN_EMAIL;

  const [category, setCategory] = useState<string>('All');
  const [deals, setDeals] = useState<DealRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [adminOpen, setAdminOpen] = useState(false);

  const load = async (cat: string, pg: number, replace: boolean) => {
    setLoading(true);
    setError(null);
    let q = supabase
      .from('deals')
      .select('*')
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .range(pg * PAGE_SIZE, pg * PAGE_SIZE + PAGE_SIZE - 1);
    if (cat !== 'All') q = q.eq('category', cat);
    const { data, error: err } = await q;
    if (err) {
      setError(err.message);
      if (replace) setDeals([]);
      setHasMore(false);
    } else {
      const rows = (data || []) as DealRow[];
      setDeals((prev) => (replace ? rows : [...prev, ...rows]));
      setHasMore(rows.length === PAGE_SIZE);
    }
    setLoading(false);
  };

  useEffect(() => {
    setPage(0);
    load(category, 0, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  const loadMore = () => {
    const next = page + 1;
    setPage(next);
    load(category, next, false);
  };

  const empty = !loading && deals.length === 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-foreground">Hot Deals</h2>
        {isSuperAdmin && (
          <Button size="sm" variant="outline" onClick={() => setAdminOpen(true)} className="rounded-full">
            <Settings2 className="w-4 h-4 mr-1" /> Manage
          </Button>
        )}
      </div>

      <div className="-mx-4 px-4 overflow-x-auto scrollbar-none">
        <div className="flex gap-2 pb-1 min-w-max">
          {DEAL_CATEGORIES.map((c) => {
            const active = category === c.key;
            return (
              <button
                key={c.key}
                onClick={() => setCategory(c.key)}
                className={`px-3.5 py-2 rounded-full text-sm font-medium whitespace-nowrap border transition-all ${
                  active
                    ? 'bg-primary text-primary-foreground border-primary shadow-sm scale-[1.02]'
                    : 'bg-card text-foreground border-border hover:border-primary/50'
                }`}
              >
                <span className="mr-1">{c.emoji}</span>
                {c.key}
              </button>
            );
          })}
        </div>
      </div>

      {loading && deals.length === 0 ? (
        <div className="grid grid-cols-2 gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <SkeletonCard key={i} />
          ))}
        </div>
      ) : empty ? (
        <div className="text-center py-16 space-y-4">
          <ShoppingBag className="w-12 h-12 text-muted-foreground mx-auto opacity-50" />
          <p className="text-muted-foreground">{error || 'No deals in this category yet.'}</p>
          <Button onClick={() => load(category, 0, true)} variant="outline" className="rounded-full">
            <RefreshCw className="w-4 h-4 mr-2" /> Refresh
          </Button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3">
            {deals.map((d) => (
              <DealCard key={d.id} deal={d} />
            ))}
            {loading && Array.from({ length: 2 }).map((_, i) => <SkeletonCard key={`sk-${i}`} />)}
          </div>
          {hasMore && !loading && (
            <div className="flex justify-center pt-2">
              <Button variant="outline" onClick={loadMore} className="rounded-full">
                Load more
              </Button>
            </div>
          )}
          {!hasMore && deals.length > 0 && (
            <p className="text-center text-xs text-muted-foreground py-4">— end of deals —</p>
          )}
        </>
      )}

      {isSuperAdmin && (
        <DealsAdminPanel
          open={adminOpen}
          onOpenChange={setAdminOpen}
          onChanged={() => load(category, 0, true)}
        />
      )}
    </div>
  );
};
