import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Bell, Clock, Loader2, Save, CheckCircle2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useLanguage } from '@/hooks/useLanguage';

interface NotificationSettingsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const timeOptions = Array.from({ length: 24 }, (_, h) => {
  const hour = String(h).padStart(2, '0');
  return [
    { value: `${hour}:00`, label: `${h === 0 ? 12 : h > 12 ? h - 12 : h}:00 ${h < 12 ? 'AM' : 'PM'}` },
    { value: `${hour}:30`, label: `${h === 0 ? 12 : h > 12 ? h - 12 : h}:30 ${h < 12 ? 'AM' : 'PM'}` },
  ];
}).flat();

export const NotificationSettings: React.FC<NotificationSettingsProps> = ({ open, onOpenChange }) => {
  const { t } = useLanguage();
  const [selectedTime, setSelectedTime] = useState('08:00');
  const [savedTime, setSavedTime] = useState('08:00');
  const [loading, setLoading] = useState(false);
  const [initializing, setInitializing] = useState(true);

  useEffect(() => {
    if (open) loadCurrentTime();
  }, [open]);

  const loadCurrentTime = async () => {
    setInitializing(true);
    try {
      const { data } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'notification_time')
        .single();

      if (data?.value) {
        setSelectedTime(data.value);
        setSavedTime(data.value);
      }
    } catch {
      // Default to 08:00
    } finally {
      setInitializing(false);
    }
  };

  const handleSave = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('update-notification-schedule', {
        body: { time: selectedTime },
      });

      if (error) throw error;

      setSavedTime(selectedTime);
      toast.success(`${t('dailyDutyReminder')}: ${formatTimeLabel(selectedTime)} IST`);
    } catch (error) {
      console.error('Failed to update schedule:', error);
      toast.error('Failed to update notification time');
    } finally {
      setLoading(false);
    }
  };

  const formatTimeLabel = (time: string) => {
    const match = timeOptions.find(t => t.value === time);
    return match?.label || time;
  };

  const hasChanges = selectedTime !== savedTime;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-sm">
        <DialogHeader>
          <DialogTitle className="font-display flex items-center gap-2">
            <Bell className="w-5 h-5 text-primary" />
            {t('notifSettings')}
          </DialogTitle>
        </DialogHeader>

        {initializing ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-5">
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                {t('dailyDutyReminder')}
              </Label>
              <Select value={selectedTime} onValueChange={setSelectedTime}>
                <SelectTrigger>
                  <SelectValue placeholder={t('selectTime')} />
                </SelectTrigger>
                <SelectContent className="max-h-60">
                  {timeOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {t('notifDesc')}
              </p>
            </div>

            {!hasChanges && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/50 rounded-lg px-3 py-2">
                <CheckCircle2 className="w-4 h-4 text-positive" />
                {t('currentlySetTo')} {formatTimeLabel(savedTime)} IST
              </div>
            )}

            <Button
              onClick={handleSave}
              disabled={loading || !hasChanges}
              className="w-full"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t('updating')}
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {t('saveSchedule')}
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
