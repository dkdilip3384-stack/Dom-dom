import React from 'react';
import { FriendBalance } from '@/lib/types';
import { formatCurrencyUnsigned } from '@/lib/formatCurrency';
import { useLanguage } from '@/hooks/useLanguage';

interface HomeMarqueeProps {
  balances: FriendBalance[];
  rentDueDay?: number;
  announcement?: string;
}

const getOrdinal = (n: number) => {
  const s = ['th', 'st', 'nd', 'rd'];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

export const HomeMarquee: React.FC<HomeMarqueeProps> = ({ balances, rentDueDay = 8, announcement }) => {
  const { t } = useLanguage();
  const negativeBalances = balances.filter(b => b.finalBalance < 0);

  const pendingText = negativeBalances.length > 0
    ? `💸 ${t('pending')}: ${negativeBalances.map(b => `${b.friend.name} - ${formatCurrencyUnsigned(b.finalBalance)}`).join('  |  ')}`
    : t('allSettled');

  const reminderText = announcement && announcement.trim().length > 0
    ? `📢 ${announcement.trim()}`
    : `📢 ${t('rentReminder')} ${getOrdinal(rentDueDay)} ${t('isRentDay')}`;

  return (
    <div className="rounded-lg overflow-hidden">
      {/* Top Line - Announcement / Rent Reminder */}
      <div className="overflow-hidden" style={{ backgroundColor: 'hsl(0, 72%, 50%)' }}>
        <div className="marquee-scroll flex whitespace-nowrap py-3 px-4">
          <div className="inline-flex items-center marquee-content" style={{ fontSize: '18px' }}>
            <span className="font-bold text-white">{reminderText}</span>
            <span className="mx-16" />
            <span className="font-bold text-white">{reminderText}</span>
          </div>
        </div>
      </div>

      {/* Bottom Line - Pending Balances */}
      <div className="overflow-hidden" style={{ backgroundColor: 'hsl(48, 100%, 88%)' }}>
        <div className="marquee-scroll flex whitespace-nowrap py-3 px-4">
          <div className="inline-flex items-center marquee-content-slow" style={{ fontSize: '18px' }}>
            <span className="font-bold text-foreground">{pendingText}</span>
            <span className="mx-16" />
            <span className="font-bold text-foreground">{pendingText}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

