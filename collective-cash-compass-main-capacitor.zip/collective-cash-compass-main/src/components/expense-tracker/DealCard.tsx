import React from 'react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/hooks/useLanguage';
import { Tag } from 'lucide-react';

export interface Deal {
  id: string;
  title: string;
  description: string;
  merchant: string;
  logo: string | null;
  image: string | null;
  discountLabel: string | null;
  offerPrice: number | null;
  originalPrice: number | null;
  url: string;
}

export const DealCard: React.FC<{ deal: Deal }> = ({ deal }) => {
  const { t } = useLanguage();
  const img = deal.image || deal.logo;

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden flex flex-col shadow-sm hover:shadow-md transition-shadow">
      <div className="relative aspect-[4/3] bg-muted flex items-center justify-center overflow-hidden">
        {img ? (
          <img
            src={img}
            alt={deal.merchant || deal.title}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).style.display = 'none';
            }}
          />
        ) : (
          <Tag className="w-10 h-10 text-muted-foreground" />
        )}
        {deal.discountLabel && (
          <span className="absolute top-2 left-2 bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded-full shadow">
            {deal.discountLabel}
          </span>
        )}
      </div>
      <div className="p-3 flex flex-col gap-2 flex-1">
        {deal.merchant && (
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold truncate">
            {deal.merchant}
          </p>
        )}
        <h3 className="text-sm font-semibold text-foreground line-clamp-2 leading-snug">
          {deal.title}
        </h3>
        {deal.description && (
          <p className="text-xs text-muted-foreground line-clamp-2">{deal.description}</p>
        )}
        {(deal.offerPrice || deal.originalPrice) && (
          <div className="flex items-baseline gap-2">
            {deal.offerPrice != null && (
              <span className="text-sm font-bold text-foreground">₹{deal.offerPrice}</span>
            )}
            {deal.originalPrice != null && (
              <span className="text-xs text-muted-foreground line-through">
                ₹{deal.originalPrice}
              </span>
            )}
          </div>
        )}
        <Button
          size="sm"
          className="mt-auto w-full"
          onClick={() => window.open(deal.url, '_blank', 'noopener,noreferrer')}
        >
          {t('getDeal' as any)}
        </Button>
      </div>
    </div>
  );
};
