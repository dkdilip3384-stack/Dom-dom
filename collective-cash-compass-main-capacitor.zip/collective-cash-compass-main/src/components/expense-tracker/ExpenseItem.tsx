import React, { useState } from 'react';
import { Expense, Friend, ExpenseSplit } from '@/lib/types';
import { formatCurrencyUnsigned } from '@/lib/formatCurrency';
import { format } from 'date-fns';
import { Pencil, Trash2, Image, CreditCard, Banknote } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { ReceiptViewer } from './ReceiptViewer';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useLanguage } from '@/hooks/useLanguage';

interface ExpenseItemProps {
  expense: Expense;
  payer?: Friend;
  friends: Friend[];
  expenseSplits: ExpenseSplit[];
  onEdit: () => void;
  onDelete: () => void;
}

const categoryClasses: Record<string, string> = {
  Food: 'category-food',
  Rent: 'category-rent',
  Bills: 'category-bills',
  Others: 'category-others',
};

export const ExpenseItem: React.FC<ExpenseItemProps> = ({ 
  expense, 
  payer, 
  friends,
  expenseSplits,
  onEdit, 
  onDelete 
}) => {
  const { isAdmin } = useAuth();
  const { t } = useLanguage();
  const [receiptOpen, setReceiptOpen] = useState(false);

  const expenseSplitData = expenseSplits.filter(split => split.expense_id === expense.id);
  
  const getSharedWithText = () => {
    if (expenseSplitData.length === 0) return null;
    
    if (expenseSplitData.length === friends.length) {
      return `${t('sharedWith')}: ${t('sharedAll')}`;
    }
    
    const sharedNames = expenseSplitData
      .map(split => {
        const friend = friends.find(f => f.id === split.friend_id);
        return friend?.name;
      })
      .filter(Boolean)
      .join(', ');
    
    return sharedNames ? `${t('sharedWith')}: ${sharedNames}` : null;
  };

  const sharedWithText = getSharedWithText();

  return (
    <>
      <div className="expense-item animate-fade-in">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-medium text-foreground truncate">{expense.description}</h4>
              <span className={`category-badge ${categoryClasses[expense.category]}`}>
                {expense.category}
              </span>
            </div>
            <p className="text-sm text-muted-foreground flex items-center gap-1.5">
              {t('paidByLabel')} 
              <Avatar className="w-5 h-5 inline-flex">
                {payer?.avatar_url ? (
                  <AvatarImage src={payer.avatar_url} alt={payer.name} />
                ) : null}
                <AvatarFallback className="text-[10px] bg-primary/20 text-primary">
                  {payer?.name?.charAt(0)?.toUpperCase() || '?'}
                </AvatarFallback>
              </Avatar>
              <span className="font-medium text-foreground">{payer?.name || t('unknown')}</span>
            </p>
            {sharedWithText && (
              <p className="text-xs text-muted-foreground/70 mt-0.5">
                {sharedWithText}
              </p>
            )}
            {expense.payment_mode === 'split' && expense.online_amount !== null && expense.cash_amount !== null && (
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline" className="text-xs px-1.5 py-0 h-5 gap-1 bg-blue-500/10 text-blue-600 border-blue-200">
                  <CreditCard className="w-2.5 h-2.5" />
                  ₹{Number(expense.online_amount).toLocaleString('en-IN')}
                </Badge>
                <Badge variant="outline" className="text-xs px-1.5 py-0 h-5 gap-1 bg-green-500/10 text-green-600 border-green-200">
                  <Banknote className="w-2.5 h-2.5" />
                  ₹{Number(expense.cash_amount).toLocaleString('en-IN')}
                </Badge>
              </div>
            )}
            <div className="flex items-center gap-2 mt-1">
              <p className="text-xs text-muted-foreground">
                {format(new Date(expense.expense_date), 'dd MMM yyyy')}
              </p>
              {expense.receipt_url && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2 text-xs text-primary"
                  onClick={() => setReceiptOpen(true)}
                >
                  <Image className="w-3 h-3 mr-1" />
                  {t('receipt')}
                </Button>
              )}
            </div>
          </div>
          <div className="text-right flex flex-col items-end gap-2">
            <p className="text-lg font-display font-semibold text-foreground">
              {formatCurrencyUnsigned(expense.amount)}
            </p>
            {isAdmin && (
              <div className="flex items-center gap-1">
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onEdit}>
                  <Pencil className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={onDelete}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      {expense.receipt_url && (
        <ReceiptViewer
          open={receiptOpen}
          onOpenChange={setReceiptOpen}
          receiptUrl={expense.receipt_url}
          description={expense.description}
        />
      )}
    </>
  );
};
