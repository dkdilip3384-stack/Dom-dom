import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface ReceiptViewerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  receiptUrl: string;
  description: string;
}

export const ReceiptViewer: React.FC<ReceiptViewerProps> = ({
  open,
  onOpenChange,
  receiptUrl,
  description,
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display">Receipt - {description}</DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          <img
            src={receiptUrl}
            alt={`Receipt for ${description}`}
            className="w-full max-h-[60vh] object-contain rounded-lg"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};
