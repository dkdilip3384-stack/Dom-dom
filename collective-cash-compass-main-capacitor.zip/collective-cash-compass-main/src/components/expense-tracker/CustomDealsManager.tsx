import React, { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useRoom } from '@/contexts/RoomContext';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, Trash2, Tag, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';

export interface CustomDeal {
  id: string;
  room_id: string;
  category: string;
  title: string;
  description: string | null;
  merchant: string | null;
  image_url: string | null;
  discount_label: string | null;
  offer_price: number | null;
  original_price: number | null;
  url: string;
}

const CATEGORIES = [
  { value: 'all', label: 'All' },
  { value: 'food', label: '🍕 Food' },
  { value: 'grocery', label: '🛒 Grocery' },
  { value: 'room', label: '📦 Room Essentials' },
  { value: 'recharge', label: '⚡ Recharge' },
];

const emptyForm = {
  category: 'all',
  title: '',
  description: '',
  merchant: '',
  image_url: '',
  discount_label: '',
  offer_price: '',
  original_price: '',
  url: '',
};

export const CustomDealsManager: React.FC = () => {
  const { currentRoom } = useRoom();
  const { user } = useAuth();
  const [deals, setDeals] = useState<CustomDeal[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const load = async () => {
    if (!currentRoom) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('custom_deals')
      .select('*')
      .eq('room_id', currentRoom.id)
      .order('created_at', { ascending: false });
    if (error) toast.error(error.message);
    else setDeals((data || []) as CustomDeal[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentRoom?.id]);

  const handleSave = async () => {
    if (!currentRoom || !user) return;
    if (!form.title.trim() || !form.url.trim()) {
      toast.error('Title and Cuelinks URL are required');
      return;
    }
    setSaving(true);
    const { error } = await supabase.from('custom_deals').insert({
      room_id: currentRoom.id,
      created_by: user.id,
      category: form.category,
      title: form.title.trim(),
      description: form.description.trim() || null,
      merchant: form.merchant.trim() || null,
      image_url: form.image_url.trim() || null,
      discount_label: form.discount_label.trim() || null,
      offer_price: form.offer_price ? Number(form.offer_price) : null,
      original_price: form.original_price ? Number(form.original_price) : null,
      url: form.url.trim(),
    });
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success('Deal added');
    setForm(emptyForm);
    setShowForm(false);
    load();
  };

  const handleDelete = async (id: string) => {
    const { error } = await supabase.from('custom_deals').delete().eq('id', id);
    if (error) toast.error(error.message);
    else {
      toast.success('Deal removed');
      setDeals((d) => d.filter((x) => x.id !== id));
    }
  };

  return (
    <div className="pt-4 border-t border-border space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-foreground flex items-center gap-2">
          <Tag className="w-4 h-4" /> Custom Hot Deals
        </h3>
        <Button size="sm" variant="outline" onClick={() => setShowForm((s) => !s)}>
          <Plus className="w-4 h-4 mr-1" /> {showForm ? 'Close' : 'Add'}
        </Button>
      </div>

      {showForm && (
        <div className="space-y-2 p-3 bg-muted/40 rounded-lg border border-border">
          <div className="grid grid-cols-2 gap-2">
            <div className="col-span-2">
              <Label className="text-xs">Category</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((c) => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Product Title *</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Amul Butter 500g" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Description</Label>
              <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Short line about the deal" />
            </div>
            <div>
              <Label className="text-xs">Merchant</Label>
              <Input value={form.merchant} onChange={(e) => setForm({ ...form, merchant: e.target.value })} placeholder="BigBasket" />
            </div>
            <div>
              <Label className="text-xs">Badge</Label>
              <Input value={form.discount_label} onChange={(e) => setForm({ ...form, discount_label: e.target.value })} placeholder="50% OFF" />
            </div>
            <div>
              <Label className="text-xs">Offer Price ₹</Label>
              <Input type="number" inputMode="decimal" value={form.offer_price} onChange={(e) => setForm({ ...form, offer_price: e.target.value })} placeholder="149" />
            </div>
            <div>
              <Label className="text-xs">Original Price ₹</Label>
              <Input type="number" inputMode="decimal" value={form.original_price} onChange={(e) => setForm({ ...form, original_price: e.target.value })} placeholder="299" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Image URL</Label>
              <Input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="https://..." />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Cuelinks / Affiliate URL *</Label>
              <Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://linksredirect.com/..." />
            </div>
          </div>
          <Button className="w-full" onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Plus className="w-4 h-4 mr-2" />}
            Save Deal
          </Button>
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-4"><Loader2 className="w-4 h-4 animate-spin text-muted-foreground" /></div>
      ) : deals.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-2">No custom deals yet.</p>
      ) : (
        <div className="space-y-2">
          {deals.map((d) => (
            <div key={d.id} className="flex items-center gap-2 p-2 bg-card border border-border rounded-lg">
              <div className="w-10 h-10 rounded bg-muted overflow-hidden flex-shrink-0 flex items-center justify-center">
                {d.image_url ? (
                  <img src={d.image_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <Tag className="w-4 h-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{d.title}</p>
                <p className="text-[10px] text-muted-foreground truncate">
                  {d.category} {d.offer_price ? `· ₹${d.offer_price}` : ''}
                </p>
              </div>
              <a href={d.url} target="_blank" rel="noopener noreferrer" className="p-2 text-muted-foreground hover:text-primary">
                <ExternalLink className="w-4 h-4" />
              </a>
              <button onClick={() => handleDelete(d.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
