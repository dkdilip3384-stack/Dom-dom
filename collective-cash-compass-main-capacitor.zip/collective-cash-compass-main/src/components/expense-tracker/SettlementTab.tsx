import React from 'react';
import { Settlement, FriendBalance } from '@/lib/types';
import { formatCurrencyUnsigned, formatCurrency } from '@/lib/formatCurrency';
import { ArrowRight, CheckCircle2, TrendingUp, TrendingDown, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useLanguage } from '@/hooks/useLanguage';

interface SettlementTabProps {
  settlements: Settlement[];
  balances: FriendBalance[];
}

export const SettlementTab: React.FC<SettlementTabProps> = ({ settlements, balances }) => {
  const { t } = useLanguage();
  const positiveBalances = balances.filter(b => b.finalBalance > 0);
  const negativeBalances = balances.filter(b => b.finalBalance < 0);

  const sendWhatsAppShare = (toName: string, amount: number) => {
    const message = encodeURIComponent(
      `Hello ${toName}, pending settlement amount: ₹${Math.abs(amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}. Please settle soon.`
    );
    const whatsappUrl = `https://wa.me/?text=${message}`;
    window.open(whatsappUrl, '_blank');
    toast.success(t('openingWhatsapp'));
  };

  return (
    <div className="space-y-6">
      {/* Balance Summary */}
      <div>
        <h2 className="font-display font-semibold text-lg mb-4">{t('balanceSummary')}</h2>
        <div className="grid grid-cols-2 gap-4">
          {/* Positive Balances */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-positive">
              <TrendingUp className="w-4 h-4" />
              <span>{t('toReceive')}</span>
            </div>
            {positiveBalances.length > 0 ? (
              positiveBalances.map(b => (
                <div key={b.friend.id} className="bg-positive-light rounded-lg p-3">
                  <p className="font-medium text-sm">{b.friend.name}</p>
                  <p className="text-positive font-display font-bold">
                    {formatCurrency(b.finalBalance)}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">{t('noOneToReceive')}</p>
            )}
          </div>

          {/* Negative Balances */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm font-medium text-negative">
              <TrendingDown className="w-4 h-4" />
              <span>{t('toPay')}</span>
            </div>
            {negativeBalances.length > 0 ? (
              negativeBalances.map(b => (
                <div key={b.friend.id} className="bg-negative-light rounded-lg p-3">
                  <p className="font-medium text-sm">{b.friend.name}</p>
                  <p className="text-negative font-display font-bold">
                    {formatCurrency(b.finalBalance)}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">{t('noOneToPay')}</p>
            )}
          </div>
        </div>
      </div>

      {/* Settlements */}
      <div>
        <h2 className="font-display font-semibold text-lg mb-4">{t('suggestedSettlements')}</h2>
        {settlements.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <div className="w-16 h-16 rounded-full bg-positive/10 flex items-center justify-center mb-4">
              <CheckCircle2 className="w-8 h-8 text-positive" />
            </div>
            <h3 className="font-display font-semibold text-lg mb-2">{t('allSettledTitle')}</h3>
            <p className="text-muted-foreground text-sm">
              {t('everyoneEven')}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {settlements.map((settlement, index) => (
              <div
                key={index}
                className="bg-card rounded-xl p-4 border border-border animate-fade-in"
              >
                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <p className="font-medium text-negative">{settlement.from.name}</p>
                    <p className="text-xs text-negative/70">{t('pays')}</p>
                  </div>
                  <div className="settlement-arrow">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                  <div className="flex-1 text-right">
                    <p className="font-medium text-positive">{settlement.to.name}</p>
                    <p className="text-xs text-positive/70">{t('receives')}</p>
                  </div>
                </div>
                <div className="mt-3 pt-3 border-t border-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-negative font-medium">{t('paysLabel')}</span>
                      <p className="text-xl font-display font-bold text-negative">
                        {formatCurrencyUnsigned(settlement.amount)}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2 text-positive border-positive hover:bg-positive/10"
                      onClick={() => sendWhatsAppShare(settlement.from.name, settlement.amount)}
                    >
                      <MessageCircle className="w-4 h-4" />
                      {t('whatsappShare')}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
