import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Friend } from '@/lib/types';
import { format } from 'date-fns';
import { CalendarIcon, CreditCard, Banknote, ChevronDown, ChevronUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ReceiptCapture } from './ReceiptCapture';
import { toast } from 'sonner';
import { speakSuccess } from '@/lib/confetti';
import { SuccessPopup } from './SuccessPopup';
import { useLanguage } from '@/hooks/useLanguage';
import { useRoom } from '@/contexts/RoomContext';
import { getGroupPreset } from '@/lib/groupConfig';

interface AddExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  friends: Friend[];
  onSubmit: (
    description: string,
    amount: number,
    paidBy: string,
    expenseDate: Date,
    splitAmong: string[],
    receiptUrl: string | null,
    paymentMode: 'single' | 'split',
    onlineAmount: number | null,
    cashAmount: number | null
  ) => Promise<boolean>;
  onSuccess?: () => void;
}

export const AddExpenseDialog: React.FC<AddExpenseDialogProps> = ({
  open,
  onOpenChange,
  friends,
  onSubmit,
  onSuccess,
}) => {
  const { t } = useLanguage();
  const { currentRoom } = useRoom();
  const preset = getGroupPreset(currentRoom?.group_type);
  const expensePlaceholder = `e.g., ${preset.expenseExamples.slice(0, 2).join(', ')}`;
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');
  const [paidBy, setPaidBy] = useState('');
  const [expenseDate, setExpenseDate] = useState<Date>(new Date());
  const [splitAmong, setSplitAmong] = useState<string[]>([]);
  const [receiptUrl, setReceiptUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const [successPopupOpen, setSuccessPopupOpen] = useState(false);
  
  const [showSplitPayment, setShowSplitPayment] = useState(false);
  const [onlineAmount, setOnlineAmount] = useState('');
  const [cashAmount, setCashAmount] = useState('');

  useEffect(() => {
    if (showSplitPayment && amount && onlineAmount) {
      const total = parseFloat(amount) || 0;
      const online = parseFloat(onlineAmount) || 0;
      const cash = Math.max(0, total - online);
      setCashAmount(cash > 0 ? cash.toFixed(2) : '');
    }
  }, [onlineAmount, amount, showSplitPayment]);

  useEffect(() => {
    if (showSplitPayment && amount && cashAmount && !onlineAmount) {
      const total = parseFloat(amount) || 0;
      const cash = parseFloat(cashAmount) || 0;
      const online = Math.max(0, total - cash);
      setOnlineAmount(online > 0 ? online.toFixed(2) : '');
    }
  }, [cashAmount, amount, showSplitPayment, onlineAmount]);

  const resetForm = () => {
    setAmount('');
    setDescription('');
    setPaidBy('');
    setExpenseDate(new Date());
    setSplitAmong([]);
    setReceiptUrl(null);
    setShowSplitPayment(false);
    setOnlineAmount('');
    setCashAmount('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const parsedAmount = parseFloat(amount);
    const trimmedDesc = description.trim();

    if (!trimmedDesc || !amount || !paidBy || splitAmong.length === 0) {
      toast.error(t('fillAllFields'));
      return;
    }

    if (parsedAmount <= 0 || !isFinite(parsedAmount)) {
      toast.error('Amount must be a positive number');
      return;
    }

    if (trimmedDesc.length > 500) {
      toast.error('Description must be 500 characters or less');
      return;
    }

    if (showSplitPayment) {
      const total = parseFloat(amount) || 0;
      const online = parseFloat(onlineAmount) || 0;
      const cash = parseFloat(cashAmount) || 0;
      
      if (Math.abs((online + cash) - total) > 0.01) {
        toast.error('Online + Cash amounts must equal Total Amount');
        return;
      }
    }

    setLoading(true);
    const success = await onSubmit(
      description.trim(),
      parseFloat(amount),
      paidBy,
      expenseDate,
      splitAmong,
      receiptUrl,
      showSplitPayment ? 'split' : 'single',
      showSplitPayment ? (parseFloat(onlineAmount) || 0) : null,
      showSplitPayment ? (parseFloat(cashAmount) || 0) : null
    );
    setLoading(false);

    if (success) {
      speakSuccess();
      resetForm();
      onOpenChange(false);
      setSuccessPopupOpen(true);
      onSuccess?.();
    }
  };

  const toggleSplit = (friendId: string) => {
    setSplitAmong(prev =>
      prev.includes(friendId)
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const selectAllForSplit = () => {
    setSplitAmong(friends.map(f => f.id));
  };

  const handleInputFocus = useCallback((e: React.FocusEvent<HTMLInputElement>) => {
    setTimeout(() => {
      e.target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  }, []);

  const handleToggleSplitPayment = () => {
    setShowSplitPayment(!showSplitPayment);
    if (!showSplitPayment) {
      setOnlineAmount('');
      setCashAmount('');
    }
  };

  return (
    <>
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] flex flex-col p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-6 pt-6 pb-2 shrink-0">
          <DialogTitle className="font-display">{t('addNewExpense')}</DialogTitle>
        </DialogHeader>
        <div className="flex-1 overflow-y-auto px-6" style={{ maxHeight: 'calc(90vh - 80px)' }}>
          <form ref={formRef} onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="description">{t('expenseReason')} *</Label>
              <Input
                id="description"
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                onFocus={handleInputFocus}
                placeholder={expensePlaceholder}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">{t('totalAmount')} *</Label>
              <Input
                id="amount"
                type="number"
                inputMode="decimal"
                step="0.01"
                min="0"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value);
                  if (showSplitPayment) {
                    setOnlineAmount('');
                    setCashAmount('');
                  }
                }}
                onFocus={handleInputFocus}
                placeholder="0.00"
                required
              />
            </div>

            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleToggleSplitPayment}
              className={cn(
                "w-full justify-between text-sm",
                showSplitPayment && "border-primary bg-primary/5"
              )}
            >
              <span className="flex items-center gap-2">
                <CreditCard className="w-4 h-4" />
                {t('splitPaymentMode')}
              </span>
              {showSplitPayment ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </Button>

            {showSplitPayment && (
              <div className="space-y-3 p-3 rounded-lg border border-border bg-muted/30 animate-fade-in">
                <p className="text-xs text-muted-foreground">
                  {t('splitPaymentDesc')}
                </p>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label htmlFor="onlineAmount" className="text-xs flex items-center gap-1">
                      <CreditCard className="w-3 h-3" />
                      {t('online')}
                    </Label>
                    <Input
                      id="onlineAmount"
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      min="0"
                      max={amount || undefined}
                      value={onlineAmount}
                      onChange={(e) => {
                        setOnlineAmount(e.target.value);
                        const total = parseFloat(amount) || 0;
                        const online = parseFloat(e.target.value) || 0;
                        const cash = Math.max(0, total - online);
                        setCashAmount(cash > 0 ? cash.toFixed(2) : '');
                      }}
                      onFocus={handleInputFocus}
                      placeholder="0.00"
                      className="h-9"
                    />
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="cashAmount" className="text-xs flex items-center gap-1">
                      <Banknote className="w-3 h-3" />
                      {t('cash')}
                    </Label>
                    <Input
                      id="cashAmount"
                      type="number"
                      inputMode="decimal"
                      step="0.01"
                      min="0"
                      max={amount || undefined}
                      value={cashAmount}
                      onChange={(e) => {
                        setCashAmount(e.target.value);
                        const total = parseFloat(amount) || 0;
                        const cash = parseFloat(e.target.value) || 0;
                        const online = Math.max(0, total - cash);
                        setOnlineAmount(online > 0 ? online.toFixed(2) : '');
                      }}
                      onFocus={handleInputFocus}
                      placeholder="0.00"
                      className="h-9"
                    />
                  </div>
                </div>

                {amount && (onlineAmount || cashAmount) && (
                  <div className={cn(
                    "text-xs px-2 py-1 rounded",
                    Math.abs((parseFloat(onlineAmount) || 0) + (parseFloat(cashAmount) || 0) - (parseFloat(amount) || 0)) <= 0.01
                      ? "bg-green-500/10 text-green-600"
                      : "bg-destructive/10 text-destructive"
                  )}>
                    {Math.abs((parseFloat(onlineAmount) || 0) + (parseFloat(cashAmount) || 0) - (parseFloat(amount) || 0)) <= 0.01
                      ? t('amountsMatch')
                      : `₹${((parseFloat(onlineAmount) || 0) + (parseFloat(cashAmount) || 0)).toFixed(2)} ≠ ₹${parseFloat(amount)?.toFixed(2) || '0.00'}`
                    }
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2">
              <Label>{t('paidBy')} *</Label>
              <Select value={paidBy} onValueChange={setPaidBy} required>
                <SelectTrigger>
                  <SelectValue placeholder={t('selectWhoPaid')} />
                </SelectTrigger>
                <SelectContent>
                  {friends.map(friend => (
                    <SelectItem key={friend.id} value={friend.id}>
                      {friend.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>{t('splitAmong')} *</Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={selectAllForSplit}
                  className="text-xs h-7"
                >
                  {t('selectAll')}
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {friends.map(friend => (
                  <label
                    key={friend.id}
                    className="flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-muted cursor-pointer"
                  >
                    <Checkbox
                      checked={splitAmong.includes(friend.id)}
                      onCheckedChange={() => toggleSplit(friend.id)}
                    />
                    <span className="text-sm">{friend.name}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm">{t('receiptPhoto')}</Label>
              <div className="max-w-[200px]">
                <ReceiptCapture
                  receiptUrl={receiptUrl}
                  onReceiptChange={setReceiptUrl}
                  required={false}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t('date')}</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      'w-full justify-start text-left font-normal',
                      !expenseDate && 'text-muted-foreground'
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {expenseDate ? format(expenseDate, 'PPP') : <span>{t('pickDate')}</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={expenseDate}
                    onSelect={(date) => date && setExpenseDate(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex gap-2 pt-4 pb-32">
              <Button
                type="button"
                variant="outline"
                className="flex-1"
                onClick={() => onOpenChange(false)}
              >
                {t('cancel')}
              </Button>
              <Button
                type="submit"
                className="flex-1"
                disabled={loading || !amount || !description.trim() || !paidBy || splitAmong.length === 0}
              >
                {loading ? t('adding') : t('addExpenseBtn')}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>

    <SuccessPopup open={successPopupOpen} onOpenChange={setSuccessPopupOpen} />
    </>
  );
};
