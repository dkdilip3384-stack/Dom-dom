import React, { useEffect, useCallback } from 'react';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import { CheckCircle2 } from 'lucide-react';

const tamilQuotes = [
  'பணம் என்பது ஒரு நல்ல வேலைக்காரன், ஆனால் மோசமான எஜமான்.',
  'சிக்கனம் என்பது பெரிய வருமானம்.',
  'சேமிப்பு என்பது எதிர்காலத்தின் அடித்தளம்.',
  'செலவை குறை, சேமிப்பை கூட்டு.',
  'பணத்தை மதி, அது உன்னை மதிக்கும்.',
  'இன்றைய சேமிப்பு நாளைய செல்வம்.',
  'வீண் செலவு வறுமையின் தோழன்.',
  'கடன் இல்லாத வாழ்வே நிம்மதியான தூக்கத்தைத் தரும்.',
  'உங்கள் தேவைகளை அறியுங்கள், ஆசைகளை கட்டுப்படுத்துங்கள்.',
  'கொஞ்சம் கொஞ்சமாக சேர்ப்பது பெரிய செல்வமாகும்.',
  'பணம் இருக்கும் போது சேமி, இல்லாத போது அழாதே.',
  'வருவாய்க்கு மேல் செலவு செய்யாதே.',
  'அறிவுடன் செலவு செய், செல்வம் வளரும்.',
  'சிறு துளி பெரு வெள்ளம், சிறு சேமிப்பு பெரு செல்வம்.',
  'கடன் வாங்காமல் வாழ்வது உண்மையான சுதந்திரம்.',
  'பணத்தின் மதிப்பை அறிந்தவன் வாழ்வில் வெற்றி பெறுவான்.',
  'இன்று நீ செய்யும் சிறு சேமிப்பு, உன்னுடைய அவசர காலத்தின் உற்ற நண்பன்.',
  'செல்வம் சேர்ப்பது கடினம், காப்பது அதைவிட கடினம்.',
  'பொறுமையும் சேமிப்பும் வெற்றியின் இரட்டை தூண்கள்.',
  'புத்திசாலி பணத்தை வேலை செய்ய வைப்பான், முட்டாள் பணத்துக்காக வேலை செய்வான்.',
  'பணத்தைச் சம்பாதிப்பது கலை என்றால், அதைச் சேமிப்பது மிகப்பெரிய சாதனை.',
];

const playClickSound = () => {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.15);

    // Second pop
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.frequency.setValueAtTime(1200, ctx.currentTime + 0.05);
    osc2.type = 'sine';
    gain2.gain.setValueAtTime(0.2, ctx.currentTime + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
    osc2.start(ctx.currentTime + 0.05);
    osc2.stop(ctx.currentTime + 0.2);
  } catch {
    // silent
  }
};

const getRandomQuote = (): string => {
  return tamilQuotes[Math.floor(Math.random() * tamilQuotes.length)];
};

interface SuccessPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const SuccessPopup: React.FC<SuccessPopupProps> = ({ open, onOpenChange }) => {
  const [quote, setQuote] = React.useState(getRandomQuote);

  useEffect(() => {
    if (open) {
      setQuote(getRandomQuote());
      playClickSound();
    }
  }, [open]);

  const handleClose = useCallback(() => {
    onOpenChange(false);
  }, [onOpenChange]);

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-sm text-center overflow-hidden">
        <AlertDialogHeader className="items-center space-y-4">
          <CheckCircle2 className="w-16 h-16 text-green-500 mb-1 animate-bounce" />
          <AlertDialogTitle className="text-xl font-extrabold text-foreground leading-snug">
            அமௌன்ட் வெற்றிகரமாக சேர்க்கப்பட்டது!
          </AlertDialogTitle>
          <AlertDialogDescription className="text-base font-bold text-emerald-700 dark:text-emerald-400 mt-4 leading-loose">
            "{quote}"
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter className="justify-center sm:justify-center mt-4">
          <AlertDialogAction onClick={handleClose} className="min-w-[120px]">
            சரி
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
