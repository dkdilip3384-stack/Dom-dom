import React, { useState, useMemo } from 'react';
import { Expense, Friend, ExpenseSplit, FriendBalance } from '@/lib/types';
import { ExpenseItem } from './ExpenseItem';
import { EditExpenseDialog } from './EditExpenseDialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { FileText, Download, Search, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent } from '@/components/ui/card';
import { formatCurrencyUnsigned } from '@/lib/formatCurrency';
import { format } from 'date-fns';
import { jsPDF } from 'jspdf';
import { toast } from 'sonner';
import { useLanguage } from '@/hooks/useLanguage';

interface HistoryTabProps {
  expenses: Expense[];
  friends: Friend[];
  expenseSplits: ExpenseSplit[];
  balances: FriendBalance[];
  totalExpense: number;
  onUpdateExpense: (
    id: string,
    description: string,
    amount: number,
    paidBy: string,
    expenseDate: Date,
    splitAmong: string[]
  ) => Promise<boolean>;
  onDeleteExpense: (id: string) => Promise<boolean>;
}

export const HistoryTab: React.FC<HistoryTabProps> = ({
  expenses,
  friends,
  expenseSplits,
  balances,
  totalExpense,
  onUpdateExpense,
  onDeleteExpense,
}) => {
  const { t } = useLanguage();
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [deletingExpense, setDeletingExpense] = useState<Expense | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMonth, setSelectedMonth] = useState<string>('all');

  const getPayer = (paidBy: string) => friends.find(f => f.id === paidBy);

  const getSplitsForExpense = (expenseId: string) => {
    return expenseSplits
      .filter(s => s.expense_id === expenseId)
      .map(s => s.friend_id);
  };

  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    expenses.forEach(e => {
      const d = new Date(e.expense_date);
      months.add(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`);
    });
    return Array.from(months).sort().reverse();
  }, [expenses]);

  const filteredExpenses = useMemo(() => {
    return expenses.filter(expense => {
      const payer = getPayer(expense.paid_by);
      const matchesSearch = !searchQuery ||
        (payer?.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
        expense.description.toLowerCase().includes(searchQuery.toLowerCase());

      const d = new Date(expense.expense_date);
      const expMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const matchesMonth = selectedMonth === 'all' || expMonth === selectedMonth;

      return matchesSearch && matchesMonth;
    });
  }, [expenses, searchQuery, selectedMonth, friends]);

  const totalPending = useMemo(() => {
    return balances
      .filter(b => b.finalBalance < 0)
      .reduce((sum, b) => sum + Math.abs(b.finalBalance), 0);
  }, [balances]);

  const exportToPDF = () => {
    try {
      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();
      let yPos = 20;
      const lineHeight = 7;
      const margin = 15;

      doc.setFontSize(20);
      doc.setFont('helvetica', 'bold');
      doc.text(t('pdfTitle'), pageWidth / 2, yPos, { align: 'center' });
      yPos += lineHeight * 2;

      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(`${t('generatedOn')}: ${format(new Date(), 'dd MMM yyyy, HH:mm')}`, pageWidth / 2, yPos, { align: 'center' });
      yPos += lineHeight * 2;

      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(t('summary').toUpperCase(), margin, yPos);
      yPos += lineHeight;

      doc.setFontSize(11);
      doc.setFont('helvetica', 'normal');
      doc.text(`${t('totalGroupExpense')}: Rs ${totalExpense.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, margin, yPos);
      yPos += lineHeight;
      doc.text(`${t('totalMembers')}: ${friends.length}`, margin, yPos);
      yPos += lineHeight * 2;

      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(t('memberBalancesTitle').toUpperCase(), margin, yPos);
      yPos += lineHeight;

      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      balances.forEach(balance => {
        const sign = balance.finalBalance >= 0 ? '+' : '-';
        const absBalance = Math.abs(balance.finalBalance);
        doc.text(
          `${balance.friend.name}: ${sign}Rs ${absBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
          margin,
          yPos
        );
        yPos += lineHeight;
      });
      yPos += lineHeight;

      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(t('expenseHistoryTitle').toUpperCase(), margin, yPos);
      yPos += lineHeight;

      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');

      expenses.forEach((expense, index) => {
        if (yPos > 270) {
          doc.addPage();
          yPos = 20;
        }

        const payer = getPayer(expense.paid_by);
        const splits = getSplitsForExpense(expense.id);
        const splitNames = splits.map(id => friends.find(f => f.id === id)?.name || t('unknown')).join(', ');

        doc.setFont('helvetica', 'bold');
        doc.text(`${index + 1}. ${expense.description}`, margin, yPos);
        yPos += lineHeight * 0.8;

        doc.setFont('helvetica', 'normal');
        doc.text(`   ${t('date')}: ${format(new Date(expense.expense_date), 'dd MMM yyyy')}`, margin, yPos);
        yPos += lineHeight * 0.8;
        doc.text(`   ${t('amount')}: Rs ${expense.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`, margin, yPos);
        yPos += lineHeight * 0.8;
        
        if (expense.payment_mode === 'split' && expense.online_amount !== null && expense.cash_amount !== null) {
          doc.text(`   ${t('payment')}: Online Rs ${Number(expense.online_amount).toLocaleString('en-IN')} + Cash Rs ${Number(expense.cash_amount).toLocaleString('en-IN')}`, margin, yPos);
          yPos += lineHeight * 0.8;
        }
        
        doc.text(`   ${t('category')}: ${expense.category} | ${t('paidByLabel')}: ${payer?.name || t('unknown')}`, margin, yPos);
        yPos += lineHeight * 0.8;
        doc.text(`   ${t('splitAmongLabel')}: ${splitNames}`, margin, yPos);
        yPos += lineHeight * 1.2;
      });

      const fileName = `Z-Kanakku-Report_${format(new Date(), 'yyyy-MM-dd')}.pdf`;
      const pdfBlob = doc.output('blob');
      const blobUrl = URL.createObjectURL(pdfBlob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = fileName;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();

      setTimeout(() => {
        document.body.removeChild(link);
        const isWebView = /wv|WebView/i.test(navigator.userAgent) || 
                          (window as any).Android !== undefined ||
                          /(iPhone|iPad).*AppleWebKit(?!.*Safari)/i.test(navigator.userAgent);
        if (isWebView) {
          window.open(blobUrl, '_blank');
        }
        setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      }, 100);
      
      toast.success(t('pdfDownloaded'));
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast.error(t('pdfFailed'));
    }
  };

  if (expenses.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
          <FileText className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="font-display font-semibold text-lg mb-2">{t('noExpensesYet')}</h3>
        <p className="text-muted-foreground text-sm">
          {t('addFirstExpense')}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-display font-semibold text-lg">{t('expenseHistory')}</h2>
        <Button variant="outline" size="sm" onClick={exportToPDF}>
          <Download className="w-4 h-4 mr-2" />
          {t('exportPdf')}
        </Button>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={t('searchPlaceholder')}
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder={t('allMonths')} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('allMonths')}</SelectItem>
            {availableMonths.map(m => (
              <SelectItem key={m} value={m}>
                {format(new Date(m + '-01'), 'MMM yyyy')}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {totalPending > 0 && (
        <Card className="border-destructive/30 bg-destructive/5">
          <CardContent className="flex items-center gap-3 p-3">
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0" />
            <div>
              <p className="text-sm font-semibold text-destructive">{t('totalPending')}</p>
              <p className="text-lg font-bold text-destructive">
                ₹{totalPending.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {filteredExpenses.length === 0 ? (
          <p className="text-center text-muted-foreground py-8 text-sm">{t('noExpensesMatch')}</p>
        ) : (
          filteredExpenses.map(expense => (
            <ExpenseItem
              key={expense.id}
              expense={expense}
              payer={getPayer(expense.paid_by)}
              friends={friends}
              expenseSplits={expenseSplits}
              onEdit={() => setEditingExpense(expense)}
              onDelete={() => setDeletingExpense(expense)}
            />
          ))
        )}
      </div>

      {editingExpense && (
        <EditExpenseDialog
          open={!!editingExpense}
          onOpenChange={(open) => !open && setEditingExpense(null)}
          expense={editingExpense}
          friends={friends}
          initialSplits={getSplitsForExpense(editingExpense.id)}
          onSubmit={async (description, amount, paidBy, expenseDate, splitAmong) => {
            const success = await onUpdateExpense(
              editingExpense.id,
              description,
              amount,
              paidBy,
              expenseDate,
              splitAmong
            );
            if (success) setEditingExpense(null);
            return success;
          }}
        />
      )}

      <AlertDialog open={!!deletingExpense} onOpenChange={(open) => !open && setDeletingExpense(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t('deleteExpense')}</AlertDialogTitle>
            <AlertDialogDescription>
              {t('deleteExpenseConfirm')} "{deletingExpense?.description}"? {t('cannotUndo')}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t('cancel')}</AlertDialogCancel>
            <AlertDialogAction
              onClick={async () => {
                if (deletingExpense) {
                  await onDeleteExpense(deletingExpense.id);
                  setDeletingExpense(null);
                }
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {t('delete')}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};
