import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Friend } from '@/lib/types';
import { formatCurrency } from '@/lib/formatCurrency';
import { Shield, Pencil, Save, X, UserPlus, Trash2, Mail, Loader2, Calendar, Megaphone, Users } from 'lucide-react';
import { AudioUpload } from './AudioUpload';
import { Textarea } from '@/components/ui/textarea';
import { GROUP_PRESETS, GROUP_TYPE_LIST } from '@/lib/groupConfig';

import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useRoom } from '@/contexts/RoomContext';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '@/hooks/useLanguage';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';

interface AdminPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  friends: Friend[];
  onUpdateFriend: (id: string, name: string, initialBalance: number) => Promise<boolean>;
  onAddFriend: (name: string, initialBalance: number) => Promise<boolean>;
  onDeleteFriend: (id: string) => Promise<boolean>;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  open,
  onOpenChange,
  friends,
  onUpdateFriend,
  onAddFriend,
  onDeleteFriend,
}) => {
  const { currentRoom, leaveRoom, updateGroupType } = useRoom();
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showDeleteRoom, setShowDeleteRoom] = useState(false);
  const [deletingRoom, setDeletingRoom] = useState(false);
  const [editName, setEditName] = useState('');
  const [editBalance, setEditBalance] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Add friend state
  const [showAddForm, setShowAddForm] = useState(false);
  const [newFriendName, setNewFriendName] = useState('');
  const [newFriendBalance, setNewFriendBalance] = useState('0');
  
  // Delete confirmation
  const [deletingFriend, setDeletingFriend] = useState<Friend | null>(null);

  // Email mapping state
  const [friendEmails, setFriendEmails] = useState<Record<string, string>>({});
  const [editingEmail, setEditingEmail] = useState<string | null>(null);
  const [emailInput, setEmailInput] = useState('');
  const [savingEmail, setSavingEmail] = useState(false);

  // Rent date state
  const [rentDay, setRentDay] = useState<number>(8);
  const [savingRentDay, setSavingRentDay] = useState(false);

  // Announcement state
  const [announcement, setAnnouncement] = useState<string>('');
  const [savingAnnouncement, setSavingAnnouncement] = useState(false);

  // Load friend emails on open
  useEffect(() => {
    if (open) {
      loadFriendEmails();
      loadRentDay();
      loadAnnouncement();
    }
  }, [open]);

  const loadAnnouncement = async () => {
    if (!currentRoom) return;
    const { data } = await supabase
      .from('app_settings')
      .select('value')
      .eq('room_id', currentRoom.id)
      .eq('key', 'announcement')
      .maybeSingle();
    setAnnouncement(data?.value ?? '');
  };

  const saveAnnouncement = async () => {
    if (!currentRoom) return;
    setSavingAnnouncement(true);
    try {
      const { data: existing } = await supabase
        .from('app_settings')
        .select('id')
        .eq('room_id', currentRoom.id)
        .eq('key', 'announcement')
        .maybeSingle();
      if (existing) {
        await supabase.from('app_settings').update({ value: announcement }).eq('id', existing.id);
      } else {
        await supabase.from('app_settings').insert({ room_id: currentRoom.id, key: 'announcement', value: announcement });
      }
      toast.success('Announcement saved!');
    } catch {
      toast.error('Failed to save announcement');
    } finally {
      setSavingAnnouncement(false);
    }
  };

  const loadRentDay = async () => {
    if (!currentRoom) return;
    const { data } = await supabase
      .from('app_settings')
      .select('value')
      .eq('room_id', currentRoom.id)
      .eq('key', 'rent_due_day')
      .maybeSingle();
    if (data?.value) setRentDay(parseInt(data.value, 10));
  };

  const saveRentDay = async (day: number) => {
    if (!currentRoom) return;
    setSavingRentDay(true);
    try {
      const { data: existing } = await supabase
        .from('app_settings')
        .select('id')
        .eq('room_id', currentRoom.id)
        .eq('key', 'rent_due_day')
        .maybeSingle();

      if (existing) {
        await supabase.from('app_settings').update({ value: day.toString() }).eq('id', existing.id);
      } else {
        await supabase.from('app_settings').insert({ room_id: currentRoom.id, key: 'rent_due_day', value: day.toString() });
      }
      setRentDay(day);
      toast.success(t('rentDateSaved'));
    } catch {
      toast.error('Failed to save rent date');
    } finally {
      setSavingRentDay(false);
    }
  };

  const loadFriendEmails = async () => {
    const { data } = await supabase
      .from('friends')
      .select('id, email');
    
    if (data) {
      const emails: Record<string, string> = {};
      data.forEach((f: any) => {
        if (f.email) emails[f.id] = f.email;
      });
      setFriendEmails(emails);
    }
  };

  const saveEmail = async (friendId: string) => {
    setSavingEmail(true);
    try {
      const { error } = await supabase
        .from('friends')
        .update({ email: emailInput.trim() || null })
        .eq('id', friendId);

      if (error) throw error;

      setFriendEmails(prev => ({
        ...prev,
        [friendId]: emailInput.trim(),
      }));
      setEditingEmail(null);
      toast.success('Email linked for push notifications');
    } catch (error) {
      toast.error('Failed to save email');
    } finally {
      setSavingEmail(false);
    }
  };

  const startEditing = (friend: Friend) => {
    setEditingId(friend.id);
    setEditName(friend.name);
    setEditBalance(friend.initial_balance.toString());
  };

  const cancelEditing = () => {
    setEditingId(null);
    setEditName('');
    setEditBalance('');
  };

  const saveEdit = async () => {
    if (!editingId || !editName || editBalance === '') return;

    setLoading(true);
    const success = await onUpdateFriend(editingId, editName, 0);
    setLoading(false);

    if (success) {
      setEditingId(null);
      setEditName('');
      setEditBalance('');
    }
  };

  const handleAddFriend = async () => {
    if (!newFriendName.trim()) return;
    
    setLoading(true);
    const success = await onAddFriend(newFriendName.trim(), 0);
    setLoading(false);
    
    if (success) {
      setNewFriendName('');
      setNewFriendBalance('0');
      setShowAddForm(false);
    }
  };

  const handleDeleteFriend = async () => {
    if (!deletingFriend) return;
    
    setLoading(true);
    await onDeleteFriend(deletingFriend.id);
    setLoading(false);
    setDeletingFriend(null);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display flex items-center gap-2">
              <Shield className="w-5 h-5 text-primary" />
              Admin Panel
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="admin-badge">
                <Shield className="w-3 h-3" />
                Super Admin
              </span>
            </div>

            {/* Add Friend Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-medium text-sm">Manage Members</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAddForm(!showAddForm)}
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add Friend
                </Button>
              </div>
              
              {showAddForm && (
                <div className="rounded-lg border border-primary/30 bg-primary/5 p-4 space-y-3">
                  <h4 className="font-medium text-sm text-primary">Add New Friend</h4>
                  <div className="space-y-2">
                    <Label>Name</Label>
                    <Input
                      value={newFriendName}
                      onChange={(e) => setNewFriendName(e.target.value)}
                      placeholder="Enter name"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={handleAddFriend}
                      disabled={loading || !newFriendName.trim()}
                      className="flex-1"
                    >
                      <UserPlus className="w-4 h-4 mr-1" />
                      {loading ? 'Adding...' : 'Add Friend'}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setShowAddForm(false);
                        setNewFriendName('');
                        setNewFriendBalance('0');
                      }}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* Friends List */}
            <div className="space-y-3">
              <h3 className="font-medium text-sm">Edit Members</h3>
              
              {friends.map(friend => (
                <div key={friend.id} className="rounded-lg border border-border p-3">
                  {editingId === friend.id ? (
                    <div className="space-y-3">
                      <div className="space-y-2">
                        <Label>Name</Label>
                        <Input
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={saveEdit}
                          disabled={loading}
                          className="flex-1"
                        >
                          <Save className="w-4 h-4 mr-1" />
                          {loading ? 'Saving...' : 'Save'}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={cancelEditing}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{friend.name}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => startEditing(friend)}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeletingFriend(friend)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Email Mapping for Push Notifications */}
                      <div className="flex items-center gap-2 pt-1 border-t border-border/50">
                        <Mail className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                        {editingEmail === friend.id ? (
                          <div className="flex items-center gap-1 flex-1">
                            <Input
                              value={emailInput}
                              onChange={(e) => setEmailInput(e.target.value)}
                              placeholder="user@email.com"
                              className="h-7 text-xs"
                              type="email"
                            />
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 w-7 p-0"
                              onClick={() => saveEmail(friend.id)}
                              disabled={savingEmail}
                            >
                              {savingEmail ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <Save className="w-3 h-3" />
                              )}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 w-7 p-0"
                              onClick={() => setEditingEmail(null)}
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        ) : (
                          <button
                            className="text-xs text-muted-foreground hover:text-foreground transition-colors truncate"
                            onClick={() => {
                              setEditingEmail(friend.id);
                              setEmailInput(friendEmails[friend.id] || '');
                            }}
                          >
                            {friendEmails[friend.id] || 'Link email for notifications →'}
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Rent Due Date Section */}
            <div className="space-y-2 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-primary" />
                <h3 className="font-medium text-sm">{t('monthlyRentDueDate')}</h3>
              </div>
              <p className="text-xs text-muted-foreground">{t('rentDateDesc')}</p>
              <div className="flex items-center gap-3">
                <Label className="text-xs shrink-0">{t('dayOfMonth')}:</Label>
                <Select
                  value={rentDay.toString()}
                  onValueChange={(val) => saveRentDay(parseInt(val, 10))}
                  disabled={savingRentDay}
                >
                  <SelectTrigger className="w-24 h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 31 }, (_, i) => i + 1).map(d => (
                      <SelectItem key={d} value={d.toString()}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {savingRentDay && <Loader2 className="w-4 h-4 animate-spin text-primary" />}
              </div>
            </div>

            {/* Group Type Section */}
            <div className="space-y-2 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-primary" />
                <h3 className="font-medium text-sm">Group Type</h3>
              </div>
              <p className="text-xs text-muted-foreground">
                Changes labels, placeholders and duty examples. Existing data is preserved.
              </p>
              <Select
                value={(currentRoom?.group_type as string) || 'roommates'}
                onValueChange={async (val) => {
                  const ok = await updateGroupType(val);
                  if (ok) toast.success('Group type updated');
                  else toast.error('Failed to update group type');
                }}
              >
                <SelectTrigger className="w-full h-9">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {GROUP_TYPE_LIST.map(g => (
                    <SelectItem key={g} value={g}>
                      {GROUP_PRESETS[g].emoji} {GROUP_PRESETS[g].label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Announcement Section */}
            <div className="space-y-2 rounded-lg border border-border p-4">
              <div className="flex items-center gap-2">
                <Megaphone className="w-4 h-4 text-primary" />
                <h3 className="font-medium text-sm">Announcement</h3>
              </div>
              <p className="text-xs text-muted-foreground">
                Shows in the scrolling banner on the Home page. Leave empty to show the default rent reminder.
              </p>
              <Textarea
                value={announcement}
                onChange={(e) => setAnnouncement(e.target.value)}
                placeholder="e.g., Salary on 5th, Rent before 8th, Trip starts at 6 AM"
                maxLength={200}
                rows={2}
              />
              <Button
                size="sm"
                onClick={saveAnnouncement}
                disabled={savingAnnouncement}
                className="w-full"
              >
                {savingAnnouncement ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                Save Announcement
              </Button>
            </div>

            {/* Audio Upload Section */}
            <AudioUpload />


            <p className="text-xs text-muted-foreground">
              {t('adminNote')}
            </p>

            {/* Delete Room Section */}
            <div className="pt-4 border-t border-destructive/30">
              <Button
                variant="destructive"
                className="w-full"
                onClick={() => setShowDeleteRoom(true)}
              >
                <Trash2 className="w-4 h-4 mr-2" />
                {t('deleteRoom')}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deletingFriend} onOpenChange={(open) => !open && setDeletingFriend(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove Friend</AlertDialogTitle>
            <AlertDialogDescription>
              இந்த மெம்பரை டெலீட் செய்தால் அவர்களின் மொத்த டேட்டாவும் அழிந்துவிடும். உறுதிப்படுத்தவும்!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteFriend}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Room Confirmation */}
      <AlertDialog open={showDeleteRoom} onOpenChange={setShowDeleteRoom}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive">⚠️ Delete Room</AlertDialogTitle>
            <AlertDialogDescription className="text-base leading-relaxed">
              இந்த ரூமை டெலீட் செய்தால் இதில் உள்ள அனைத்து கணக்குகளும், மெம்பர்களும் நிரந்தரமாக அழிந்துவிடும். இதை உறுதிப்படுத்துகிறீர்களா?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingRoom}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={deletingRoom}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={async (e) => {
                e.preventDefault();
                if (!currentRoom) return;
                setDeletingRoom(true);
                try {
                  const { error } = await supabase.rpc('delete_room', { _room_id: currentRoom.id });
                  if (error) throw error;
                  toast.success('Room deleted successfully');
                  leaveRoom();
                  onOpenChange(false);
                  setShowDeleteRoom(false);
                  navigate('/room-lobby');
                } catch (err: any) {
                  toast.error(err.message || 'Failed to delete room');
                } finally {
                  setDeletingRoom(false);
                }
              }}
            >
              {deletingRoom ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
              {deletingRoom ? 'Deleting...' : 'Delete Room'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
