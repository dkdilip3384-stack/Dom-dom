import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertCircle, X } from 'lucide-react';
import { formatCurrency } from '@/lib/formatCurrency';
import { useLanguage } from '@/hooks/useLanguage';

interface DebtPopupProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  balance: number;
  userName?: string;
}

export const DebtPopup: React.FC<DebtPopupProps> = ({ open, onOpenChange, balance, userName }) => {
  const { t } = useLanguage();
  const displayName = userName || 'there';
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="font-display flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-destructive" />
              {t('paymentReminder')}
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onOpenChange(false)}
              className="h-6 w-6"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        <div className="py-4 text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-destructive/10 flex items-center justify-center">
            <AlertCircle className="w-8 h-8 text-destructive" />
          </div>
          <p className="text-lg mb-2">
            {t('helloPending')} <span className="font-semibold">{displayName}</span>{t('youHavePendingDues')}
          </p>
          <p className="text-2xl font-display font-bold text-destructive mb-4">
            {formatCurrency(Math.abs(balance))}
          </p>
          <p className="text-muted-foreground text-sm">
            {t('payAmountSoon')}
          </p>
        </div>
        <div className="flex justify-center pt-2">
          <Button onClick={() => onOpenChange(false)} className="w-full" variant="outline">
            {t('close')}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
