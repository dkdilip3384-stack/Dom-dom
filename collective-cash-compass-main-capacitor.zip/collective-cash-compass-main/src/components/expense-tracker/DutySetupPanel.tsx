import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ChefHat, Trash2, Droplets, Loader2, GripVertical, Save } from 'lucide-react';
import { Friend } from '@/lib/types';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useLanguage } from '@/hooks/useLanguage';

interface DutySetupPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  friends: Friend[];
}

interface DutyAssignment {
  id?: string;
  duty_type: string;
  friend_id: string;
  duty_order: number;
  start_date: string;
}

export const DutySetupPanel: React.FC<DutySetupPanelProps> = ({
  open,
  onOpenChange,
  friends,
}) => {
  const { t } = useLanguage();

  const dutyTypes = [
    { type: 'Cooking', label: t('cooking'), icon: ChefHat, color: 'text-orange-500' },
    { type: 'Trash', label: t('trash'), icon: Trash2, color: 'text-green-500' },
    { type: 'Water', label: t('water'), icon: Droplets, color: 'text-blue-500' },
  ];

  const [selectedFriends, setSelectedFriends] = useState<Record<string, string[]>>({
    Cooking: [],
    Trash: [],
    Water: [],
  });
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      fetchExistingAssignments();
    }
  }, [open]);

  const fetchExistingAssignments = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('duty_assignments')
        .select('*')
        .order('duty_order', { ascending: true });

      if (error) throw error;

      const newSelected: Record<string, string[]> = {
        Cooking: [],
        Trash: [],
        Water: [],
      };

      (data || []).forEach((assignment: DutyAssignment) => {
        if (newSelected[assignment.duty_type]) {
          newSelected[assignment.duty_type].push(assignment.friend_id);
        }
      });

      setSelectedFriends(newSelected);
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error fetching duty assignments:', error);
      toast.error(t('dutyRosterFailed'));
    } finally {
      setLoading(false);
    }
  };

  const toggleFriend = (dutyType: string, friendId: string) => {
    setSelectedFriends(prev => {
      const current = prev[dutyType] || [];
      if (current.includes(friendId)) {
        return { ...prev, [dutyType]: current.filter(id => id !== friendId) };
      } else {
        return { ...prev, [dutyType]: [...current, friendId] };
      }
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error: deleteError } = await supabase
        .from('duty_assignments')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (deleteError) throw deleteError;

      const today = new Date().toISOString().split('T')[0];
      const newAssignments: Omit<DutyAssignment, 'id'>[] = [];

      Object.entries(selectedFriends).forEach(([dutyType, friendIds]) => {
        friendIds.forEach((friendId, index) => {
          newAssignments.push({
            duty_type: dutyType,
            friend_id: friendId,
            duty_order: index,
            start_date: today,
          });
        });
      });

      if (newAssignments.length > 0) {
        const { error: insertError } = await supabase
          .from('duty_assignments')
          .insert(newAssignments);

        if (insertError) throw insertError;
      }

      toast.success(t('dutyRosterSaved'));
      onOpenChange(false);
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error saving duty assignments:', error);
      toast.error(t('dutyRosterFailed'));
    } finally {
      setSaving(false);
    }
  };

  const moveFriend = (dutyType: string, fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= selectedFriends[dutyType].length) return;
    
    setSelectedFriends(prev => {
      const newOrder = [...prev[dutyType]];
      const [removed] = newOrder.splice(fromIndex, 1);
      newOrder.splice(toIndex, 0, removed);
      return { ...prev, [dutyType]: newOrder };
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('dutyRosterSetup')}</DialogTitle>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-6">
            {dutyTypes.map(duty => {
              const IconComponent = duty.icon;
              const selectedIds = selectedFriends[duty.type] || [];

              return (
                <div key={duty.type} className="space-y-3">
                  <div className="flex items-center gap-2">
                    <IconComponent className={`w-5 h-5 ${duty.color}`} />
                    <h3 className="font-medium text-foreground">{duty.label}</h3>
                  </div>

                  <div className="space-y-2 pl-7">
                    {friends.map(friend => (
                      <div key={friend.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`${duty.type}-${friend.id}`}
                          checked={selectedIds.includes(friend.id)}
                          onCheckedChange={() => toggleFriend(duty.type, friend.id)}
                        />
                        <Label
                          htmlFor={`${duty.type}-${friend.id}`}
                          className="text-sm font-normal cursor-pointer"
                        >
                          {friend.name}
                        </Label>
                      </div>
                    ))}
                  </div>

                  {selectedIds.length > 0 && (
                    <div className="pl-7">
                      <p className="text-xs text-muted-foreground mb-2">
                        {t('rotationOrder')}
                      </p>
                      <div className="space-y-1">
                        {selectedIds.map((friendId, index) => {
                          const friend = friends.find(f => f.id === friendId);
                          return (
                            <div
                              key={friendId}
                              className="flex items-center gap-2 p-2 bg-muted rounded text-sm"
                            >
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0"
                                  onClick={() => moveFriend(duty.type, index, index - 1)}
                                  disabled={index === 0}
                                >
                                  ↑
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="h-6 w-6 p-0"
                                  onClick={() => moveFriend(duty.type, index, index + 1)}
                                  disabled={index === selectedIds.length - 1}
                                >
                                  ↓
                                </Button>
                              </div>
                              <span className="text-muted-foreground">{index + 1}.</span>
                              <span>{friend?.name}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}

            <Button onClick={handleSave} className="w-full" disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  {t('saving')}
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {t('saveDutyRoster')}
                </>
              )}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
