import React, { useState, useEffect, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChefHat, Trash2, Droplets, Calendar, User, Check, Loader2 } from 'lucide-react';
import { Friend } from '@/lib/types';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { useLanguage } from '@/hooks/useLanguage';

interface DutyAssignment {
  id: string;
  duty_type: string;
  friend_id: string;
  duty_order: number;
  start_date: string;
  current_index: number;
  last_completed_at: string | null;
}

interface DutyTabProps {
  friends: Friend[];
}

export const DutyTab: React.FC<DutyTabProps> = ({ friends }) => {
  const { t } = useLanguage();
  const [assignments, setAssignments] = useState<DutyAssignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [markingDone, setMarkingDone] = useState<string | null>(null);
  const { isAdmin, user } = useAuth();

  const dutyConfig = useMemo(() => [
    { type: 'Cooking', label: t('cooking'), icon: ChefHat, color: 'bg-orange-500' },
    { type: 'Trash', label: t('trash'), icon: Trash2, color: 'bg-green-500' },
    { type: 'Water', label: t('water'), icon: Droplets, color: 'bg-blue-500' },
  ], [t]);

  useEffect(() => {
    fetchAssignments();

    const channel = supabase
      .channel('duty-assignments-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'duty_assignments' }, () => {
        fetchAssignments();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchAssignments = async () => {
    try {
      const { data, error } = await supabase
        .from('duty_assignments')
        .select('*')
        .order('duty_order', { ascending: true });

      if (error) throw error;
      setAssignments((data || []) as DutyAssignment[]);
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error fetching duty assignments:', error);
    } finally {
      setLoading(false);
    }
  };

  const todaysDuties = useMemo(() => {
    return dutyConfig.map(duty => {
      const dutyAssignments = assignments
        .filter(a => a.duty_type === duty.type)
        .sort((a, b) => a.duty_order - b.duty_order);

      if (dutyAssignments.length === 0) {
        return { ...duty, assignedFriend: null, nextFriends: [], dutyAssignments: [] };
      }

      const currentIndex = dutyAssignments[0]?.current_index || 0;
      const normalizedIndex = currentIndex % dutyAssignments.length;
      const assignedAssignment = dutyAssignments[normalizedIndex];
      const assignedFriend = friends.find(f => f.id === assignedAssignment?.friend_id);

      const nextFriends: Friend[] = [];
      for (let i = 1; i <= Math.min(2, dutyAssignments.length - 1); i++) {
        const nextIndex = (normalizedIndex + i) % dutyAssignments.length;
        const nextFriend = friends.find(f => f.id === dutyAssignments[nextIndex]?.friend_id);
        if (nextFriend && !nextFriends.some(nf => nf.id === nextFriend.id)) {
          nextFriends.push(nextFriend);
        }
      }

      return { ...duty, assignedFriend, nextFriends, dutyAssignments };
    });
  }, [assignments, friends, dutyConfig]);

  const canMarkAsDone = (assignedFriend: Friend | null) => {
    if (isAdmin) return true;
    if (!assignedFriend || !user) return false;
    
    const userEmailPrefix = user.email?.split('@')[0]?.toLowerCase() || '';
    const friendNameLower = assignedFriend.name.toLowerCase();
    return friendNameLower === userEmailPrefix || 
           friendNameLower.includes(userEmailPrefix) ||
           userEmailPrefix.includes(friendNameLower);
  };

  const handleMarkAsDone = async (dutyType: string) => {
    try {
      setMarkingDone(dutyType);
      
      const dutyAssignments = assignments
        .filter(a => a.duty_type === dutyType)
        .sort((a, b) => a.duty_order - b.duty_order);
      
      if (dutyAssignments.length === 0) return;

      const currentIndex = dutyAssignments[0]?.current_index || 0;
      const nextIndex = currentIndex + 1;

      const { error } = await supabase
        .from('duty_assignments')
        .update({ 
          current_index: nextIndex,
          last_completed_at: new Date().toISOString()
        })
        .eq('duty_type', dutyType);

      if (error) throw error;
      
      const dutyLabel = dutyConfig.find(d => d.type === dutyType)?.label || dutyType;
      toast.success(`${dutyLabel} ${t('markedAsDone')}`);
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error marking duty as done:', error);
      toast.error(t('failedMarkDone'));
    } finally {
      setMarkingDone(null);
    }
  };

  const formatDate = () => {
    return new Date().toLocaleDateString('en-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-6 h-6 animate-spin text-primary" />
      </div>
    );
  }

  const hasDutySetup = assignments.length > 0;

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 text-muted-foreground mb-1">
          <Calendar className="w-4 h-4" />
          <span className="text-sm">{t('todaysDate')}</span>
        </div>
        <h2 className="text-lg font-semibold text-foreground">{formatDate()}</h2>
      </div>

      {!hasDutySetup ? (
        <Card className="border-dashed">
          <CardContent className="py-8 text-center">
            <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="font-medium text-foreground mb-2">{t('noDutiesAssigned')}</h3>
            <p className="text-sm text-muted-foreground">
              {t('askAdminDuty')}
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="space-y-4">
            <h3 className="font-medium text-foreground">{t('todaysDuties')}</h3>
            {todaysDuties.map(duty => {
              const IconComponent = duty.icon;
              const showMarkAsDone = canMarkAsDone(duty.assignedFriend);
              const isMarking = markingDone === duty.type;
              
                return (
                <Card key={duty.type} className="overflow-hidden">
                  <div className={`h-1 ${duty.color}`} />
                  <CardContent className="py-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${duty.color} text-white`}>
                          <IconComponent className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{duty.label}</p>
                          {duty.assignedFriend ? (
                            <div className="relative inline-block">
                              <div className="absolute -inset-2 rounded-full bg-neon-blue/60 blur-sm animate-spin-slow" />
                              <div className="absolute -inset-1.5 rounded-full border-2 border-neon-blue animate-glow-pulse" />
                              <p className="relative text-lg font-semibold text-primary bg-background px-2 py-0.5 rounded-full">
                                {duty.assignedFriend.name}
                              </p>
                            </div>
                          ) : (
                            <p className="text-sm text-muted-foreground">{t('notAssigned')}</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {showMarkAsDone && duty.assignedFriend && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="gap-1 text-xs"
                            onClick={() => handleMarkAsDone(duty.type)}
                            disabled={isMarking}
                          >
                            {isMarking ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Check className="w-3 h-3" />
                            )}
                            {t('done')}
                          </Button>
                        )}
                        <Badge variant="secondary" className="text-xs">
                          {t('today')}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="space-y-4">
            <h3 className="font-medium text-foreground">{t('upcomingRotation')}</h3>
            <Card>
              <CardContent className="py-4">
                <div className="space-y-3">
                  {todaysDuties.map(duty => {
                    const IconComponent = duty.icon;
                    if (duty.nextFriends.length === 0) return null;
                    return (
                      <div key={duty.type} className="flex items-center gap-3">
                        <div className={`p-1.5 rounded ${duty.color} text-white`}>
                          <IconComponent className="w-4 h-4" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium text-foreground">{duty.label}</p>
                          <p className="text-xs text-muted-foreground">
                            {t('next')}: {duty.nextFriends.map(f => f.name).join(' → ')}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
};
