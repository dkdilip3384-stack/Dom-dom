import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useExpenseData } from '@/hooks/useExpenseData';
import { useAuth } from '@/contexts/AuthContext';
import { useRoom } from '@/contexts/RoomContext';
import { useSystemNotifications } from '@/hooks/useSystemNotifications';
import { usePushNotifications } from '@/hooks/usePushNotifications';

import { BottomNav } from './BottomNav';
import { HomeTab } from './HomeTab';
import { HistoryTab } from './HistoryTab';
import { SettlementTab } from './SettlementTab';
import { DutyTab } from './DutyTab';
import { DealsTab } from './DealsTab';
import { AddExpenseDialog } from './AddExpenseDialog';
import { AdminPanel } from './AdminPanel';
import { DutySetupPanel } from './DutySetupPanel';
import { NotificationSettings } from './NotificationSettings';
import { DebtPopup } from './DebtPopup';
import { NotificationBell } from './NotificationBell';
import { AudioPlayer } from './AudioPlayer';
import { TabType } from '@/lib/types';
import { Plus, Loader2, LogOut, User, Settings, RefreshCw, Copy, ArrowLeft, Globe } from 'lucide-react';
import { useLanguage } from '@/hooks/useLanguage';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';

export const ExpenseTracker: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [addExpenseOpen, setAddExpenseOpen] = useState(false);
  const [adminPanelOpen, setAdminPanelOpen] = useState(false);
  const [dutySetupOpen, setDutySetupOpen] = useState(false);
  const [notifSettingsOpen, setNotifSettingsOpen] = useState(false);
  const [debtPopupOpen, setDebtPopupOpen] = useState(false);
  const [userBalance, setUserBalance] = useState(0);
  const [userName, setUserName] = useState('');
  const [debtPopupShown, setDebtPopupShown] = useState(false);
  
  const { user, signOut } = useAuth();
  const { currentRoom, isRoomAdmin, leaveRoom, currentMember } = useRoom();
  const { t, lang, setLang } = useLanguage();
  const navigate = useNavigate();

  const {
    friends,
    expenses,
    expenseSplits,
    loading,
    calculateBalances,
    calculateSettlements,
    getTotalExpense,
    addExpense,
    updateExpense,
    deleteExpense,
    updateFriend,
    addFriend,
    deleteFriend,
    refetch,
  } = useExpenseData();

  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
    toast.success(t('refreshed'));
  };

  const balances = calculateBalances();
  const settlements = calculateSettlements();
  const totalExpense = getTotalExpense();

  useSystemNotifications(friends);
  usePushNotifications();

  useEffect(() => {
    const checkUserBalance = async () => {
      if (!loading && user && balances.length > 0 && !debtPopupShown) {
        const userEmailPrefix = user.email?.split('@')[0]?.toLowerCase() || '';
        const currentUserBalance = balances.find(b => {
          const friendNameLower = b.friend.name.toLowerCase();
          return friendNameLower === userEmailPrefix || 
                 friendNameLower.includes(userEmailPrefix) ||
                 userEmailPrefix.includes(friendNameLower);
        });
        
        if (currentUserBalance && currentUserBalance.finalBalance < 0) {
          setUserBalance(currentUserBalance.finalBalance);
          setUserName(currentUserBalance.friend.name);
          setDebtPopupOpen(true);
          setDebtPopupShown(true);
        }
      }
    };
    checkUserBalance();
  }, [loading, user, balances, debtPopupShown]);

  useEffect(() => {
    if (!loading && user) {
      const welcomePlayed = sessionStorage.getItem('z-kanakku-welcome-played');
      if (!welcomePlayed && 'speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance('Welcome to Z-Kanakku');
        utterance.rate = 1;
        utterance.pitch = 1;
        utterance.volume = 0.8;
        window.speechSynthesis.speak(utterance);
        sessionStorage.setItem('z-kanakku-welcome-played', 'true');
      }
    }
  }, [loading, user]);

  const handleSignOut = async () => {
    await signOut();
    toast.success('Signed out successfully');
  };

  const copyRoomCode = () => {
    if (currentRoom?.code) {
      navigator.clipboard.writeText(currentRoom.code);
      toast.success(t('copyCode'));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">{t('loading')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-32 pt-16">
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-lg mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <NotificationBell />
            <div>
              <h1 className="font-display font-bold text-xl text-foreground leading-tight">
                Z-Kanakku
              </h1>
              {currentRoom && (
                <button
                  onClick={copyRoomCode}
                  className="text-xs text-muted-foreground hover:text-primary transition-colors flex items-center gap-1"
                >
                  {currentRoom.name} • <span className="font-mono">{currentRoom.code}</span>
                  <Copy className="w-3 h-3" />
                </button>
              )}
            </div>
            <AudioPlayer />
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              aria-label="Refresh data"
            >
              <RefreshCw className={`w-5 h-5 ${isRefreshing ? 'animate-spin' : ''}`} />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => navigate('/settings')}
              aria-label={t('settings')}
              className="relative"
            >
              <Settings className="w-5 h-5" />
              {isRoomAdmin && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-primary" />
              )}
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="w-5 h-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem disabled className="text-xs text-muted-foreground">
                  {currentMember?.display_name || user?.email}
                </DropdownMenuItem>
                {isRoomAdmin && (
                  <DropdownMenuItem disabled className="text-xs text-primary font-medium">
                    {t('roomAdmin')}
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => { leaveRoom(); }}>
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  {t('switchRoom')}
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="w-4 h-4 mr-2" />
                  {t('signOut')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>

      <main className="max-w-lg mx-auto px-4 py-6">
        {activeTab === 'home' && (
          <HomeTab totalExpense={totalExpense} balances={balances} />
        )}
        {activeTab === 'history' && (
          <HistoryTab
            expenses={expenses}
            friends={friends}
            expenseSplits={expenseSplits}
            balances={balances}
            totalExpense={totalExpense}
            onUpdateExpense={updateExpense}
            onDeleteExpense={deleteExpense}
          />
        )}
        {activeTab === 'settlement' && (
          <SettlementTab settlements={settlements} balances={balances} />
        )}
        {activeTab === 'duty' && (
          <DutyTab friends={friends} />
        )}
        {activeTab === 'deals' && <DealsTab />}
      </main>

      {activeTab !== 'duty' && activeTab !== 'deals' && (
        <button
          className="floating-action-button"
          onClick={() => setAddExpenseOpen(true)}
          aria-label="Add expense"
          style={{ bottom: '100px' }}
        >
          <Plus className="w-6 h-6" />
        </button>
      )}

      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />

      <AddExpenseDialog
        open={addExpenseOpen}
        onOpenChange={setAddExpenseOpen}
        friends={friends}
        onSubmit={addExpense}
        onSuccess={() => setActiveTab('home')}
      />

      {isRoomAdmin && (
        <>
          <AdminPanel
            open={adminPanelOpen}
            onOpenChange={setAdminPanelOpen}
            friends={friends}
            onUpdateFriend={updateFriend}
            onAddFriend={addFriend}
            onDeleteFriend={deleteFriend}
          />
          <DutySetupPanel
            open={dutySetupOpen}
            onOpenChange={setDutySetupOpen}
            friends={friends}
          />
          <NotificationSettings
            open={notifSettingsOpen}
            onOpenChange={setNotifSettingsOpen}
          />
        </>
      )}

      <DebtPopup
        open={debtPopupOpen}
        onOpenChange={setDebtPopupOpen}
        balance={userBalance}
        userName={userName}
      />
    </div>
  );
};
