import React, { useEffect, useState } from 'react';
import { TotalCard } from './TotalCard';
import { BalanceCard } from './BalanceCard';
import { HomeMarquee } from './HomeMarquee';
import { FriendBalance } from '@/lib/types';
import { supabase } from '@/integrations/supabase/client';
import { useRoom } from '@/contexts/RoomContext';
import { useLanguage } from '@/hooks/useLanguage';

interface HomeTabProps {
  totalExpense: number;
  balances: FriendBalance[];
  onFriendClick?: (friendId: string) => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({ totalExpense, balances, onFriendClick }) => {
  const { currentRoom } = useRoom();
  const { t } = useLanguage();
  const [rentDueDay, setRentDueDay] = useState(8);
  const [announcement, setAnnouncement] = useState<string>('');

  useEffect(() => {
    if (!currentRoom) return;
    const fetchSettings = async () => {
      const { data } = await supabase
        .from('app_settings')
        .select('key, value')
        .eq('room_id', currentRoom.id)
        .in('key', ['rent_due_day', 'announcement']);
      if (data) {
        for (const row of data) {
          if (row.key === 'rent_due_day' && row.value) setRentDueDay(parseInt(row.value, 10));
          if (row.key === 'announcement') setAnnouncement(row.value ?? '');
        }
      }
    };
    fetchSettings();

    const channel = supabase
      .channel(`app_settings_${currentRoom.id}`)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'app_settings', filter: `room_id=eq.${currentRoom.id}`,
      }, () => fetchSettings())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [currentRoom]);

  return (
    <div className="space-y-6">
      <TotalCard totalExpense={totalExpense} memberCount={balances.length} />

      <HomeMarquee balances={balances} rentDueDay={rentDueDay} announcement={announcement} />

      <div>
        <h2 className="font-display font-semibold text-lg mb-4">{t('memberBalances')}</h2>
        <div className="grid grid-cols-2 gap-4">
          {balances.map(balance => (
            <BalanceCard
              key={balance.friend.id}
              balance={balance}
              onClick={() => onFriendClick?.(balance.friend.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

