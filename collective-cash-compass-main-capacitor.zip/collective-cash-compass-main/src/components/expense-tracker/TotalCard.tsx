import React from 'react';
import { Wallet } from 'lucide-react';
import { formatCurrencyUnsigned } from '@/lib/formatCurrency';
import { useLanguage } from '@/hooks/useLanguage';

interface TotalCardProps {
  totalExpense: number;
  memberCount: number;
}

export const TotalCard: React.FC<TotalCardProps> = ({ totalExpense, memberCount }) => {
  const { t } = useLanguage();
  
  return (
    <div className="dashboard-card animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
            <Wallet className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm opacity-80">{t('totalGroupExpense')}</p>
            <p className="text-xs opacity-60">{memberCount} {t('members')}</p>
          </div>
        </div>
      </div>
      <p className="text-4xl font-display font-bold tracking-tight">
        {formatCurrencyUnsigned(totalExpense)}
      </p>
    </div>
  );
};
