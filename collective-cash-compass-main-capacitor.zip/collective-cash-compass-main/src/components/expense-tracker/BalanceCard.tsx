import React from 'react';
import { FriendBalance } from '@/lib/types';
import { formatCurrency, formatCurrencyUnsigned } from '@/lib/formatCurrency';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useLanguage } from '@/hooks/useLanguage';

const AVATAR_COLORS = [
  'bg-primary/20 text-primary',
  'bg-positive/20 text-positive',
  'bg-negative/20 text-negative',
  'bg-accent text-accent-foreground',
  'bg-secondary text-secondary-foreground',
];

interface BalanceCardProps {
  balance: FriendBalance;
  onClick?: () => void;
}

export const BalanceCard: React.FC<BalanceCardProps> = ({ balance, onClick }) => {
  const { t } = useLanguage();
  const isPositive = balance.finalBalance >= 0;
  const colorIndex = balance.friend.display_order % AVATAR_COLORS.length;
  
  return (
    <div 
      className={`balance-card cursor-pointer ${isPositive ? 'balance-positive' : 'balance-negative'}`}
      onClick={onClick}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <Avatar className="w-8 h-8 shrink-0">
            {balance.friend.avatar_url ? (
              <AvatarImage src={balance.friend.avatar_url} alt={balance.friend.name} />
            ) : null}
            <AvatarFallback className={AVATAR_COLORS[colorIndex]}>
              {balance.friend.name.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <h3 className="font-display font-semibold text-foreground truncate text-sm">
              {balance.friend.name}
            </h3>
            <p className="text-xs text-muted-foreground">
              {t('paid')}: {formatCurrencyUnsigned(balance.totalPaid)}
            </p>
          </div>
        </div>
        <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
          isPositive ? 'bg-positive/10' : 'bg-negative/10'
        }`}>
          {isPositive ? (
            <TrendingUp className="w-3.5 h-3.5 text-positive" />
          ) : (
            <TrendingDown className="w-3.5 h-3.5 text-negative" />
          )}
        </div>
      </div>
      <p className={`text-2xl font-display font-bold ${
        isPositive ? 'balance-amount-positive' : 'balance-amount-negative'
      }`}>
        {formatCurrency(balance.finalBalance)}
      </p>
      <p className="text-xs text-muted-foreground mt-1">
        {t('share')}: {formatCurrencyUnsigned(balance.totalShare)}
      </p>
    </div>
  );
};
