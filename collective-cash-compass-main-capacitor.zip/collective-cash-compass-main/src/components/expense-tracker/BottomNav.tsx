import React from 'react';
import { Home, History, ArrowLeftRight, ClipboardList, Tag } from 'lucide-react';
import { TabType } from '@/lib/types';
import { useLanguage } from '@/hooks/useLanguage';

interface BottomNavProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const { t } = useLanguage();
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50 pb-[45px]">
      <div className="max-w-lg mx-auto flex items-center justify-around">
        <button
          className={`tab-button ${activeTab === 'home' ? 'active' : ''}`}
          onClick={() => onTabChange('home')}
        >
          <Home className="w-5 h-5" />
          <span className="text-xs font-medium">{t('home')}</span>
        </button>
        <button
          className={`tab-button ${activeTab === 'history' ? 'active' : ''}`}
          onClick={() => onTabChange('history')}
        >
          <History className="w-5 h-5" />
          <span className="text-xs font-medium">{t('history')}</span>
        </button>
        <button
          className={`tab-button ${activeTab === 'settlement' ? 'active' : ''}`}
          onClick={() => onTabChange('settlement')}
        >
          <ArrowLeftRight className="w-5 h-5" />
          <span className="text-xs font-medium">{t('settlement')}</span>
        </button>
        <button
          className={`tab-button ${activeTab === 'duty' ? 'active' : ''}`}
          onClick={() => onTabChange('duty')}
        >
          <ClipboardList className="w-5 h-5" />
          <span className="text-xs font-medium">{t('duty')}</span>
        </button>
        <button
          className={`tab-button ${activeTab === 'deals' ? 'active' : ''}`}
          onClick={() => onTabChange('deals')}
        >
          <Tag className="w-5 h-5" />
          <span className="text-xs font-medium">{t('deals' as any)}</span>
        </button>
      </div>
    </nav>
  );
};
