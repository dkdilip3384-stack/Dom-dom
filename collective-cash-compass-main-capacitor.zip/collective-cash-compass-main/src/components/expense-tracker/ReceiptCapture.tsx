import React, { useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Camera, Image, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface ReceiptCaptureProps {
  receiptUrl: string | null;
  onReceiptChange: (url: string | null) => void;
  required?: boolean;
}

export const ReceiptCapture: React.FC<ReceiptCaptureProps> = ({
  receiptUrl,
  onReceiptChange,
  required = false,
}) => {
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please select an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image size must be less than 5MB');
      return;
    }

    setUploading(true);

    try {
      const fileExt = file.name.split('.').pop();
      // Use crypto.randomUUID() for more secure random filenames
      const fileName = `${crypto.randomUUID()}.${fileExt}`;
      const filePath = `receipts/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('receipts')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Use signed URLs since bucket is now private
      const { data, error: signedUrlError } = await supabase.storage
        .from('receipts')
        .createSignedUrl(filePath, 60 * 60 * 24 * 7); // 7 days expiration

      if (signedUrlError) throw signedUrlError;

      onReceiptChange(data.signedUrl);
      toast.success('Receipt uploaded successfully');
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error uploading receipt:', error);
      toast.error('Failed to upload receipt');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveReceipt = () => {
    onReceiptChange(null);
  };

  const openCamera = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className="space-y-2">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        className="hidden"
      />

      {receiptUrl ? (
        <div className="relative">
          <img
            src={receiptUrl}
            alt="Receipt"
            className="w-full h-32 object-cover rounded-lg border border-border"
          />
          <Button
            type="button"
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2 h-7 w-7"
            onClick={handleRemoveReceipt}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      ) : (
        <Button
          type="button"
          variant="outline"
          className={`w-full h-24 flex flex-col gap-2 ${required ? 'border-destructive' : ''}`}
          onClick={openCamera}
          disabled={uploading}
        >
          {uploading ? (
            <>
              <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              <span className="text-sm">Uploading...</span>
            </>
          ) : (
            <>
              <Camera className="w-6 h-6" />
              <span className="text-sm">
                {required ? 'Add Receipt Photo (Required)' : 'Add Receipt Photo'}
              </span>
            </>
          )}
        </Button>
      )}
    </div>
  );
};
