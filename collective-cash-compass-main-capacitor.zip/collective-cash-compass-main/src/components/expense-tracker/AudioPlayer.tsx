import React, { useState, useRef, useEffect } from 'react';
import { Play, Pause, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';

export const AudioPlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    fetchAudioUrl();
  }, []);

  const fetchAudioUrl = async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'background_audio_url')
        .single();

      if (!error && data?.value) {
        setAudioUrl(data.value);
      }
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error fetching audio URL:', error);
    }
  };

  const togglePlay = async () => {
    if (!audioUrl) return;

    if (!audioRef.current) {
      audioRef.current = new Audio(audioUrl);
      audioRef.current.loop = true;
      audioRef.current.onended = () => setIsPlaying(false);
      audioRef.current.onerror = () => {
        setIsPlaying(false);
        setIsLoading(false);
      };
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      setIsLoading(true);
      try {
        await audioRef.current.play();
        setIsPlaying(true);
      } catch (error) {
        if (import.meta.env.DEV) console.error('Error playing audio:', error);
      } finally {
        setIsLoading(false);
      }
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={togglePlay}
      className="relative h-8 w-8 p-0 ml-2.5 cursor-pointer hover:bg-blue-100"
      disabled={isLoading || !audioUrl}
      title={audioUrl ? (isPlaying ? "Pause audio" : "Play audio") : "No audio uploaded"}
    >
      {isLoading ? (
        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
      ) : isPlaying ? (
        <Pause className="w-6 h-6 text-blue-600" />
      ) : (
        <Play className="w-6 h-6 text-blue-600" />
      )}
    </Button>
  );
};
