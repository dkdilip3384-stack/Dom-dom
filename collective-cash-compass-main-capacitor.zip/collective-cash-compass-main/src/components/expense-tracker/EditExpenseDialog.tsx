import React, { useState, useEffect } from 'react';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Expense, Friend } from '@/lib/types';
import { format } from 'date-fns';
import { CalendarIcon } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useLanguage } from '@/hooks/useLanguage';

interface EditExpenseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  expense: Expense;
  friends: Friend[];
  initialSplits: string[];
  onSubmit: (
    description: string,
    amount: number,
    paidBy: string,
    expenseDate: Date,
    splitAmong: string[]
  ) => Promise<boolean>;
}

export const EditExpenseDialog: React.FC<EditExpenseDialogProps> = ({
  open,
  onOpenChange,
  expense,
  friends,
  initialSplits,
  onSubmit,
}) => {
  const { t } = useLanguage();
  const [description, setDescription] = useState(expense.description);
  const [amount, setAmount] = useState(expense.amount.toString());
  const [paidBy, setPaidBy] = useState(expense.paid_by);
  const [expenseDate, setExpenseDate] = useState<Date>(new Date(expense.expense_date));
  const [splitAmong, setSplitAmong] = useState<string[]>(initialSplits);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setDescription(expense.description);
    setAmount(expense.amount.toString());
    setPaidBy(expense.paid_by);
    setExpenseDate(new Date(expense.expense_date));
    setSplitAmong(initialSplits);
  }, [expense, initialSplits]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedDesc = description.trim();
    const parsedAmount = parseFloat(amount);

    if (!trimmedDesc || !amount || !paidBy || splitAmong.length === 0) {
      toast.error(t('fillAllFields'));
      return;
    }

    if (parsedAmount <= 0 || !isFinite(parsedAmount)) {
      toast.error('Amount must be a positive number');
      return;
    }

    if (trimmedDesc.length > 500) {
      toast.error('Description must be 500 characters or less');
      return;
    }

    setLoading(true);
    const success = await onSubmit(
      description,
      parseFloat(amount),
      paidBy,
      expenseDate,
      splitAmong
    );
    setLoading(false);

    if (success) {
      onOpenChange(false);
    }
  };

  const toggleSplit = (friendId: string) => {
    setSplitAmong(prev =>
      prev.includes(friendId)
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display">{t('editExpense')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="edit-description">{t('expenseReason')}</Label>
            <Input
              id="edit-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g., Fish Curry, Current Bill"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-amount">{t('amount')}</Label>
            <Input
              id="edit-amount"
              type="number"
              step="0.01"
              min="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label>{t('paidBy')}</Label>
            <Select value={paidBy} onValueChange={setPaidBy}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {friends.map(friend => (
                  <SelectItem key={friend.id} value={friend.id}>
                    {friend.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>{t('date')}</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn('w-full justify-start text-left font-normal')}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(expenseDate, 'PPP')}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={expenseDate}
                  onSelect={(date) => date && setExpenseDate(date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>{t('splitAmong')}</Label>
            <div className="grid grid-cols-2 gap-2">
              {friends.map(friend => (
                <label
                  key={friend.id}
                  className="flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-muted cursor-pointer"
                >
                  <Checkbox
                    checked={splitAmong.includes(friend.id)}
                    onCheckedChange={() => toggleSplit(friend.id)}
                  />
                  <span className="text-sm">{friend.name}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              {t('cancel')}
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={loading || !description || !amount || !paidBy || splitAmong.length === 0}
            >
              {loading ? t('saving') : t('saveChanges')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
