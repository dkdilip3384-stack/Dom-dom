import React, { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Plus, Trash2, Pencil, Sparkles, Search, X, ExternalLink } from 'lucide-react';
import { toast } from 'sonner';
import { DEAL_BADGES, DEAL_CATEGORIES, DealRow } from '@/lib/dealsConfig';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onChanged?: () => void;
}

interface FormState {
  id?: string;
  affiliate_url: string;
  title: string;
  description: string;
  price: string;
  image_url: string;
  store_name: string;
  category: string;
  badge: string;
  is_active: boolean;
}

const emptyForm: FormState = {
  affiliate_url: '',
  title: '',
  description: '',
  price: '',
  image_url: '',
  store_name: '',
  category: 'Others',
  badge: '',
  is_active: true,
};

export const DealsAdminPanel: React.FC<Props> = ({ open, onOpenChange, onChanged }) => {
  const { user } = useAuth();
  const [deals, setDeals] = useState<DealRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [fetching, setFetching] = useState(false);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('deals')
      .select('*')
      .order('created_at', { ascending: false });
    if (error) toast.error(error.message);
    else setDeals((data || []) as DealRow[]);
    setLoading(false);
  };

  useEffect(() => {
    if (open) load();
  }, [open]);

  const resetForm = () => {
    setForm(emptyForm);
    setShowForm(false);
  };

  const startEdit = (d: DealRow) => {
    setForm({
      id: d.id,
      affiliate_url: d.affiliate_url,
      title: d.title,
      description: d.description || '',
      price: d.price != null ? String(d.price) : '',
      image_url: d.image_url || '',
      store_name: d.store_name || '',
      category: d.category,
      badge: d.badge || '',
      is_active: d.is_active,
    });
    setShowForm(true);
  };

  const handleAutoFetch = async () => {
    if (!form.affiliate_url.trim()) {
      toast.error('Paste an affiliate URL first');
      return;
    }
    setFetching(true);
    try {
      const { data, error } = await supabase.functions.invoke('scrape-product', {
        body: { url: form.affiliate_url.trim() },
      });
      if (error) throw error;
      const filled: Partial<FormState> = {};
      if (data?.title && !form.title) filled.title = data.title;
      if (data?.description && !form.description) filled.description = data.description;
      if (data?.image_url && !form.image_url) filled.image_url = data.image_url;
      if (data?.store_name && !form.store_name) filled.store_name = data.store_name;
      if (data?.price != null && !form.price) filled.price = String(data.price);
      setForm((f) => ({ ...f, ...filled }));
      if (data?.ok && (filled.title || filled.image_url)) {
        toast.success('Product details auto-filled — review & edit');
      } else {
        toast.info('Could not auto-detect — fill fields manually');
      }
    } catch (e: any) {
      toast.info('Auto-fetch unavailable — fill fields manually');
    } finally {
      setFetching(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    if (!form.title.trim() || !form.affiliate_url.trim()) {
      toast.error('Title and affiliate URL are required');
      return;
    }
    setSaving(true);
    const payload = {
      title: form.title.trim(),
      description: form.description.trim() || null,
      price: form.price ? Number(form.price) : null,
      image_url: form.image_url.trim() || null,
      affiliate_url: form.affiliate_url.trim(),
      store_name: form.store_name.trim() || null,
      category: form.category,
      badge: form.badge || null,
      is_active: form.is_active,
    };
    const { error } = form.id
      ? await supabase.from('deals').update(payload).eq('id', form.id)
      : await supabase.from('deals').insert({ ...payload, created_by: user.id });
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(form.id ? 'Deal updated' : 'Deal published');
    resetForm();
    load();
    onChanged?.();
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this deal permanently?')) return;
    const { error } = await supabase.from('deals').delete().eq('id', id);
    if (error) toast.error(error.message);
    else {
      toast.success('Deal deleted');
      setDeals((d) => d.filter((x) => x.id !== id));
      onChanged?.();
    }
  };

  const toggleActive = async (d: DealRow) => {
    const { error } = await supabase
      .from('deals')
      .update({ is_active: !d.is_active })
      .eq('id', d.id);
    if (error) toast.error(error.message);
    else {
      setDeals((rows) => rows.map((r) => (r.id === d.id ? { ...r, is_active: !d.is_active } : r)));
      onChanged?.();
    }
  };

  const filtered = deals.filter((d) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return (
      d.title.toLowerCase().includes(q) ||
      (d.store_name || '').toLowerCase().includes(q) ||
      d.category.toLowerCase().includes(q)
    );
  });

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="bottom" className="h-[95vh] overflow-y-auto rounded-t-3xl p-0">
        <div className="sticky top-0 z-10 bg-background border-b border-border px-4 py-3 flex items-center justify-between">
          <SheetHeader className="text-left space-y-0">
            <SheetTitle className="text-lg">Deals Admin</SheetTitle>
          </SheetHeader>
          <Button size="sm" onClick={() => { setForm(emptyForm); setShowForm(true); }} className="rounded-full">
            <Plus className="w-4 h-4 mr-1" /> New
          </Button>
        </div>

        <div className="p-4 space-y-4">
          {showForm && (
            <div className="p-4 bg-muted/40 border border-border rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-sm">{form.id ? 'Edit deal' : 'Add new deal'}</p>
                <button onClick={resetForm} className="p-1 text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div>
                <Label className="text-xs">Affiliate URL *</Label>
                <div className="flex gap-2">
                  <Input
                    value={form.affiliate_url}
                    onChange={(e) => setForm({ ...form, affiliate_url: e.target.value })}
                    placeholder="https://ekaro.in/... or amazon.in/..."
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleAutoFetch}
                    disabled={fetching}
                    className="flex-shrink-0"
                  >
                    {fetching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  </Button>
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">
                  Tap ✨ to auto-fetch product details. Missing fields? Edit below.
                </p>
              </div>

              <div>
                <Label className="text-xs">Product Name *</Label>
                <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              </div>

              <div>
                <Label className="text-xs">Description</Label>
                <Textarea
                  rows={2}
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Price ₹</Label>
                  <Input
                    type="number"
                    inputMode="decimal"
                    value={form.price}
                    onChange={(e) => setForm({ ...form, price: e.target.value })}
                  />
                </div>
                <div>
                  <Label className="text-xs">Store Name</Label>
                  <Input
                    value={form.store_name}
                    onChange={(e) => setForm({ ...form, store_name: e.target.value })}
                    placeholder="Amazon"
                  />
                </div>
              </div>

              <div>
                <Label className="text-xs">Image URL</Label>
                <Input
                  value={form.image_url}
                  onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                  placeholder="https://..."
                />
                {form.image_url && (
                  <img
                    src={form.image_url}
                    alt=""
                    className="mt-2 w-20 h-20 object-cover rounded-lg border border-border"
                    onError={(e) => ((e.currentTarget as HTMLImageElement).style.display = 'none')}
                  />
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Category *</Label>
                  <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {DEAL_CATEGORIES.filter((c) => c.key !== 'All').map((c) => (
                        <SelectItem key={c.key} value={c.key}>
                          {c.emoji} {c.key}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Badge</Label>
                  <Select value={form.badge || 'none'} onValueChange={(v) => setForm({ ...form, badge: v === 'none' ? '' : v })}>
                    <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      {DEAL_BADGES.map((b) => (
                        <SelectItem key={b} value={b}>{b}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center justify-between p-3 bg-background rounded-lg border border-border">
                <Label className="text-sm">Active (visible to users)</Label>
                <Switch
                  checked={form.is_active}
                  onCheckedChange={(v) => setForm({ ...form, is_active: v })}
                />
              </div>

              <Button className="w-full rounded-xl" onClick={handleSave} disabled={saving}>
                {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                {form.id ? 'Update Deal' : 'Publish Deal'}
              </Button>
            </div>
          )}

          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search deals..."
              className="pl-9"
            />
          </div>

          {loading ? (
            <div className="flex justify-center py-6">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">
              {deals.length === 0 ? 'No deals yet. Tap New to add one.' : 'No matches.'}
            </p>
          ) : (
            <div className="space-y-2">
              {filtered.map((d) => (
                <div
                  key={d.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border ${
                    d.is_active ? 'bg-card border-border' : 'bg-muted/30 border-border opacity-60'
                  }`}
                >
                  <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted flex-shrink-0 flex items-center justify-center">
                    {d.image_url ? (
                      <img src={d.image_url} alt="" className="w-full h-full object-cover" loading="lazy" />
                    ) : (
                      <Sparkles className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{d.title}</p>
                    <p className="text-[11px] text-muted-foreground truncate">
                      {d.category} {d.store_name ? `· ${d.store_name}` : ''} {d.price ? `· ₹${d.price}` : ''}
                    </p>
                  </div>
                  <Switch checked={d.is_active} onCheckedChange={() => toggleActive(d)} />
                  <a
                    href={d.affiliate_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 text-muted-foreground hover:text-primary"
                    title="Open affiliate URL"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                  <button onClick={() => startEdit(d)} className="p-2 text-muted-foreground hover:text-primary">
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDelete(d.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
};
