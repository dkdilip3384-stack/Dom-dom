import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Music, Upload, Trash2, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export const AudioUpload: React.FC = () => {
  const [uploading, setUploading] = useState(false);
  const [currentAudioUrl, setCurrentAudioUrl] = useState<string | null>(null);
  const [currentFileName, setCurrentFileName] = useState<string | null>(null);

  useEffect(() => {
    fetchCurrentAudio();
  }, []);

  const fetchCurrentAudio = async () => {
    try {
      const { data, error } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'background_audio_url')
        .single();

      if (!error && data?.value) {
        setCurrentAudioUrl(data.value);
        // Extract filename from URL
        const urlParts = data.value.split('/');
        setCurrentFileName(decodeURIComponent(urlParts[urlParts.length - 1]));
      }
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error fetching audio:', error);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('audio/')) {
      toast.error('Please upload an audio file (MP3, WAV, etc.)');
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('Audio file must be less than 10MB');
      return;
    }

    setUploading(true);
    try {
      // Delete existing audio if any
      if (currentFileName) {
        await supabase.storage.from('audio').remove([currentFileName]);
      }

      // Upload new audio
      const fileName = `${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('audio')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Get signed URL (private bucket)
      const { data: urlData, error: signedUrlError } = await supabase.storage
        .from('audio')
        .createSignedUrl(fileName, 60 * 60 * 24 * 365); // 1-year expiry

      if (signedUrlError) throw signedUrlError;
      const signedUrl = urlData.signedUrl;

      // Upsert app setting
      const { error: settingError } = await supabase
        .from('app_settings')
        .upsert(
          { key: 'background_audio_url', value: signedUrl, updated_at: new Date().toISOString() },
          { onConflict: 'key' }
        );

      if (settingError) throw settingError;

      setCurrentAudioUrl(signedUrl);
      setCurrentFileName(fileName);
      toast.success('Audio uploaded successfully!');
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error uploading audio:', error);
      toast.error('Failed to upload audio');
    } finally {
      setUploading(false);
      // Reset the input
      e.target.value = '';
    }
  };

  const handleRemove = async () => {
    if (!currentFileName) return;

    setUploading(true);
    try {
      // Remove from storage
      await supabase.storage.from('audio').remove([currentFileName]);

      // Remove from settings
      await supabase
        .from('app_settings')
        .delete()
        .eq('key', 'background_audio_url');

      setCurrentAudioUrl(null);
      setCurrentFileName(null);
      toast.success('Audio removed');
    } catch (error) {
      if (import.meta.env.DEV) console.error('Error removing audio:', error);
      toast.error('Failed to remove audio');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="rounded-lg border border-border p-4 space-y-3">
      <div className="flex items-center gap-2">
        <Music className="w-4 h-4 text-primary" />
        <h4 className="font-medium text-sm">Background Audio</h4>
      </div>
      
      {/* Show current audio if exists */}
      {currentAudioUrl && (
        <div className="flex items-center justify-between gap-2 p-2 bg-muted rounded-md">
          <span className="text-sm text-muted-foreground truncate flex-1">
            {currentFileName || 'Audio file uploaded'}
          </span>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleRemove}
            disabled={uploading}
            className="text-destructive hover:text-destructive shrink-0"
          >
            {uploading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Trash2 className="w-4 h-4" />
            )}
          </Button>
        </div>
      )}
      
      {/* Always show upload option */}
      <div className="space-y-2">
        <Label htmlFor="audio-upload" className="text-xs text-muted-foreground">
          {currentAudioUrl ? 'Upload new MP3 to replace current audio' : 'Upload MP3 for background playback'}
        </Label>
        <div className="relative">
          <Input
            id="audio-upload"
            type="file"
            accept="audio/*"
            onChange={handleUpload}
            disabled={uploading}
            className="cursor-pointer"
          />
          {uploading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/80 rounded-md">
              <Loader2 className="w-4 h-4 animate-spin" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
