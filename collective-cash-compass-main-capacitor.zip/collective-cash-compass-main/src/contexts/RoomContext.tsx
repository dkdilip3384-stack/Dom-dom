import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';

interface Room {
  id: string;
  code: string;
  name: string;
  created_by: string;
  created_at: string;
  group_type?: string | null;
}

interface RoomMember {
  id: string;
  room_id: string;
  user_id: string;
  display_name: string;
  is_admin: boolean;
  joined_at: string;
}

interface RoomContextType {
  rooms: Room[];
  currentRoom: Room | null;
  currentMember: RoomMember | null;
  members: RoomMember[];
  isRoomAdmin: boolean;
  loading: boolean;
  setCurrentRoom: (room: Room | null) => void;
  createRoom: (name: string, displayName: string, groupType?: string) => Promise<Room | null>;
  joinRoom: (code: string, displayName: string) => Promise<boolean>;
  leaveRoom: () => void;
  refreshRooms: () => Promise<void>;
  updateGroupType: (groupType: string) => Promise<boolean>;
}

const RoomContext = createContext<RoomContextType | undefined>(undefined);

export const RoomProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [currentRoom, setCurrentRoom] = useState<Room | null>(null);
  const [currentMember, setCurrentMember] = useState<RoomMember | null>(null);
  const [members, setMembers] = useState<RoomMember[]>([]);
  const [isRoomAdmin, setIsRoomAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchRooms = useCallback(async () => {
    if (!user) {
      setRooms([]);
      setCurrentRoom(null);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('room_members')
        .select('room_id')
        .eq('user_id', user.id);

      if (error) throw error;

      if (data && data.length > 0) {
        const roomIds = data.map(d => d.room_id);
        const { data: roomsData, error: roomsError } = await supabase
          .from('rooms')
          .select('*')
          .in('id', roomIds);

        if (roomsError) throw roomsError;
        setRooms((roomsData ?? []) as Room[]);

        const savedRoomId = localStorage.getItem(`z-kanakku-room-${user.id}`);
        const savedRoom = roomsData?.find(r => r.id === savedRoomId);
        if (savedRoom) {
          setCurrentRoom(savedRoom as Room);
        } else if (roomsData && roomsData.length === 1) {
          setCurrentRoom(roomsData[0] as Room);
        }
      } else {
        setRooms([]);
      }
    } catch (err) {
      if (import.meta.env.DEV) console.error('Error fetching rooms:', err);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    if (!currentRoom || !user) {
      setMembers([]);
      setCurrentMember(null);
      setIsRoomAdmin(false);
      return;
    }

    localStorage.setItem(`z-kanakku-room-${user.id}`, currentRoom.id);

    const fetchMembers = async () => {
      const { data, error } = await supabase
        .from('room_members')
        .select('*')
        .eq('room_id', currentRoom.id);

      if (error) {
        if (import.meta.env.DEV) console.error('Error fetching members:', error);
        return;
      }

      const membersData = (data ?? []) as RoomMember[];
      setMembers(membersData);

      const me = membersData.find(m => m.user_id === user.id);
      setCurrentMember(me ?? null);
      setIsRoomAdmin(me?.is_admin ?? false);
    };

    void fetchMembers();
  }, [currentRoom, user]);

  useEffect(() => {
    void fetchRooms();
  }, [fetchRooms]);

  const createRoom = async (name: string, displayName: string, groupType: string = 'roommates'): Promise<Room | null> => {
    if (!user) return null;

    try {
      const { data: roomData, error: roomError } = await supabase
        .from('rooms')
        .insert({ name, created_by: user.id, group_type: groupType } as any)
        .select()
        .single();

      if (roomError) throw roomError;

      const { error: memberError } = await supabase
        .from('room_members')
        .insert({
          room_id: roomData.id,
          user_id: user.id,
          display_name: displayName,
          is_admin: true,
        });

      if (memberError) throw memberError;

      const avatarUrl = user.user_metadata?.avatar_url || user.user_metadata?.picture || null;
      const { error: friendError } = await supabase
        .from('friends')
        .insert({
          name: displayName,
          room_id: roomData.id,
          user_id: user.id,
          initial_balance: 0,
          display_order: 0,
          avatar_url: avatarUrl,
        });

      if (friendError) throw friendError;

      const room = roomData as Room;
      setCurrentRoom(room);
      await fetchRooms();
      return room;
    } catch (err) {
      if (import.meta.env.DEV) console.error('Error creating room:', err);
      return null;
    }
  };

  const joinRoom = async (code: string, displayName: string): Promise<boolean> => {
    if (!user) return false;

    try {
      // Use secure RPC to join room by code (validates code server-side)
      const { data: roomId, error: joinError } = await supabase.rpc('join_room_by_code', {
        _code: code.toUpperCase(),
        _display_name: displayName,
      });

      if (joinError || !roomId) {
        if (import.meta.env.DEV) console.error('Failed to join room:', joinError);
        return false;
      }

      const roomIdStr = roomId as string;

      // Get member count for display_order
      const { data: existingMembers } = await supabase
        .from('room_members')
        .select('id')
        .eq('room_id', roomIdStr);

      // Create friend record
      const avatarUrl = user.user_metadata?.avatar_url || user.user_metadata?.picture || null;
      const { error: friendError } = await supabase
        .from('friends')
        .insert({
          name: displayName,
          room_id: roomIdStr,
          user_id: user.id,
          initial_balance: 0,
          display_order: (existingMembers?.length ?? 0),
          avatar_url: avatarUrl,
        });

      if (friendError && import.meta.env.DEV) console.error('Friend record error:', friendError);

      await fetchRooms();
      return true;
    } catch (err) {
      if (import.meta.env.DEV) console.error('Error joining room:', err);
      return false;
    }
  };

  const leaveRoom = () => {
    setCurrentRoom(null);
    if (user) {
      localStorage.removeItem(`z-kanakku-room-${user.id}`);
    }
  };

  const updateGroupType = async (groupType: string): Promise<boolean> => {
    if (!currentRoom) return false;
    const { error } = await supabase
      .from('rooms')
      .update({ group_type: groupType } as any)
      .eq('id', currentRoom.id);
    if (error) {
      if (import.meta.env.DEV) console.error('Failed to update group type:', error);
      return false;
    }
    setCurrentRoom({ ...currentRoom, group_type: groupType });
    setRooms(prev => prev.map(r => r.id === currentRoom.id ? { ...r, group_type: groupType } : r));
    return true;
  };

  return (
    <RoomContext.Provider value={{
      rooms,
      currentRoom,
      currentMember,
      members,
      isRoomAdmin,
      loading,
      setCurrentRoom,
      createRoom,
      joinRoom,
      leaveRoom,
      refreshRooms: fetchRooms,
      updateGroupType,
    }}>
      {children}
    </RoomContext.Provider>
  );
};

export const useRoom = (): RoomContextType => {
  const context = useContext(RoomContext);
  if (context === undefined) {
    throw new Error('useRoom must be used within a RoomProvider');
  }
  return context;
};
