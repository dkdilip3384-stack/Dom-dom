import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);



export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const checkAdminStatus = useCallback(async (currentUser: User | null) => {
    if (!currentUser) {
      setIsAdmin(false);
      setIsSuperAdmin(false);
      return;
    }

    try {
      const { data: roles, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', currentUser.id);

      if (error) {
        if (import.meta.env.DEV) console.error('Failed to check roles:', error);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        return;
      }

      const roleSet = new Set((roles ?? []).map(r => r.role));
      setIsAdmin(roleSet.has('admin') || roleSet.has('super_admin'));
      setIsSuperAdmin(roleSet.has('super_admin'));
    } catch (error) {
      if (import.meta.env.DEV) console.error('Unexpected role check error:', error);
      setIsAdmin(false);
      setIsSuperAdmin(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;
    const safetyTimeout = window.setTimeout(() => {
      if (isMounted) {
        setLoading(false);
      }
    }, 3000);

    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, nextSession) => {
        if (!isMounted) return;

        setSession(nextSession);
        setUser(nextSession?.user ?? null);

        if (nextSession?.user) {
          void checkAdminStatus(nextSession.user);
        } else {
          setIsAdmin(false);
        }

        // Never block UI on admin role check/network delay
        setLoading(false);
      }
    );

    // THEN check for existing session
    (async () => {
      try {
        const { data: { session: existingSession }, error } = await supabase.auth.getSession();

        if (!isMounted) return;

        if (error) {
          if (import.meta.env.DEV) console.error('Failed to restore session:', error);
          setSession(null);
          setUser(null);
          setIsAdmin(false);
          return;
        }

        setSession(existingSession);
        setUser(existingSession?.user ?? null);

        if (existingSession?.user) {
          void checkAdminStatus(existingSession.user);
        } else {
          setIsAdmin(false);
        }
      } catch (error) {
        if (!isMounted) return;
        if (import.meta.env.DEV) console.error('Unexpected session restore error:', error);
        setSession(null);
        setUser(null);
        setIsAdmin(false);
      } finally {
        if (isMounted) setLoading(false);
      }
    })();

    return () => {
      isMounted = false;
      window.clearTimeout(safetyTimeout);
      subscription.unsubscribe();
    };
  }, [checkAdminStatus]);

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      return { error };
    } catch (error: any) {
      if (import.meta.env.DEV) console.error('Sign in network error:', error);
      return { error: new Error(error?.message || 'Network error while signing in') };
    }
  };

  const signUp = async (email: string, password: string) => {
    const redirectUrl = `${window.location.origin}/`;
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl
      }
    });
    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setIsAdmin(false);
    setIsSuperAdmin(false);
  };

  return (
    <AuthContext.Provider value={{ user, session, loading, isAdmin, isSuperAdmin, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
