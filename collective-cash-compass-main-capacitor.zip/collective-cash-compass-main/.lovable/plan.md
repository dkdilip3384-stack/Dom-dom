# Centralized Super Admin System

Add a global Super Admin layer above the existing Room Admin role without altering current room-scoped permissions or UI.

## 1. Role foundation (database)

- Keep existing `user_roles` table and `has_role()` function. Add `'super_admin'` to `app_role` enum (currently: admin, moderator, user).
- Replace `is_super_admin()` (currently hardcoded to the owner email) with a version that reads from `user_roles`:
  ```
  SELECT public.has_role(auth.uid(), 'super_admin')
  ```
- Seed one row: user_id of dkdilip3384@gmail.com → role `super_admin`. Email lookup happens once at seed time; runtime checks use user_id only.
- Add trigger blocking any INSERT/UPDATE/DELETE on `user_roles` for role='super_admin' unless the caller is already an active super admin (protects the owner account).

All existing Room Admin logic (`is_room_admin`, room_members.is_admin, RLS on rooms/expenses/friends/etc.) stays untouched.

## 2. New Super-Admin-owned tables

All with RLS: public SELECT limited to `status='published'`; all writes gated by `is_super_admin()`.

- `faqs` — question, answer, display_order, status (draft/published/hidden), lang
- `contact_methods` — type (email/phone/whatsapp/hours), label, value, display_order, status
- `about_sections` — title, body, display_order, status, lang
- `legal_documents` — kind ('privacy'|'terms'), version, effective_date, published_at, status ('draft'|'published'|'archived'), summary, content, previous_version_id, created_by
- `legal_acceptances` — user_id, document_id, accepted_at (for "review & accept again" flow)
- `admin_audit_log` — actor_id, actor_email, action, entity, entity_id, before, after, ip, status, created_at (SELECT limited to super admin)

Each table gets the required GRANTs (authenticated SELECT where applicable, service_role ALL) and standard updated_at trigger.

## 3. Frontend role plumbing

- Extend `AuthContext`: add `isSuperAdmin` (queries `has_role(uid, 'super_admin')`); keep existing `isAdmin` untouched.
- New hook `useSuperAdmin()` for convenience.
- Route guard component `<RequireSuperAdmin>` that redirects non-super-admins to `/` with an "Access Denied" toast.

## 4. Settings page rebuild

Rewrite `src/pages/Settings.tsx` to the requested full-page structure (title "Settings", no big profile card):

- **Account**: My Profile, Group Settings, Notification Settings, Language
- **Support**: Help & FAQ, Contact Us, Rate App, Share App
- **Legal & Information**: Privacy Policy, Terms & Conditions, About Z-KANAKKU
- **Account Actions**: Delete Account (red/destructive), Sign Out (bottom, separated)

Existing Room Admin entries (Manage Balances, Duty Setup, Notification Settings) remain visible to room admins as they are today — grouped under "Group Settings" / "Notification Settings" so nothing is removed.

Public content pages (FAQ, Contact, About, Privacy, Terms) read from the new tables and show only `published` rows + current effective legal version. A "Policy updated" banner appears when the latest published legal version's `published_at` is newer than the user's last acceptance.

## 5. Super Admin console

New route `/super-admin` (guarded), with sub-sections:

- FAQ manager — add/edit/hide/reorder/publish
- Contact manager — add/edit/hide contact methods
- About manager — add/edit/hide sections
- Legal manager (Privacy & Terms) — draft, preview, publish, unpublish, archive, restore, version history, restore previous version. Delete = archive (never hard delete).
- Audit log viewer (read-only)
- Sensitive actions (publish legal, archive, delete accounts, role changes) go through a confirmation dialog spelling out consequences.

Entry point: a "Super Admin" tile in Settings, rendered only when `isSuperAdmin === true`.

## 6. Audit logging

Server-side: trigger on FAQ / contact / about / legal tables writes any change into `admin_audit_log` with `auth.uid()`, `auth.jwt() ->> 'email'`, action, before/after JSON. Login and failed access events logged from the client via an RPC.

## 7. Non-goals / preservation guarantees

- No changes to: rooms, room_members, expenses, expense_splits, friends, duty_assignments, notifications, deals, custom_deals, app_settings, or any of their RLS policies.
- No changes to `is_room_admin`, `join_room_by_code`, `delete_room`, or existing AdminPanel/DutySetupPanel/NotificationSettings functionality.
- Owner email appears exactly once — in the seed migration. Every runtime check uses `has_role(auth.uid(), 'super_admin')`.

## Technical details

- Migration order per new table: CREATE → GRANT → ENABLE RLS → POLICIES → trigger.
- Legal version history uses append-only inserts; archive = `status='archived'`; restore = new row copying archived content as new draft.
- RLS pattern for content tables:
  - `SELECT` to anon+authenticated: `USING (status = 'published')`
  - `ALL` to authenticated: `USING (public.is_super_admin()) WITH CHECK (public.is_super_admin())`
  - `ALL` to service_role
- `admin_audit_log`: no INSERT policy for clients; only trigger (SECURITY DEFINER) and service_role write. SELECT restricted to super admin.
- Client uses existing `@/integrations/supabase/client`; no edits to auto-generated files.
